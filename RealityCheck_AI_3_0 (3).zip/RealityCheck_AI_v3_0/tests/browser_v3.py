"""3.0 portable-browser checks (no server). Optional: needs Python Playwright + Chromium.
Run: python tests/browser_v3.py   — writes docs/V3_*.png and docs/browser_v3_results.json"""
import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
URL = (ROOT/'RealityCheck_AI.html').as_uri()
results = []
def check(name, ok):
    results.append({'name': name, 'passed': bool(ok)}); print(('PASS ' if ok else 'FAIL ')+name)

with sync_playwright() as p:
    kw = {'executable_path': os.environ['CHROMIUM_EXECUTABLE']} if os.getenv('CHROMIUM_EXECUTABLE') else {}
    b = p.chromium.launch(**kw)
    errors = []
    for lang in ('en', 'ar', 'he'):
        pg = b.new_page(viewport={'width': 1440, 'height': 900}, device_scale_factor=2 if lang == 'en' else 1)
        pg.on('pageerror', lambda e: errors.append(str(e)))
        pg.goto(URL+'#full'); pg.wait_for_timeout(300); pg.click(f'[data-lang="{lang}"]')
        check(f'{lang}: version 3.0.0 shown', '3.0.0' in pg.locator('.version').inner_text())
        check(f'{lang}: portable opens quick check', pg.locator('#v3-quick-text').count() == 1)
        pg.click('[data-page="redteam"]'); pg.click('[data-v3="example"]'); pg.click('[data-v3="launch"]'); pg.wait_for_timeout(1500)
        check(f'{lang}: 13 attack cards rendered', pg.locator('.v3-attack').count() == 13)
        summary = pg.locator('.v3-live-summary strong').all_inner_texts()
        v2, v3 = int(summary[1].rstrip('%')), int(summary[2].rstrip('%'))
        check(f'{lang}: shield improves live robustness ({v2}% -> {v3}%)', v3 > v2)
        check(f'{lang}: benchmark shows 44.4 -> 91.3', '44.4' in pg.locator('.v3-big.old').inner_text() and '91.3' in pg.locator('.v3-big.new').inner_text())
        check(f'{lang}: no horizontal overflow', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        if lang == 'en':
            pg.evaluate('scrollTo(0,0)'); pg.wait_for_timeout(1500); pg.screenshot(path=str(ROOT/'docs/V3_REDTEAM_DESKTOP.png'))
            pg.locator('#v3-live-result').screenshot(path=str(ROOT/'docs/V3_REDTEAM_LIVE.png'))
        pg.locator('[data-v3="xray"][data-idx="2"]').click(); pg.wait_for_timeout(1300)  # soft-hyphen attack
        hidden = pg.locator('.v3-xray .v3-hidden').count()
        check(f'{lang}: X-ray reveals hidden characters ({hidden})', hidden > 0)
        check(f'{lang}: manipulation DNA radar rendered', pg.locator('.v3-radar-shape').count() == 1)
        if lang == 'en': pg.locator('.v3-extras').screenshot(path=str(ROOT/'docs/V3_DNA_XRAY.png'))
        pg.click('[data-page="arena"]'); pg.click('[data-v3="arena-start"]')
        for i in range(8):
            pg.click('[data-choice="scam"]')
            if lang == 'en' and i == 4: pg.wait_for_timeout(700); pg.screenshot(path=str(ROOT/'docs/V3_HUMAN_VS_AI.png'))
            pg.click('[data-v3="next"]')
        final = pg.locator('.v3-final-score strong').all_inner_texts()
        check(f'{lang}: arena completes, engine 7/8 (hi-mom round missed by design)', final[1].startswith('7'))
        pg.close()
    m = b.new_page(**p.devices['iPhone 13']); m.on('pageerror', lambda e: errors.append(str(e)))
    m.goto(URL+'#full'); m.wait_for_timeout(300); m.evaluate("document.querySelector('[data-page=redteam]').click()"); m.wait_for_timeout(1200)
    check('mobile: no horizontal overflow on Red Team Arena', m.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    m.screenshot(path=str(ROOT/'docs/V3_MOBILE.png'))
    check('no page errors', not errors)
    b.close()
(ROOT/'docs/browser_v3_results.json').write_text(json.dumps({'passed': sum(r['passed'] for r in results), 'total': len(results), 'checks': results, 'errors': errors}, indent=2), encoding='utf-8')
print(f"{sum(r['passed'] for r in results)}/{len(results)} passed")
