/* RealityCheck 3.0 — Red Team Arena, Manipulation DNA, Evidence X-ray, Human vs AI.
   Local only: every function here runs in the browser with no network requests.
   All user text is escaped before it reaches the DOM. */
window.RC_V3={create(ctx){
 const {state,t,esc,icon,render,toast}=ctx;
 const L=()=>state.lang;
 const S={
  ar:{redteam:'ساحة الهجوم',arena:'إنسان ضد الذكاء',newBadge:'جديد',
   rtEyebrow:'اختبار قوة النظام',rtTitle:'هاجمنا نظامنا قبل ما يهاجمه المحتال.',rtBody:'المحتالون لا يكتبون "كلمة المرور" بشكل نظيف. يخفون الحروف، يستبدلونها بأرقام، يدخلون رموزًا غير مرئية. هنا نلعب دور المهاجم: نعيد كتابة الكلمات التي كشفت الرسالة بـ13 تقنية تمويه، ثم نقيس هل صمد المحرك.',
   benchTitle:'المناعة ضد التمويه',benchSub:'نسبة الهجمات التي لم تُسقط مستوى الإنذار — هجوم "صندوق أبيض" يعرف الكلمات التي كشفته',trials:'محاولة هجوم',messages:'رسالة مستهدفة',fpGuard:'إنذارات كاذبة جديدة على النصوص العادية',
   engineV2:'محرك 2.0',engineV3:'محرك 3.0 + درع التمويه',liveTitle:'جرّب الهجوم بنفسك',liveSub:'الصق رسالة احتيال (أو استخدم المثال) وأطلق كل تقنيات التمويه دفعة واحدة.',launch:'أطلق 13 هجومًا',useExample:'مثال جاهز',
   held:'صمد',degraded:'ضعف',evaded:'اخترق',na:'غير منطبق',original:'الرسالة الأصلية',mutated:'بعد التمويه',robustThis:'مناعة هذه الرسالة',
   notAttackable:'هذه الرسالة لم تُطلق إنذارًا أصلًا، لذلك لا يوجد ما يُهاجَم. جرّب رسالة احتيال.',perOp:'النتائج حسب تقنية الهجوم',operator:'التقنية',family:'العائلة',
   fam:{invisible:'غير مرئي',visual:'بصري',structural:'بنيوي',semantic:'دلالي',url:'روابط'},
   honest:'نقطة ضعف معروفة ومعلنة: إعادة الصياغة بالمعنى ما زالت تخترق المحرك، لأن الدرع يعالج الشكل لا المعنى. هذا هو اتجاه البحث القادم (نموذج دلالي متعدد اللغات).',
   shieldTitle:'كيف يعمل درع التمويه؟',shieldBody:'طبقة تطبيع ثانية قبل القواعد: تحويل الحروف المتشابهة (سيريلية، يونانية، فارسية) إلى أصلها، فك الـLeetspeak داخل الكلمات فقط، حذف المحارف غير المرئية والرموز المزروعة داخل الكلمة، جمع الحروف المفرّقة، وتوحيد الأرقام العربية-الهندية. كل حرف يحتفظ بموقعه الأصلي، فالدليل المعروض هو نص المستخدم كما هو.',
   attackThis:'هاجم هذه الرسالة',
   dnaTitle:'البصمة النفسية للرسالة',dnaSub:'أي أدوات تلاعب نفسي تستخدمها الرسالة؟ مبنية على مبادئ Stajano & Wilson (2011) لفهم ضحايا الاحتيال.',dnaNote:'مؤشرات لغوية، ليست قياسًا نفسيًا.',wants:'ماذا يريد المرسل؟',
   ax:{time:'ضغط الوقت',authority:'انتحال سلطة',fear:'التخويف',greed:'الطمع',secrecy:'العزل والسرية',herd:'تأثير القطيع',kindness:'استغلال العاطفة'},
   want:{credentials:'كلمة المرور أو الرموز',payment:'أموالك',remote_access:'السيطرة على جهازك',none:'لم يتم تحديد طلب حساس'},
   xrayTitle:'أشعة X للأدلة',xraySub:'الكلمات التي أطلقت القواعد ملوّنة. الحروف المخفية أو المتنكرة التي لا تراها العين تظهر بالأحمر.',hidden:'محرف مخفي/متنكر',hiddenCount:'محارف مخفية أو متنكرة',noHidden:'لا توجد محارف مخفية',
   warnTitle:'حذّر شخصًا تحبه',warnBody:'رسالة قصيرة جاهزة للنسخ — بدون الرابط المشبوه وبدون نص الرسالة الأصلية.',copy:'انسخ التحذير',copied:'تم النسخ',
   warnText:(s,w,l)=>`⚠️ انتبه: وصلتني رسالة تبدو احتيالية (مؤشر ${s}/100). تطلب ${w}${l?` وتستخدم ${l}`:''}. لا تضغط على روابطها ولا تشارك أي رمز — تواصل مع الجهة عبر تطبيقها أو رقمها الرسمي.`,
   arEyebrow:'تحدّي: إنسان ضد الذكاء',arTitle:'هل تكشف الاحتيال أسرع من الآلة؟',arBody:'8 رسائل. الجمهور يصوّت أولًا، ثم يكشف المحرك قراره وأدلته. بعض الجولات صُممت لتُسقط الإنسان، وبعضها لتُسقط الآلة.',
   start:'ابدأ التحدي',round:'جولة',of:'من',scam:'احتيال',legit:'سليمة',vote:'تصويت الجمهور',humans:'الجمهور',engine:'المحرك',truth:'الحقيقة',engineSays:'المحرك يقول',next:'الجولة التالية',finish:'النتيجة النهائية',again:'العب مجددًا',
   correct:'صح',wrong:'خطأ',finalTitle:'النتيجة النهائية',finalBody:'الإنسان يقرأ السياق والعاطفة، والآلة لا تتعب ولا تنخدع بالحروف المخفية. الأقوى هو الاثنين معًا.',why:'لماذا؟',
   synthetic:'رسائل تجريبية مصطنعة',gp:'ضغط',gm:'مال',gs:'أسرار وروابط'},
  he:{redteam:'זירת התקיפה',arena:'אדם מול AI',newBadge:'חדש',
   rtEyebrow:'בדיקת עמידות המערכת',rtTitle:'תקפנו את המערכת שלנו לפני שהנוכל יעשה זאת.',rtBody:'נוכלים לא כותבים "סיסמה" בצורה נקייה. הם מסווים אותיות, מחליפים אותן בספרות ומחדירים תווים בלתי נראים. כאן אנחנו התוקף: משכתבים את המילים שחשפו את ההודעה ב-13 טכניקות הסוואה ובודקים אם המנוע עמד בכך.',
   benchTitle:'חסינות להסוואה',benchSub:'שיעור ניסיונות התקיפה שלא הורידו את רמת ההתראה — תוקף "קופסה לבנה" שמכיר את המילים שחשפו אותו',trials:'ניסיונות תקיפה',messages:'הודעות מותקפות',fpGuard:'התראות שווא חדשות בטקסטים רגילים',
   engineV2:'מנוע 2.0',engineV3:'מנוע 3.0 + מגן הסוואה',liveTitle:'נסו לתקוף בעצמכם',liveSub:'הדביקו הודעת הונאה (או השתמשו בדוגמה) והפעילו את כל טכניקות ההסוואה בבת אחת.',launch:'הפעל 13 תקיפות',useExample:'דוגמה מוכנה',
   held:'עמד',degraded:'נחלש',evaded:'נפרץ',na:'לא רלוונטי',original:'ההודעה המקורית',mutated:'אחרי הסוואה',robustThis:'חסינות ההודעה הזו',
   notAttackable:'ההודעה לא הפעילה התראה מלכתחילה, כך שאין מה לתקוף. נסו הודעת הונאה.',perOp:'תוצאות לפי טכניקת תקיפה',operator:'טכניקה',family:'משפחה',
   fam:{invisible:'בלתי נראה',visual:'חזותי',structural:'מבני',semantic:'סמנטי',url:'קישורים'},
   honest:'חולשה ידועה ומוצהרת: ניסוח מחדש במשמעות עדיין עוקף את המנוע, כי המגן מטפל בצורה ולא במשמעות. זה כיוון המחקר הבא (מודל סמנטי רב-לשוני).',
   shieldTitle:'איך עובד מגן ההסוואה?',shieldBody:'שכבת נרמול שנייה לפני הכללים: המרת אותיות דומות (קירילית, יוונית, פרסית) למקור, פענוח Leetspeak בתוך מילים בלבד, הסרת תווים בלתי נראים וסמלים שהוחדרו למילה, איחוד אותיות מרווחות ואיחוד ספרות הודיות-ערביות. כל תו שומר על מיקומו המקורי, כך שהראיה המוצגת היא הטקסט המקורי.',
   attackThis:'תקוף את ההודעה הזו',
   dnaTitle:'טביעת האצבע הפסיכולוגית',dnaSub:'באילו מנופי מניפולציה ההודעה משתמשת? מבוסס על עקרונות Stajano & Wilson (2011) להבנת קורבנות הונאה.',dnaNote:'סימנים לשוניים, לא מדידה פסיכולוגית.',wants:'מה השולח רוצה?',
   ax:{time:'לחץ זמן',authority:'התחזות לסמכות',fear:'הפחדה',greed:'חמדנות',secrecy:'בידוד וסודיות',herd:'אפקט העדר',kindness:'ניצול רגשי'},
   want:{credentials:'סיסמה או קודים',payment:'הכסף שלך',remote_access:'שליטה במכשיר שלך',none:'לא זוהתה בקשה רגישה'},
   xrayTitle:'רנטגן ראיות',xraySub:'המילים שהפעילו כללים צבועות. תווים מוסתרים או מתחזים שהעין לא רואה מופיעים באדום.',hidden:'תו מוסתר/מתחזה',hiddenCount:'תווים מוסתרים או מתחזים',noHidden:'אין תווים מוסתרים',
   warnTitle:'הזהירו מישהו שאתם אוהבים',warnBody:'הודעה קצרה להעתקה — בלי הקישור החשוד ובלי טקסט ההודעה המקורית.',copy:'העתק אזהרה',copied:'הועתק',
   warnText:(s,w,l)=>`⚠️ שימו לב: קיבלתי הודעה שנראית כהונאה (מדד ${s}/100). היא מבקשת ${w}${l?` ומשתמשת ב${l}`:''}. אל תלחצו על קישורים ואל תמסרו קודים — פנו לגוף דרך האפליקציה או המספר הרשמי.`,
   arEyebrow:'אתגר: אדם מול AI',arTitle:'האם תזהו הונאה מהר יותר מהמכונה?',arBody:'8 הודעות. הקהל מצביע קודם, ואז המנוע חושף החלטה וראיות. חלק מהסבבים נועדו להפיל את האדם, וחלקם את המכונה.',
   start:'התחילו את האתגר',round:'סבב',of:'מתוך',scam:'הונאה',legit:'תקינה',vote:'הצבעת הקהל',humans:'הקהל',engine:'המנוע',truth:'האמת',engineSays:'המנוע אומר',next:'הסבב הבא',finish:'תוצאה סופית',again:'שחקו שוב',
   correct:'נכון',wrong:'שגוי',finalTitle:'התוצאה הסופית',finalBody:'האדם קורא הקשר ורגש; המכונה לא מתעייפת ולא נופלת בתווים מוסתרים. החזק ביותר — שניהם יחד.',why:'למה?',
   synthetic:'הודעות סינתטיות מבוימות',gp:'לחץ',gm:'כסף',gs:'סודות וקישורים'},
  en:{redteam:'Red Team Arena',arena:'Human vs AI',newBadge:'NEW',
   rtEyebrow:'Robustness test',rtTitle:'We attacked our own AI before scammers could.',rtBody:'Scammers don’t type “password” cleanly. They disguise letters, swap them for digits and inject invisible characters. Here we play the attacker: the exact words that exposed a message are rewritten with 13 evasion techniques, then we measure whether the engine still holds.',
   benchTitle:'Evasion robustness',benchSub:'Share of attack trials that did not lower the alert level — a white-box attacker who knows which words exposed it',trials:'attack trials',messages:'messages attacked',fpGuard:'new false alerts on ordinary texts',
   engineV2:'Engine 2.0',engineV3:'Engine 3.0 + Evasion Shield',liveTitle:'Run the attack yourself',liveSub:'Paste a scam message (or use the example) and launch every evasion technique at once.',launch:'Launch 13 attacks',useExample:'Use example',
   held:'Held',degraded:'Weakened',evaded:'Evaded',na:'n/a',original:'Original message',mutated:'After evasion',robustThis:'Robustness for this message',
   notAttackable:'This message did not raise an alert in the first place, so there is nothing to attack. Try a scam message.',perOp:'Results by attack technique',operator:'Technique',family:'Family',
   fam:{invisible:'invisible',visual:'visual',structural:'structural',semantic:'semantic',url:'links'},
   honest:'Known, declared weakness: meaning-preserving paraphrase still evades the engine, because the shield repairs form, not meaning. That is the next research direction (a multilingual semantic model).',
   shieldTitle:'How the Evasion Shield works',shieldBody:'A second normalization pass before the rules: look-alike letters (Cyrillic, Greek, Persian) are mapped back, leetspeak is decoded only inside words, invisible characters and symbols planted inside words are removed, spaced-out letters are joined, and Arabic-Indic digits are unified. Every character keeps its original offset, so the evidence shown is still the user’s own text.',
   attackThis:'Attack this message',
   dnaTitle:'Manipulation DNA',dnaSub:'Which psychological levers does the message pull? Based on Stajano & Wilson (2011), “Understanding scam victims: seven principles for systems security”.',dnaNote:'Lexical cues, not a psychological measurement.',wants:'What does the sender want?',
   ax:{time:'Time pressure',authority:'Authority',fear:'Fear',greed:'Greed',secrecy:'Secrecy',herd:'Herd',kindness:'Kindness'},
   want:{credentials:'your password or codes',payment:'your money',remote_access:'control of your device',none:'no sensitive request identified'},
   xrayTitle:'Evidence X-ray',xraySub:'Words that triggered rules are highlighted. Hidden or disguised characters the eye cannot see show up in red.',hidden:'hidden/disguised character',hiddenCount:'hidden or disguised characters',noHidden:'No hidden characters',
   warnTitle:'Warn someone you love',warnBody:'A short message ready to copy — without the suspicious link and without the original text.',copy:'Copy warning',copied:'Copied',
   warnText:(s,w,l)=>`⚠️ Heads-up: I received a message that looks like a scam (score ${s}/100). It asks for ${w}${l?` and uses ${l}`:''}. Don’t click its links or share any code — contact the organization through its official app or number.`,
   arEyebrow:'Challenge: human vs AI',arTitle:'Can you spot the scam faster than the machine?',arBody:'8 messages. The audience votes first, then the engine reveals its decision and evidence. Some rounds are designed to fool humans, others to fool the machine.',
   start:'Start the challenge',round:'Round',of:'of',scam:'Scam',legit:'Legit',vote:'Audience vote',humans:'Audience',engine:'Engine',truth:'Truth',engineSays:'Engine says',next:'Next round',finish:'Final score',again:'Play again',
   correct:'Correct',wrong:'Wrong',finalTitle:'Final score',finalBody:'Humans read context and emotion; the machine never gets tired and is not fooled by hidden characters. The strongest defence is both together.',why:'Why?',
   synthetic:'synthetic, staged messages',gp:'pressure',gm:'money',gs:'secrets & links'}
 };
 const s=k=>S[L()][k]??S.en[k];
 for(const lang of ['ar','he','en']){window.RC_I18N[lang].redteam=S[lang].redteam;window.RC_I18N[lang].arena=S[lang].arena;}
 /* Plain-language navigation labels (override the older technical names). */
 const NAV={
  ar:{quick:'افحص',investigate:'فحص مفصّل',arena:'اختبر نفسك',history:'المحفوظات',redteam:'ضد التحايل',lab:'أمثلة',evaluation:'دقة النظام',about:'عن المشروع',navMain:'الفحص',navProject:'للمهتمين بالتفاصيل',offlineTag:'بيشتغل بدون إنترنت',local:'الفحص على جهازك',privacyBadge:'ما بنفتح الروابط المشبوهة'},
  he:{quick:'בדיקה',investigate:'בדיקה מפורטת',arena:'בחנו את עצמכם',history:'שמורים',redteam:'נגד תחבולות',lab:'דוגמאות',evaluation:'דיוק המערכת',about:'על הפרויקט',navMain:'בדיקה',navProject:'לפרטים נוספים',offlineTag:'עובד בלי אינטרנט',local:'הבדיקה במכשיר שלכם',privacyBadge:'לא פותחים קישורים חשודים'},
  en:{quick:'Check',investigate:'Detailed check',arena:'Test yourself',history:'Saved',redteam:'Anti-tricks',lab:'Examples',evaluation:'Accuracy',about:'About',navMain:'Check',navProject:'More details',offlineTag:'Works offline',local:'Runs on your device',privacyBadge:'We never open suspicious links'}
 };
 for(const lang of ['ar','he','en'])Object.assign(window.RC_I18N[lang],NAV[lang]);


 /* ---------- Manipulation DNA ---------- */
 const norm=x=>RC_ML.matching(String(x).toLowerCase());
 const CUES={
  time:['today','tonight','now','expires','expire','deadline','final notice','last','hours','minutes','اليوم','الان','حالا','ينتهي','اخر','مهلة','ساعة','دقيقة','بسرعة','היום','עכשיו','מיד','פג','אחרון','שעות','דקות'],
  authority:['bank','police','government','ministry','tax','court','security team','support','technician','manager','ceo','official','customs','بنك','البنك','شرطة','وزارة','ضريبة','محكمة','الدعم','الفني','مدير','الادارة','رسمي','الجمارك','בנק','משטרה','משרד','מס','בית משפט','תמיכה','טכנאי','מנהל','רשמי','מכס'],
  fear:['suspend','block','close','closed','infected','virus','legal','arrest','fine','penalty','hold','lose','ايقاف','يتوقف','حظر','اغلاق','تعليق','مصاب','فيروس','غرامة','اعتقال','قانوني','متوقف','تخسر','חסימה','ייסגר','נגוע','וירוס','קנס','מעצר','משפטי','מעוכב','תאבד'],
  greed:['won','win','prize','profit','free','bonus','gift','reward','double','guaranteed','ربح','ربحت','جائزة','مجاني','هدية','مكافاة','ضاعف','مضمون','זכית','פרס','רווח','חינם','מתנה','בונוס','הכפל','מובטח'],
  secrecy:['secret','between us','tell anyone','confidential','سر','بيننا','تخبر','لحدا','سري','סוד','בינינו','לאף אחד','חסוי'],
  herd:['everyone','thousands','others already','limited spots','only a few','الجميع','الاف','كثيرون','اماكن محدودة','كل الناس','כולם','אלפים','מקומות מוגבלים','רבים כבר'],
  kindness:['mom','mum','dad','help me','please help','emergency','lost my phone','new number','ماما','بابا','ساعدني','طوارئ','ضاع تلفوني','رقمي الجديد','امي','ابي','אמא','אבא','עזרו','חירום','הטלפון שלי נאבד','המספר החדש']
 };
 const NCUES=Object.fromEntries(Object.entries(CUES).map(([k,v])=>[k,[...new Set(v.map(norm))]]));
 const AXES=['time','authority','fear','greed','secrecy','herd','kindness'];
 function dna(r){
  const text=norm(r.original_text||''),codes=new Set((r.signals||[]).filter(x=>x.weight).map(x=>x.code)),allCodes=new Set((r.signals||[]).map(x=>x.code));
  const hits=k=>NCUES[k].filter(c=>{const re=new RegExp('(?:^|[^\\p{L}])'+c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?:$|[^\\p{L}])','u');return re.test(text);}).length;
  const base={time:codes.has('urgency')?100:0,authority:(codes.has('domain_mismatch')||codes.has('lookalike')||codes.has('brand_bait')||codes.has('userinfo'))?70:codes.has('threat')?55:0,fear:codes.has('threat')?100:0,greed:(codes.has('reward'))?100:codes.has('unusual_payment')?45:0,secrecy:codes.has('secrecy')?100:0,herd:0,kindness:0};
  const v={};for(const k of AXES)v[k]=Math.max(base[k],Math.min(85,hits(k)*35));
  const wants=[];if(codes.has('credentials'))wants.push('credentials');if(codes.has('payment')||codes.has('unusual_payment'))wants.push('payment');if(codes.has('remote_access'))wants.push('remote_access');
  return {v,wants,allCodes};
 }
 function radar(v){
  const W=340,C=170,R=118,n=AXES.length,pt=(i,f)=>{const a=-Math.PI/2+2*Math.PI*i/n;return [C+Math.cos(a)*R*f,C+Math.sin(a)*R*f];};
  const ring=f=>AXES.map((_,i)=>pt(i,f).map(x=>x.toFixed(1)).join(',')).join(' ');
  const poly=AXES.map((k,i)=>pt(i,Math.max(.04,v[k]/100)).map(x=>x.toFixed(1)).join(',')).join(' ');
  const labels=AXES.map((k,i)=>{const [x,y]=pt(i,1.24);const anchor=Math.abs(x-C)<8?'middle':x>C?'start':'end';return `<text x="${x.toFixed(1)}" y="${(y+4).toFixed(1)}" text-anchor="${anchor}" class="v3-radar-label ${v[k]>=50?'hot':''}">${esc(s('ax')[k])}</text>`;}).join('');
  const dots=AXES.map((k,i)=>v[k]?`<circle cx="${pt(i,v[k]/100)[0].toFixed(1)}" cy="${pt(i,v[k]/100)[1].toFixed(1)}" r="4" class="v3-radar-dot"/>`:'').join('');
  return `<svg class="v3-radar" viewBox="-70 -10 ${W+140} ${W+20}" role="img" aria-label="${esc(s('dnaTitle'))}" direction="ltr">${[.25,.5,.75,1].map(f=>`<polygon points="${ring(f)}" class="v3-radar-ring"/>`).join('')}${AXES.map((_,i)=>{const [x,y]=pt(i,1);return `<line x1="${C}" y1="${C}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" class="v3-radar-axis"/>`;}).join('')}<polygon points="${poly}" class="v3-radar-shape"/>${dots}${labels}</svg>`;
 }
 /* ---------- Evidence X-ray ---------- */
 const SUSPECT=/[­͏؜ᅟᅠ឴឵᠎​-‏‪-‮⁠-⁤⁦-⁩ㅤ﻿ﾠ︀-️]/;
 const CONFUSABLE=/[Ѐ-ӿͰ-Ͽ]/;
 function xray(r){
  const text=r.original_text||'',marks=new Array(text.length).fill(null);
  const groups={pressure:'p',money:'m',secrets:'s',url:'u',context:'c',format:'c'};
  for(const sig of (r.signals||[]))if(Number.isFinite(sig.start)&&sig.weight)for(let i=sig.start;i<Math.min(sig.end,text.length);i++)marks[i]??=groups[sig.group]||'c';
  let out='',cur=null,buf='',hidden=0;
  const flush=()=>{if(buf)out+=cur?`<mark class="v3-mark v3-${cur}">${buf}</mark>`:buf;buf='';};
  for(let i=0;i<text.length;){
   const c=String.fromCodePoint(text.codePointAt(i)),m=marks[i];
   if(m!==cur){flush();cur=m;}
   const latinNeighbour=/[A-Za-z]/.test(text[i-1]||'')||/[A-Za-z]/.test(text[i+c.length]||'');
   if(SUSPECT.test(c)){hidden++;buf+=`<span class="v3-hidden" title="${esc(s('hidden'))} U+${c.codePointAt(0).toString(16).toUpperCase().padStart(4,'0')}">${c==='­'?'SHY':'ZW'}</span>`;}
   else if(CONFUSABLE.test(c)&&latinNeighbour){hidden++;buf+=`<span class="v3-hidden v3-glyph" title="${esc(s('hidden'))} U+${c.codePointAt(0).toString(16).toUpperCase().padStart(4,'0')}">${esc(c)}</span>`;}
   else buf+=esc(c);
   i+=c.length;
  }
  flush();
  return {html:out,hidden};
 }
 function warnText(r,d){
  const w=d.wants.length?d.wants.map(k=>s('want')[k]).join(' + '):s('want').none;
  const levers=AXES.filter(k=>d.v[k]>=50).sort((a,b)=>d.v[b]-d.v[a]).slice(0,2).map(k=>s('ax')[k]).join(' + ');
  return S[L()].warnText(r.score,w,levers);
 }
 function reportExtras(){
  const r=state.report;if(!r||r.input_type==='url')return '';
  const d=dna(r),x=xray(r),warn=warnText(r,d);
  return `<section class="v3-extras"><article class="card v3-dna"><div class="v3-card-head"><div><h2>${esc(s('dnaTitle'))}</h2><p>${esc(s('dnaSub'))}</p></div></div><div class="v3-dna-body">${radar(d.v)}<div class="v3-dna-side"><span class="v3-label">${esc(s('wants'))}</span><div class="v3-wants">${(d.wants.length?d.wants:['none']).map(k=>`<span class="v3-want ${k}">${esc(s('want')[k])}</span>`).join('')}</div><div class="v3-bars">${AXES.map(k=>`<div class="v3-bar"><span>${esc(s('ax')[k])}</span><i><b style="width:${d.v[k]}%"></b></i><code>${d.v[k]}</code></div>`).join('')}</div><small>${esc(s('dnaNote'))}</small></div></div></article>
  <article class="card v3-xray"><div class="v3-card-head"><div><h2>${esc(s('xrayTitle'))}</h2><p>${esc(s('xraySub'))}</p></div><span class="v3-hidden-count ${x.hidden?'bad':''}">${x.hidden?`${x.hidden} ${esc(s('hiddenCount'))}`:esc(s('noHidden'))}</span></div><div class="v3-xray-text" dir="auto">${x.html}</div><div class="v3-legend"><span><i class="v3-p"></i>${esc(s('gp'))}</span><span><i class="v3-m"></i>${esc(s('gm'))}</span><span><i class="v3-s"></i>${esc(s('gs'))}</span><span><i class="v3-h"></i>${esc(s('hidden'))}</span></div>
  <div class="v3-actions"><button class="button secondary small" data-v3="attack-current">${icon('alert')}${esc(s('attackThis'))}</button></div></article>
  <article class="card v3-warn"><div><h3>${esc(s('warnTitle'))}</h3><p>${esc(s('warnBody'))}</p></div><blockquote id="v3-warn-text" dir="auto">${esc(warn)}</blockquote><button class="button primary small" data-v3="copy-warn">${icon('message')}${esc(s('copy'))}</button></article></section>`;
 }

 /* ---------- Red Team Arena ---------- */
 const rt={text:'',result:null,busy:false};
 const EXAMPLE={en:'Urgent: your account will be suspended. Enter your password and verification code immediately to keep access.',ar:'عاجل: سيتم إغلاق حسابك. أدخل كلمة المرور ورمز التحقق فورًا للحفاظ على الوصول.',he:'דחוף: החשבון ייסגר. הזינו סיסמה וקוד אימות מיד כדי לשמור על הגישה.'};
 const pill=(o,score)=>`<span class="v3-outcome ${o}"><b>${score}</b>${esc(s(o))}</span>`;
 function bench(){
  const b=RC_DATA.redteam;if(!b||!b.robustness)return '';
  const v2=b.robustness.v2,v3=b.robustness.v3,fp=b.false_positive_guard||{};
  const rows=[...(b.operators||[])].sort((a,c)=>(c.v3.held/c.trials-c.v2.held/c.trials)-(a.v3.held/a.trials-a.v2.held/a.trials));
  const cell=(p,n)=>{const v=Math.round(100*p.held/n);return `<td><span class="v3-heat" style="--v:${v}">${v}%</span></td>`;};
  return `<section class="v3-bench"><article class="card v3-score-card"><div class="eyebrow">${esc(s('benchTitle'))}</div><p>${esc(s('benchSub'))}</p><div class="v3-versus"><div class="v3-big old"><span>${esc(s('engineV2'))}</span><strong dir="ltr">${v2}<small>%</small></strong><i><b style="width:${v2}%"></b></i></div><div class="v3-arrow" aria-hidden="true">→</div><div class="v3-big new"><span>${esc(s('engineV3'))}</span><strong dir="ltr">${v3}<small>%</small></strong><i><b style="width:${v3}%"></b></i></div></div><div class="v3-facts"><div><strong>${b.trials}</strong><span>${esc(s('trials'))}</span></div><div><strong>${b.messages_attacked}</strong><span>${esc(s('messages'))}</span></div><div><strong>${(fp.alerts_v3??0)-(fp.alerts_v2??0)}</strong><span>${esc(s('fpGuard'))} (${fp.benign_texts??0})</span></div></div></article>
  <article class="card v3-table-card"><h3>${esc(s('perOp'))}</h3><div class="v3-table-wrap"><table class="v3-table"><thead><tr><th>${esc(s('operator'))}</th><th>${esc(s('family'))}</th><th>2.0</th><th>3.0</th></tr></thead><tbody>${rows.map(o=>`<tr><td>${esc(o.name[L()]||o.name.en)}</td><td><span class="v3-fam ${o.family}">${esc(s('fam')[o.family])}</span></td>${cell(o.v2,o.trials)}${cell(o.v3,o.trials)}</tr>`).join('')}</tbody></table></div><p class="v3-honest">${icon('info')}${esc(s('honest'))}</p></article></section>`;
 }
 function liveResult(){
  const r=rt.result;if(!r)return '';
  if(!r.attackable)return `<div class="callout">${esc(s('notAttackable'))}</div>`;
  return `<div class="v3-live-summary"><div><span>${esc(s('original'))}</span><strong class="base" dir="ltr">${r.base.score}<small>/100</small></strong></div><div><span>${esc(s('robustThis'))} · ${esc(s('engineV2'))}</span><strong class="old" dir="ltr">${r.robustness.v2}%</strong></div><div><span>${esc(s('robustThis'))} · ${esc(s('engineV3'))}</span><strong class="new" dir="ltr">${r.robustness.v3}%</strong></div></div>
  <div class="v3-attack-grid">${r.rows.map((x,i)=>`<article class="v3-attack ${x.applicable?x.v3.outcome:'na'}" style="--i:${i}"><header><span class="v3-fam ${x.family}">${esc(s('fam')[x.family])}</span><h4>${esc(x.name[L()]||x.name.en)}</h4></header>${x.applicable?`<code class="v3-mutated" dir="auto">${esc(RC_RedTeam.visible(x.mutated).slice(0,190))}</code><footer><div><small>2.0</small>${pill(x.v2.outcome,x.v2.score)}</div><div><small>3.0</small>${pill(x.v3.outcome,x.v3.score)}</div><button class="icon-button v3-xray-btn" data-v3="xray" data-idx="${i}" title="${esc(s('xrayTitle'))}" aria-label="${esc(s('xrayTitle'))}">${icon('search')}</button></footer>`:`<p class="v3-na">${esc(s('na'))}</p>`}</article>`).join('')}</div>`;
 }
 function redteam(){
  if(!rt.text)rt.text=EXAMPLE[L()];
  return `<section class="v3-page"><header class="v3-hero"><div class="eyebrow"><span class="tiny-line"></span>${esc(s('rtEyebrow'))}</div><h1>${esc(s('rtTitle'))}</h1><p>${esc(s('rtBody'))}</p></header>${bench()}
  <section class="card v3-live"><div class="v3-card-head"><div><h2>${esc(s('liveTitle'))}</h2><p>${esc(s('liveSub'))}</p></div><button class="button secondary small" data-v3="example">${icon('flask')}${esc(s('useExample'))}</button></div><textarea id="v3-text" dir="auto" maxlength="2000" aria-label="${esc(s('liveTitle'))}">${esc(rt.text)}</textarea><button class="button primary v3-launch" data-v3="launch" ${rt.text.trim()?'':'disabled'}>${icon('alert')}${esc(s('launch'))}</button><div id="v3-live-result">${liveResult()}</div></section>
  <details class="card v3-explain"><summary>${esc(s('shieldTitle'))}</summary><p>${esc(s('shieldBody'))}</p><code dir="ltr">raw → NFKC → strip invisibles → confusables → leet (in-word) → drop in-word symbols → join spaced letters → rules</code></details></section>`;
 }

 /* ---------- Human vs AI challenge ---------- */
 const ROUNDS=[
  {truth:'legit',text:{en:'Reminder from your bank app: we will never ask for your password or verification code. Report suspicious messages through the official app.',ar:'تذكير من تطبيق البنك: لن نطلب منك أبدًا كلمة المرور أو رمز التحقق. بلّغ عن الرسائل المشبوهة عبر التطبيق الرسمي.',he:'תזכורת מאפליקציית הבנק: לעולם לא נבקש סיסמה או קוד אימות. דווחו על הודעות חשודות דרך האפליקציה הרשמית.'},why:{en:'It mentions passwords — but to warn you. The engine understands negation and warning context.',ar:'تذكر كلمة المرور — لكن للتحذير. المحرك يفهم النفي وسياق التحذير.',he:'היא מזכירה סיסמה — אבל כדי להזהיר. המנוע מבין שלילה והקשר אזהרה.'}},
  {truth:'scam',text:{en:'Your account will be suspended within 24 hours. Enter your password at https://secure-login.example to keep access.',ar:'سيتم إغلاق حسابك خلال 24 ساعة. أدخل كلمة المرور على https://secure-login.example للحفاظ على الوصول.',he:'החשבון ייסגר תוך 24 שעות. הזינו סיסמה בכתובת https://secure-login.example כדי לשמור על הגישה.'},why:{en:'Threat + deadline + password request + link: the classic combination.',ar:'تهديد + مهلة + طلب كلمة مرور + رابط: التركيبة الكلاسيكية.',he:'איום + מועד אחרון + בקשת סיסמה + קישור: השילוב הקלאסי.'}},
  {truth:'scam',text:{en:'Final notice: your parcel is on hold. Pay the redelivery fee and enter your c4rd numb3r at https://parcel-help.example',ar:'إشعار أخير: طردك متوقف. ادفع رسوم التوصيل، ثم أدخل کلمة السر على https://parcel-help.example',he:'הודעה אחרונה: החבילה מעוכבת. שלמו דמי משלוח, ואז הזינו מספר כר*טיס בכתובת https://parcel-help.example'},why:{en:'Disguised characters (4→a, 3→e) hide the request from 2.0 filters. The 3.0 Evasion Shield sees through them.',ar:'حرف فارسي متنكر (ک بدل ك) يخفي الطلب عن فلاتر 2.0. درع التمويه في 3.0 يكشفه.',he:'סימן שהוחדר לתוך המילה מסתיר את הבקשה ממסנני 2.0. מגן ההסוואה של 3.0 רואה דרכו.'}},
  {truth:'legit',text:{en:'Urgent: tomorrow’s exam has moved to hall B at 9:00. Details are on the course page.',ar:'عاجل: امتحان الغد انتقل إلى القاعة B الساعة 9:00. التفاصيل على صفحة المساق.',he:'דחוף: הבחינה של מחר עברה לאולם B בשעה 9:00. פרטים באתר הקורס.'},why:{en:'“Urgent” alone is not a scam. No request for money, codes or access — the engine keeps it low.',ar:'كلمة "عاجل" وحدها ليست احتيالًا. لا طلب لمال أو رموز أو وصول — فيبقى المؤشر منخفضًا.',he:'"דחוף" לבדו אינו הונאה. אין בקשה לכסף, קודים או גישה — המדד נשאר נמוך.'}},
  {truth:'scam',text:{en:'Hi mom, I lost my phone and this is my new number. Can you transfer 2,000 to my friend’s account today? I’ll explain later.',ar:'ماما، ضاع تلفوني وهذا رقمي الجديد. بتقدري تحوّلي 2000 شيكل لحساب صاحبي اليوم؟ بشرحلك بعدين.',he:'אמא, הטלפון שלי נאבד וזה המספר החדש שלי. תוכלי להעביר 2,000 ₪ לחשבון של חבר שלי היום? אסביר אחר כך.'},why:{en:'The “hi mom” scam: no link, no password — only emotion. Rules miss it, but Manipulation DNA lights up kindness + time pressure. This is where semantic models come next.',ar:'احتيال "ماما": لا رابط ولا كلمة مرور — فقط عاطفة. القواعد تفوّته، لكن البصمة النفسية تكشف استغلال العاطفة وضغط الوقت. هنا يأتي دور النماذج الدلالية.',he:'הונאת "היי אמא": בלי קישור ובלי סיסמה — רק רגש. הכללים מפספסים, אבל טביעת האצבע הפסיכולוגית מזהה ניצול רגשי ולחץ זמן. כאן נכנסים מודלים סמנטיים.'}},
  {truth:'scam',text:{en:'Congratulations, you have won a prize! Pay the processing fee with gift cards to claim it. Don’t tell anyone.',ar:'مبروك، ربحت جائزة! ادفع رسوم الاستلام ببطاقات هدايا. لا تخبر أحدًا.',he:'מזל טוב, זכית בפרס! שלמו את דמי הטיפול בכרטיסי מתנה. אל תספר לאף אחד.'},why:{en:'Greed + unusual payment + secrecy. Gift cards are never a legitimate fee.',ar:'طمع + طريقة دفع غير معتادة + سرية. بطاقات الهدايا ليست وسيلة دفع رسمية أبدًا.',he:'חמדנות + אמצעי תשלום חריג + סודיות. כרטיסי מתנה לעולם אינם תשלום לגיטימי.'}},
  {truth:'legit',text:{en:'Your receipt for order 4821 is ready. Thank you for shopping with us.',ar:'إيصال طلبك رقم 4821 جاهز. شكرًا لتسوقك معنا.',he:'הקבלה להזמנה 4821 מוכנה. תודה שקניתם אצלנו.'},why:{en:'No request, no pressure, no link. Ordinary.',ar:'لا طلب ولا ضغط ولا رابط. رسالة عادية.',he:'אין בקשה, אין לחץ, אין קישור. רגילה.'}},
  {truth:'scam',text:{en:'Tech support here: your computer is infected. Install AnyDesk immediately so our technician can fix it.',ar:'هنا الدعم الفني: جهازك مصاب بفيروس. نزّل AnyDesk فورًا حتى يصلحه الفني.',he:'כאן התמיכה הטכנית: המחשב שלך נגוע. התקן AnyDesk מיד כדי שהטכנאי יתקן.'},why:{en:'Fake authority + fear + remote-access tool = full control of your device.',ar:'سلطة مزيفة + تخويف + برنامج تحكم عن بعد = سيطرة كاملة على جهازك.',he:'סמכות מזויפת + הפחדה + כלי שליטה מרחוק = שליטה מלאה במכשיר.'}}
 ];
 const ar={round:-1,vote:null,human:0,engine:0,report:null};
 function arenaRound(){
  const q=ROUNDS[ar.round],text=q.text[L()];
  if(ar.vote&&!ar.report)ar.report=RC.analyze({text,language:L()});
  const r=ar.report,engineSays=r?(r.score>=25?'scam':'legit'):null;
  const fake=r?{...r,original_text:text}:null;
  return `<div class="v3-arena-top"><span>${esc(s('round'))} ${ar.round+1} ${esc(s('of'))} ${ROUNDS.length}</span><div class="v3-progress">${ROUNDS.map((_,i)=>`<i class="${i<ar.round?'done':i===ar.round?'now':''}"></i>`).join('')}</div><div class="v3-scoreboard"><div><span>${esc(s('humans'))}</span><strong>${ar.human}</strong></div><div><span>${esc(s('engine'))}</span><strong>${ar.engine}</strong></div></div></div>
  <article class="card v3-round"><div class="v3-phone"><div class="v3-bubble" dir="auto">${r?xray(fake).html:esc(text)}</div></div>
  ${!ar.vote?`<div class="v3-vote"><span>${esc(s('vote'))}</span><button class="v3-choice scam" data-v3="vote" data-choice="scam">🚩 ${esc(s('scam'))}</button><button class="v3-choice legit" data-v3="vote" data-choice="legit">✓ ${esc(s('legit'))}</button></div>`:
  `<div class="v3-reveal"><div class="v3-verdicts"><div class="${ar.vote===q.truth?'ok':'bad'}"><span>${esc(s('humans'))}</span><strong>${esc(s(ar.vote))}</strong><em>${esc(s(ar.vote===q.truth?'correct':'wrong'))}</em></div><div class="truth"><span>${esc(s('truth'))}</span><strong>${esc(s(q.truth))}</strong></div><div class="${engineSays===q.truth?'ok':'bad'}"><span>${esc(s('engineSays'))} · <b dir="ltr">${r.score}/100</b></span><strong>${esc(s(engineSays))}</strong><em>${esc(s(engineSays===q.truth?'correct':'wrong'))}</em></div></div>
  <p class="v3-why"><b>${esc(s('why'))}</b> ${esc(q.why[L()])}</p>${r.signals.filter(x=>x.weight).length?`<div class="v3-chips">${r.signals.filter(x=>x.weight).map(x=>`<span>${esc(x.title)} <b>+${x.weight}</b></span>`).join('')}</div>`:''}
  <button class="button primary" data-v3="next">${esc(s(ar.round===ROUNDS.length-1?'finish':'next'))}</button></div>`}</article>`;
 }
 function arena(){
  let body;
  if(ar.round<0)body=`<div class="v3-arena-start"><button class="button primary v3-launch" data-v3="arena-start">${icon('spark')}${esc(s('start'))}</button><small>${ROUNDS.length} · ${esc(s('synthetic'))}</small></div>`;
  else if(ar.round>=ROUNDS.length)body=`<article class="card v3-final"><div class="eyebrow">${esc(s('finalTitle'))}</div><div class="v3-final-score"><div><span>${esc(s('humans'))}</span><strong>${ar.human}<small>/${ROUNDS.length}</small></strong></div><em>vs</em><div><span>${esc(s('engine'))}</span><strong>${ar.engine}<small>/${ROUNDS.length}</small></strong></div></div><p>${esc(s('finalBody'))}</p><button class="button secondary" data-v3="arena-start">${esc(s('again'))}</button></article>`;
  else body=arenaRound();
  return `<section class="v3-page v3-arena"><header class="v3-hero"><div class="eyebrow"><span class="tiny-line"></span>${esc(s('arEyebrow'))}</div><h1>${esc(s('arTitle'))}</h1><p>${esc(s('arBody'))}</p></header>${body}</section>`;
 }


 /* ---------- Smart Check: one input (message / link / phone / screenshot), automatic multi-source investigation, one big answer ---------- */
 const Q={
  ar:{nav:'فحص سريع',title:'شاكك برابط أو ملف؟',sub:'الصق الرابط أو الرسالة، أو اختار ملف — واكبس افحص.',ph:'الصق هون رابط أو رسالة...',btn:'افحص',img:'صورة',imgRemove:'شيل الصورة',again:'افحص إشي ثاني',more:'شوف التفاصيل',why:'ليش؟',
   kinds:{message:'💬 رسالة',url:'🔗 رابط',phone:'📞 رقم تلفون',image:'🖼️ صورة'},investigating:'عم نحقق...',realSite:'🔗 الموقع الحقيقي:',
   high:'نعم — على الأغلب احتيال',review:'مشكوك فيها — تأكد قبل ما تتصرف',limited:'لا — ما لقينا علامات احتيال',unknown:'ما لقينا إشي غريب بالرقم — بس هاد مش ضمان',unread:'ما قدرنا نقرأ الصورة',doUnread:'جرّب صورة أوضح، أو انسخ نص الرسالة والصقه بالمربع.',
   doHigh:'لا تضغط على الرابط، لا تدفع، ولا تبعت أي رمز.',doReview:'لا تضغط على الرابط. ادخل على الموقع أو التطبيق الرسمي بنفسك وتأكد.',doLimited:'بس ضل منتبه: إذا حدا طلب منك مصاري أو رمز، تأكد من الجهة الرسمية.',doUnknown:'ما منقدر نعرف مين صاحب الرقم بدون فحص خارجي. إذا بيطلب منك مصاري أو رموز، لا تتعامل معه.',
   local:'الفحص بصير على جهازك. الرسالة ما بتنبعت لأي مكان.',sources:'وين دوّرنا؟',
   st:{ai:'الذكاء الاصطناعي المحلي',content:'كلام الرسالة',links:'الروابط',identity:'هوية الجهة المرسلة',phone:'رقم التلفون',image:'الصورة',hidden:'حروف مخفية وتمويه',external:'فحص خارجي (سمعة المواقع والأرقام)'},
   ok:'سليم',warn:'مشبوه',na:'مش موجود',off:'مش مفعّل بهاي النسخة',
   d:{mlCaution:'أسلوب الكتابة بيشبه رسائل الاحتيال',mlOk:'أسلوب الكتابة عادي',noLink:'ما في رابط',noPhone:'ما في رقم',noEntity:'ما ذكرت جهة معروفة',entityOk:e=>`${e} — الرابط رسمي`,hidden:n=>`${n} حرف مخفي أو متنكر`,phone:(p,c)=>`${p}${c?' · '+c:''}`,
     imgText:n=>`قرأنا ${n} حرف من الصورة`,imgQR:n=>`لقينا ${n} رمز QR`,imgNone:'ما لقينا نص بالصورة',imgFail:'قراءة الصور بتحتاج إنترنت أول مرة لتحميل أداة القراءة. الصورة نفسها ما بتطلع من جهازك.',imgLoading:p=>`عم نقرأ الصورة... ${p}%`},
   pf:{phone_special:'رقم من نطاق دولي خاص (أقمار صناعية/شبكات دولية/خدمات مدفوعة) — نادرًا ما يستعمله أشخاص أو شركات حقيقية',phone_premium:'رقم خدمة مدفوعة (1-900) — المكالمة ممكن تكلفك مصاري',phone_local_entity_foreign:c=>`الرسالة بتدّعي إنها من جهة محلية، بس الرقم مسجّل في ${c}`,link_brand:e=>`اسم ${e} مزروع داخل رابط مش إلها`,pay_page:'الرابط بيودّي لصفحة دفع أو تسجيل دخول على موقع مجهول',risky_tld:t=>`نهاية الموقع (.${t}) رخيصة ومنتشرة كثير بروابط الاحتيال`,deep_sub:d=>`اسم الموقع الحقيقي مخبّى بآخر الرابط: ${d}`,odd_name:'اسم الموقع مركّب بشكل غريب (شَرطات أو أرقام كثير)',ml_pattern:'الذكاء الاصطناعي المحلي لقى أسلوب كتابة بيشبه رسائل الاحتيال',short_hidden:'رابط مختصر — ما بنقدر نشوف لوين بيودّي فعليًا'}},
  he:{nav:'בדיקה מהירה',title:'חושדים בקישור או בקובץ?',sub:'הדביקו קישור או הודעה, או בחרו קובץ — ולחצו בדיקה.',ph:'הדביקו כאן קישור או הודעה...',btn:'בדיקה',img:'תמונה',imgRemove:'הסרת התמונה',again:'בדיקה נוספת',more:'לפרטים המלאים',why:'למה?',
   kinds:{message:'💬 הודעה',url:'🔗 קישור',phone:'📞 מספר טלפון',image:'🖼️ תמונה'},investigating:'חוקרים...',realSite:'🔗 האתר האמיתי:',
   high:'כן — כנראה הונאה',review:'חשודה — בדקו לפני שפועלים',limited:'לא — לא נמצאו סימני הונאה',unknown:'לא מצאנו משהו חריג במספר — אבל זו לא ערובה',unread:'לא הצלחנו לקרוא את התמונה',doUnread:'נסו תמונה ברורה יותר, או העתיקו את טקסט ההודעה והדביקו בתיבה.',
   doHigh:'אל תלחצו על הקישור, אל תשלמו ואל תמסרו שום קוד.',doReview:'אל תלחצו על הקישור. היכנסו בעצמכם לאתר או לאפליקציה הרשמיים ובדקו.',doLimited:'רק שימו לב: אם מבקשים מכם כסף או קוד, ודאו מול הגוף הרשמי.',doUnknown:'אי אפשר לדעת למי שייך המספר בלי בדיקה חיצונית. אם מבקשים מכם כסף או קודים, אל תשתפו פעולה.',
   local:'הבדיקה מתבצעת במכשיר שלכם. ההודעה לא נשלחת לשום מקום.',sources:'איפה חיפשנו?',
   st:{ai:'בינה מלאכותית מקומית',content:'תוכן ההודעה',links:'קישורים',identity:'זהות השולח',phone:'מספר טלפון',image:'תמונה',hidden:'תווים מוסתרים והסוואה',external:'בדיקה חיצונית (מוניטין אתרים ומספרים)'},
   ok:'תקין',warn:'חשוד',na:'לא קיים',off:'לא פעיל בגרסה זו',
   d:{mlCaution:'סגנון הכתיבה דומה להודעות הונאה',mlOk:'סגנון כתיבה רגיל',noLink:'אין קישור',noPhone:'אין מספר',noEntity:'לא הוזכר גוף מוכר',entityOk:e=>`${e} — הקישור רשמי`,hidden:n=>`${n} תווים מוסתרים או מתחזים`,phone:(p,c)=>`${p}${c?' · '+c:''}`,
     imgText:n=>`קראנו ${n} תווים מהתמונה`,imgQR:n=>`מצאנו ${n} קודי QR`,imgNone:'לא נמצא טקסט בתמונה',imgFail:'קריאת תמונות דורשת אינטרנט בפעם הראשונה כדי לטעון את כלי הקריאה. התמונה עצמה לא יוצאת מהמכשיר.',imgLoading:p=>`קוראים את התמונה... ${p}%`},
   pf:{phone_special:'מספר מטווח בינלאומי מיוחד (לוויין/רשתות בינלאומיות/שירות בתשלום) — כמעט לא בשימוש אנשים או חברות אמיתיים',phone_premium:'מספר שירות בתשלום (1-900) — השיחה עלולה לעלות כסף',phone_local_entity_foreign:c=>`ההודעה מתחזה לגוף מקומי, אבל המספר רשום ב${c}`,link_brand:e=>`השם ${e} שתול בתוך קישור שאינו שלו`,pay_page:'הקישור מוביל לדף תשלום או התחברות באתר לא מוכר',risky_tld:t=>`סיומת האתר (.${t}) זולה ונפוצה מאוד בקישורי הונאה`,deep_sub:d=>`שם האתר האמיתי מוסתר בסוף הקישור: ${d}`,odd_name:'שם האתר מורכב בצורה חשודה (הרבה מקפים או ספרות)',ml_pattern:'הבינה המלאכותית המקומית זיהתה סגנון כתיבה של הודעות הונאה',short_hidden:'קישור מקוצר — אי אפשר לראות לאן הוא מוביל באמת'}},
  en:{nav:'Quick check',title:'Suspicious link or file?',sub:'Paste the link or message, or choose a file — then tap Check.',ph:'Paste a link or message here...',btn:'Check',img:'Image',imgRemove:'Remove image',again:'Check something else',more:'See the details',why:'Why?',
   kinds:{message:'💬 Message',url:'🔗 Link',phone:'📞 Phone number',image:'🖼️ Image'},investigating:'Investigating...',realSite:'🔗 The real site:',
   high:'Yes — likely a scam',review:'Suspicious — check before acting',limited:'No — no scam signs found',unknown:'Nothing unusual about the number — but that is no guarantee',unread:'We couldn\u2019t read the image',doUnread:'Try a clearer image, or copy the message text and paste it in the box.',
   doHigh:'Don’t tap the link, don’t pay, and don’t send any code.',doReview:'Don’t tap the link. Open the official website or app yourself and check.',doLimited:'Stay alert: if anyone asks for money or a code, confirm with the official organization.',doUnknown:'We can’t tell who owns a number without an external lookup. If they ask for money or codes, don’t engage.',
   local:'The check runs on your device. The message is not sent anywhere.',sources:'Where we looked',
   st:{ai:'Local AI model',content:'Message content',links:'Links',identity:'Sender identity',phone:'Phone number',image:'Image',hidden:'Hidden characters & disguise',external:'External lookup (site and number reputation)'},
   ok:'Clean',warn:'Suspicious',na:'Not present',off:'Not enabled in this version',
   d:{mlCaution:'Writing style resembles scam messages',mlOk:'Ordinary writing style',noLink:'No link',noPhone:'No number',noEntity:'No well-known organization named',entityOk:e=>`${e} — official link`,hidden:n=>`${n} hidden or disguised characters`,phone:(p,c)=>`${p}${c?' · '+c:''}`,
     imgText:n=>`Read ${n} characters from the image`,imgQR:n=>`Found ${n} QR code(s)`,imgNone:'No text found in the image',imgFail:'Reading images needs internet the first time to load the reader. The image itself never leaves your device.',imgLoading:p=>`Reading the image... ${p}%`},
   pf:{phone_special:'Number from a special international range (satellite/international networks/premium) — rarely used by real people or companies',phone_premium:'Premium-rate number (1-900) — calling may cost you money',phone_local_entity_foreign:c=>`The message claims to be a local organization, but the number is registered in ${c}`,link_brand:e=>`The name ${e} is planted inside a link it does not own`,pay_page:'The link leads to a payment or login page on an unknown site',risky_tld:t=>`The site ending (.${t}) is cheap and common in scam links`,deep_sub:d=>`The real site is hidden at the end of the link: ${d}`,odd_name:'The site name is oddly built (many hyphens or digits)',ml_pattern:'The local AI model found a writing style typical of scam messages',short_hidden:'Shortened link — we cannot see where it really leads'}}
 };
 const q=k=>Q[L()][k];
 const SIMPLE=()=>document.body.classList.contains('rc-simple');
 const qs={text:'',file:null,image:null,imageName:'',result:null,steps:null,running:false,imgNote:''};
 const OCR_LIB='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js',QR_LIB='https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js';
 const loadScript=src=>new Promise((ok,fail)=>{if(document.querySelector(`script[src="${src}"]`))return ok();const s=document.createElement('script');s.src=src;s.async=true;s.crossOrigin='anonymous';s.onload=()=>ok();s.onerror=()=>fail(new Error('load'));document.head.appendChild(s);});
 const withTimeout=(p,ms)=>Promise.race([p,new Promise((_,f)=>setTimeout(()=>f(new Error('timeout')),ms))]);
 async function imageCanvas(dataUrl){const img=new Image();img.src=dataUrl;await img.decode();const k=Math.min(1,1600/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);c.getContext('2d').drawImage(img,0,0,c.width,c.height);return c;}
 async function readImage(dataUrl,onProgress){
  const canvas=await imageCanvas(dataUrl),out={text:'',qr:[],failed:false};
  try{ // QR codes: native detector when the browser has one, otherwise jsQR.
   if('BarcodeDetector' in window){const det=new window.BarcodeDetector({formats:['qr_code']});out.qr=(await det.detect(canvas)).map(x=>x.rawValue).filter(Boolean);}
   else{await withTimeout(loadScript(QR_LIB),15000);const d=canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height);const r=window.jsQR(d.data,d.width,d.height);if(r?.data)out.qr=[r.data];}
  }catch{}
  try{ // Text: Tesseract runs in this browser; only the reader's model files are downloaded.
   await withTimeout(loadScript(OCR_LIB),20000);
   const langs={ar:'ara+eng',he:'heb+eng',en:'eng'}[L()];
   const worker=await withTimeout(window.Tesseract.createWorker(langs,1,{logger:m=>{if(m.status==='recognizing text')onProgress(Math.round(m.progress*100));}}),60000);
   const {data}=await withTimeout(worker.recognize(canvas),90000);await worker.terminate();out.text=(data.text||'').trim();
  }catch{out.failed=true;}
  return out;
 }
 const URL_GROUP_CODES=new Set(['domain_mismatch','lookalike','brand_bait','claimed_mismatch','claimed_bait','userinfo']);
 function buildResult(text,kind,img){
  const lang=L(),a=String(text).trim()?RC.analyze({text,language:lang,input_type:kind==='url'?'url':'message'}):{score:0,verdict:'limited',signals:[],urls:[],claimed_entity:null,original_text:'',language:lang,input_type:'message'};
  const plist=RC_Smart.phones(text),pf=RC_Smart.phoneFindings(plist,a.claimed_entity);
  if(!a.signals.some(x=>x.code==='claimed_bait'||x.code==='claimed_mismatch'))pf.push(...RC_Smart.linkBrandFindings(a.urls,RC_DATA.entities));
  pf.push(...RC_Smart.linkFindings(a.urls,RC_DATA.entities));
  if(a.signals.some(x=>x.code==='shortener'))pf.push({code:'short_hidden',weight:15});
  // Local machine-learning model (runs in the browser): can lift a message the rules scored low into "check first".
  const ml=a.ml||{},mlCaution=kind!=='phone'&&ml.status==='completed'&&ml.label==='caution_pattern'&&(ml.coverage||0)>=0.3;
  if(mlCaution&&a.score+pf.reduce((t,f)=>t+f.weight,0)<25)pf.push({code:'ml_pattern',weight:25});
  const extra=pf.reduce((s,f)=>s+f.weight,0),score=Math.min(100,a.score+extra);
  let verdict=RC_Smart.verdictOf(score);if(kind==='phone'&&!pf.length&&!a.signals.some(x=>x.weight))verdict='unknown';
  if(img&&!String(text).trim())verdict='unread';
  const sig=a.signals.filter(x=>x.weight),x=xray({...a,original_text:text}),D=q('d');
  const ent=a.claimed_entity?(RC_DATA.entities?.entities||[]).find(e=>e.id===a.claimed_entity):null;
  const steps=[
   {id:'content',status:kind==='phone'||kind==='url'?'na':sig.some(s=>['pressure','money','secrets'].includes(s.group))?'warn':'ok',detail:sig.filter(s=>['pressure','money','secrets'].includes(s.group)).map(s=>s.title).slice(0,2).join(' · ')},
   {id:'links',status:a.urls.length?(sig.some(s=>s.group==='url'||URL_GROUP_CODES.has(s.code))||pf.some(f=>['link_brand','pay_page','risky_tld','deep_sub','odd_name'].includes(f.code))?'warn':'ok'):'na',detail:a.urls.length?a.urls.map(u=>u.host).slice(0,2).join(' · '):D.noLink},
   {id:'identity',status:sig.some(s=>URL_GROUP_CODES.has(s.code))||pf.some(f=>f.code==='phone_local_entity_foreign'||f.code==='link_brand')?'warn':ent?'ok':'na',detail:pf.find(f=>f.code==='phone_local_entity_foreign')?q('pf').phone_local_entity_foreign(pf.find(f=>f.code==='phone_local_entity_foreign').phone.country?.[lang]||''):pf.find(f=>f.code==='link_brand')?`${pf.find(f=>f.code==='link_brand').entity.name[lang]} · ${pf.find(f=>f.code==='link_brand').host}`:ent?(sig.some(s=>URL_GROUP_CODES.has(s.code))?sig.filter(s=>URL_GROUP_CODES.has(s.code))[0].evidence:D.entityOk(ent.name[lang])):D.noEntity},
   {id:'phone',status:plist.length?(pf.length?'warn':'ok'):'na',detail:plist.length?plist.slice(0,2).map(p=>D.phone(p.e164,p.country?.[lang]||'')).join(' · '):D.noPhone},
   ...(img?[{id:'image',status:img.failed&&!img.qr.length?'off':(img.qr.length?'warn':'ok'),detail:img.failed&&!img.qr.length?D.imgFail:[img.text?D.imgText(img.text.length):D.imgNone,img.qr.length?D.imgQR(img.qr.length):''].filter(Boolean).join(' · ')}]:[]),
   {id:'hidden',status:x.hidden?'warn':'ok',detail:x.hidden?D.hidden(x.hidden):''},
   {id:'ai',status:ml.status==='completed'?(mlCaution?'warn':'ok'):'na',detail:ml.status==='completed'?(mlCaution?D.mlCaution:D.mlOk):''},
  ];
  if(img?.qr.length&&steps.find(s=>s.id==='image').status==='warn'&&!sig.length)steps.find(s=>s.id==='image').status='ok';
  const LINK_T={short_hidden:f=>q('pf').short_hidden,pay_page:f=>q('pf').pay_page,risky_tld:f=>q('pf').risky_tld(f.tld),deep_sub:f=>q('pf').deep_sub(f.real),odd_name:f=>q('pf').odd_name,ml_pattern:f=>q('pf').ml_pattern};
  const reasons=[...pf.map(f=>({w:f.weight,t:LINK_T[f.code]?LINK_T[f.code](f):f.code==='link_brand'?q('pf').link_brand(f.entity.name[lang]):typeof q('pf')[f.code]==='function'?q('pf')[f.code](f.phone.country?.[lang]||f.phone.e164):q('pf')[f.code]})),...sig.map(s=>({w:s.weight,t:s.title}))].sort((m,n)=>n.w-m.w).slice(0,3).map(r=>r.t);
  const realSites=[...new Set(a.urls.map(u=>RC_Smart.realDomain(u.host)).filter(Boolean))].slice(0,2);
  return {report:{...a,score,verdict:['unknown','unread'].includes(verdict)?'limited':verdict},verdict,score,reasons,steps,kind,realSites};
 }
 /* ---------- Examples and "warn your family" (no external services) ---------- */
 const VQ={
  ar:{warn:'حذّر أهلك',examples:'جرّب مثال:',ex:[['🔗 رابط دفع','https://paypa1-secure-billing.xyz/visa/verify'],['🚓 مخالفة','تنبيه من الشرطة: عليك مخالفة سير غير مدفوعة بقيمة 250 شيكل. ادفع خلال 24 ساعة عبر الرابط https://police-fines-pay.example'],['📦 طرد','بريد إسرائيل: طردك متوقف. اتصل فورًا على +44 7700 900123 وادفع رسوم التوصيل عبر https://israelpost-delivery.example'],['👩 ماما ضاع تلفوني','ماما، ضاع تلفوني وهذا رقمي الجديد. بتقدري تحوّلي 2000 شيكل لحساب صاحبي اليوم؟ بشرحلك بعدين.']]},
  he:{warn:'הזהירו את המשפחה',examples:'נסו דוגמה:',ex:[['🔗 קישור תשלום','https://paypa1-secure-billing.xyz/visa/verify'],['🚓 דוח','משטרת ישראל: יש לך דוח תנועה שלא שולם. שלמו תוך 24 שעות בקישור https://police-fines-pay.example'],['📦 חבילה','דואר ישראל: החבילה שלך מעוכבת. שלמו דמי משלוח בקישור https://israelpost-delivery.example'],['👩 היי אמא','אמא, הטלפון שלי נאבד וזה המספר החדש שלי. תוכלי להעביר 2,000 ₪ לחשבון של חבר שלי היום? אסביר אחר כך.']]},
  en:{warn:'Warn your family',examples:'Try an example:',ex:[['🔗 Payment link','https://paypa1-secure-billing.xyz/visa/verify'],['🚓 Fine','Police notice: you have an unpaid traffic fine. Pay within 24 hours at https://police-fines-pay.example'],['📦 Parcel','Netflix: your payment failed. Update your card number at https://netflix-billing.example'],['👩 Hi mom','Hi mom, I lost my phone and this is my new number. Can you transfer 2,000 to my friend’s account today? I’ll explain later.']]}
 };
 const vq=k=>VQ[L()][k];

 const HOW={ar:['كيف بيشتغل؟',[['📋','الصق','رسالة، رابط، رقم أو صورة'],['🔍','بنفحص','الكلام، الرابط، مين المرسل والرقم'],['✅','بنجاوبك','نعم، مشكوك أو لا — ومعها شو تعمل']]],
  he:['איך זה עובד?',[['📋','מדביקים','הודעה, קישור, מספר או תמונה'],['🔍','בודקים','התוכן, הקישור, השולח והמספר'],['✅','עונים','כן, חשוד או לא — ומה לעשות']]],
  en:['How it works',[['📋','Paste','a message, link, number or image'],['🔍','We check','the words, the link, the sender and the number'],['✅','You get an answer','yes, suspicious or no — and what to do']]]};
 function howHtml(){const [title,steps]=HOW[L()];return `<div class="v3-how"><b>${esc(title)}</b><ol>${steps.map(([e,t1,t2])=>`<li><span aria-hidden="true">${e}</span><div><strong>${esc(t1)}</strong><small>${esc(t2)}</small></div></li>`).join('')}</ol></div>`;}
 function examplesHtml(){return `<div class="v3-examples"><span>${esc(vq('examples'))}</span>${vq('ex').map(([label],i)=>`<button class="v3-ex" data-v3="example-fill" data-i="${i}" type="button">${esc(label)}</button>`).join('')}</div>`;}
 function answerActions(r){return ['high','review'].includes(r.verdict)?`<div class="v3-answer-actions"><button class="v3-act" data-v3="quick-warn" type="button">📣 <span>${esc(vq('warn'))}</span></button></div>`:'';}
 const QW={ar:(w)=>`⚠️ انتبه: وصلتني رسالة على الأغلب احتيال.${w?` بتطلب ${w}.`:''} لا تضغط على روابطها، لا تحوّل مصاري، ولا تشارك أي رمز — تأكد من الجهة عبر رقمها أو تطبيقها الرسمي.`,he:(w)=>`⚠️ שימו לב: קיבלתי הודעה שכנראה היא הונאה.${w?` היא מבקשת ${w}.`:''} אל תלחצו על קישורים, אל תעבירו כסף ואל תמסרו קודים — ודאו מול הגוף דרך המספר או האפליקציה הרשמיים.`,en:(w)=>`⚠️ Heads-up: I got a message that is likely a scam.${w?` It asks for ${w}.`:''} Don’t tap its links, don’t send money and don’t share any code — check with the organization through its official number or app.`};
 function quickWarn(r){const d=dna(r.report);return QW[L()](d.wants.map(k=>s('want')[k]).join(' + '));}

 const FQ={
  ar:{btn:'ملف أو صورة',kind:'📄 ملف',st:'الملف',ok:t=>`نوع الملف: ${t} — ما في إشي نشط أو مخفي`,caveat:'هاد فحص لشكل الملف ومحتواه، مش برنامج حماية من الفيروسات.',vt:'افحص بصمة الملف على VirusTotal',vtNote:'(بيبعت البصمة بس، مش الملف)',
   high:'نعم — الملف خطير على الأغلب',review:'مشكوك — لا تفتحه قبل ما تتأكد',limited:'ما لقينا إشي خطير بالملف',
   doHigh:'لا تفتح الملف، وامسحه. وإذا فتحته، افصل الإنترنت وافحص جهازك ببرنامج حماية.',doReview:'لا تفتحه قبل ما تتأكد من الشخص اللي بعته، بمكالمة مش برسالة.',doLimited:'بس افتح ملفات بس من ناس بتعرفهم، وانتبه لأي طلب بعد ما تفتحه.',
   f:{program:e=>`هاد ملف برنامج (.${e}) — لما تفتحه بيقدر يشغّل أوامر على جهازك`,apk:'تطبيق أندرويد من برّا المتجر — طريقة منتشرة لزرع برامج تجسس',double_ext:(sh,r)=>`اسم الملف مزوّر: بيبيّن إنه "${sh}" بس هو فعليًا .${r}`,rtlo_name:'اسم الملف فيه حرف مخفي بيقلب الكتابة عشان يخبّي نوعه الحقيقي',type_mismatch:(e,r)=>`الملف بيدّعي إنه .${e} بس محتواه الحقيقي ${r.toUpperCase()}`,macro:'ملف Office فيه ماكرو (أوامر برمجية) — من أشهر طرق الاختراق',archive_exec:n=>`الملف المضغوط فيه برنامج: ${n}`,encrypted:'ملف مضغوط بكلمة سر — طريقة لتهريب برامج خبيثة من الفحص',pdf_active:'ملف PDF فيه أوامر بتشتغل لحالها (JavaScript أو تشغيل ملفات)',html_phish:'صفحة ويب جوّا ملف فيها خانة كلمة سر أو بطاقة — طريقة منتشرة لسرقة الحسابات',html_script:'ملف فيه كود مخفي بيشتغل لما تفتحه'}},
  he:{btn:'קובץ או תמונה',kind:'📄 קובץ',st:'הקובץ',ok:t=>`סוג הקובץ: ${t} — אין תוכן פעיל או מוסתר`,caveat:'זו בדיקה של מבנה ותוכן הקובץ, לא אנטי-וירוס.',vt:'בדקו את טביעת הקובץ ב-VirusTotal',vtNote:'(נשלחת רק הטביעה, לא הקובץ)',
   high:'כן — הקובץ כנראה מסוכן',review:'חשוד — אל תפתחו לפני שבדקתם',limited:'לא מצאנו משהו מסוכן בקובץ',
   doHigh:'אל תפתחו את הקובץ ומחקו אותו. אם פתחתם, נתקו את האינטרנט וסרקו את המחשב באנטי-וירוס.',doReview:'אל תפתחו לפני שווידאתם עם השולח, בשיחה ולא בהודעה.',doLimited:'פתחו קבצים רק מאנשים שאתם מכירים, ושימו לב לכל בקשה אחרי הפתיחה.',
   f:{program:e=>`זה קובץ תוכנה (.${e}) — פתיחה שלו יכולה להריץ פקודות במחשב`,apk:'אפליקציית אנדרואיד מחוץ לחנות — דרך נפוצה להשתלת רוגלות',double_ext:(sh,r)=>`שם הקובץ מזויף: נראה כמו "${sh}" אבל בפועל .${r}`,rtlo_name:'בשם הקובץ יש תו מוסתר שהופך את הכתיבה כדי להסתיר את הסוג האמיתי',type_mismatch:(e,r)=>`הקובץ מתחזה ל-.${e} אבל התוכן האמיתי הוא ${r.toUpperCase()}`,macro:'קובץ Office עם מאקרו (פקודות תוכנה) — מדרכי הפריצה הנפוצות',archive_exec:n=>`בקובץ הדחוס יש תוכנה: ${n}`,encrypted:'קובץ דחוס עם סיסמה — דרך להבריח תוכנות זדוניות מבדיקה',pdf_active:'קובץ PDF עם פקודות שרצות לבד (JavaScript או הפעלת קבצים)',html_phish:'דף אינטרנט בתוך קובץ עם שדה סיסמה או כרטיס — דרך נפוצה לגניבת חשבונות',html_script:'בקובץ יש קוד מוסתר שרץ בפתיחה'}},
  en:{btn:'File or image',kind:'📄 File',st:'The file',ok:t=>`File type: ${t} — no active or hidden content`,caveat:'This checks the file’s structure and content; it is not an antivirus scan.',vt:'Check the file fingerprint on VirusTotal',vtNote:'(sends only the fingerprint, not the file)',
   high:'Yes — the file is likely dangerous',review:'Suspicious — don’t open it until you check',limited:'Nothing dangerous found in the file',
   doHigh:'Don’t open the file; delete it. If you opened it, disconnect from the internet and scan your device with antivirus.',doReview:'Don’t open it until you confirm with the sender — by a call, not a message.',doLimited:'Only open files from people you know, and be careful with any request after opening.',
   f:{program:e=>`This is a program file (.${e}) — opening it can run commands on your device`,apk:'An Android app from outside the store — a common way to plant spyware',double_ext:(sh,r)=>`Fake file name: it looks like "${sh}" but it is really .${r}`,rtlo_name:'The file name hides a character that reverses text to disguise its real type',type_mismatch:(e,r)=>`The file claims to be .${e} but its real content is ${r.toUpperCase()}`,macro:'An Office file with macros (program code) — one of the most common attack methods',archive_exec:n=>`The archive contains a program: ${n}`,encrypted:'A password-protected archive — used to sneak malware past scanners',pdf_active:'A PDF with commands that run by themselves (JavaScript or launching files)',html_phish:'A web page inside a file with a password or card field — a common account-theft trick',html_script:'The file contains hidden code that runs when opened'}}
 };
 const fq=k=>FQ[L()][k];
 for(const lang of ['ar','he','en'])Q[lang].st.file=FQ[lang].st;
 function fileReason(x){const f=fq('f')[x.code];if(typeof f!=='function')return f;if(x.code==='program')return f(x.ext);if(x.code==='double_ext')return f(x.shown,x.real);if(x.code==='type_mismatch')return f(x.ext,x.real);if(x.code==='archive_exec')return f(x.names.join(', '));return f();}

 /* Local AI card: the built-in machine-learning model (multinomial Naive Bayes, trained on 240 authored
    messages in ar/he/en). Runs in the browser. Shows its decision and the words that pushed it. */
 const MLQ={
  ar:{title:'🤖 رأي الذكاء الاصطناعي',scam:'أسلوب هاي الرسالة بيشبه رسائل الاحتيال اللي تعلّم عليها.',safe:'أسلوب هاي الرسالة بيشبه الرسائل العادية.',abst:'ما قدر يحكم على أسلوب هاي الرسالة بثقة، فاعتمدنا على باقي الفحوصات.',strength:'درجة الشبه',lv:['ضعيفة','متوسطة','قوية'],words:'الكلمات اللي خلّته يشك:',foot:'نموذج تعلّم آلي مدرّب على 240 رسالة بالعربي والعبري والإنجليزي، بيشتغل على جهازك بدون إنترنت. ممكن يغلط، وعشان هيك منجمعه مع باقي الفحوصات.'},
  he:{title:'🤖 חוות דעת הבינה המלאכותית',scam:'סגנון ההודעה דומה להודעות ההונאה שהמודל למד.',safe:'סגנון ההודעה דומה להודעות רגילות.',abst:'המודל לא הצליח להכריע בביטחון לגבי סגנון ההודעה, ולכן הסתמכנו על שאר הבדיקות.',strength:'מידת הדמיון',lv:['חלשה','בינונית','חזקה'],words:'המילים שעוררו חשד:',foot:'מודל למידת מכונה שאומן על 240 הודעות בעברית, ערבית ואנגלית, ורץ במכשיר בלי אינטרנט. הוא עלול לטעות, ולכן משולב עם שאר הבדיקות.'},
  en:{title:'🤖 What the AI thinks',scam:'This message is written like the scam messages it learned from.',safe:'This message is written like ordinary messages.',abst:'It could not judge this message\u2019s style with confidence, so we relied on the other checks.',strength:'Similarity',lv:['weak','medium','strong'],words:'Words that made it suspicious:',foot:'A machine-learning model trained on 240 messages in Arabic, Hebrew and English, running on your device without internet. It can be wrong, so it is combined with the other checks.'}
 };
 const mq=k=>MLQ[L()][k];
 function mlCard(r){
  const ml=r.report?.ml;if(!ml||r.kind==='url'||r.kind==='phone'||r.kind==='file'||!String(r.report.original_text||'').trim())return '';
  const done=ml.status==='completed'&&['caution_pattern','ordinary_pattern'].includes(ml.label);
  const scam=done&&ml.label==='caution_pattern',m=Math.abs(Number(ml.raw_margin)||0),lv=m>=15?2:m>=6?1:0;
  const words=scam?(ml.top_features||[]).filter(f=>f.contribution>0&&f.feature!=='numtoken'&&!/^[\W_]+$/.test(f.feature)).slice(0,5).map(f=>f.feature):[];
  return `<article class="v3-ml ${scam?'scam':done?'safe':'abst'}"><b class="v3-ml-title">${esc(mq('title'))}</b><p>${esc(done?(scam?mq('scam'):mq('safe')):mq('abst'))}</p>${done?`<div class="v3-ml-meter"><span>${esc(mq('strength'))}: <strong>${esc(mq('lv')[lv])}</strong></span><i><b style="width:${[34,67,100][lv]}%"></b></i></div>`:''}${words.length?`<div class="v3-ml-words"><span>${esc(mq('words'))}</span>${words.map(w=>`<em dir="auto">${esc(w)}</em>`).join('')}</div>`:''}<small>${esc(mq('foot'))}</small></article>`;
 }

 /* ---------- Phone-call check: a short yes/no questionnaire + optional caller number ---------- */
 const CQ={
  ar:{btn:'مكالمة',title:'حدا اتصل فيك؟',sub:'جاوب بآه أو لا، وحط رقم المتصل إذا بتعرفه.',num:'رقم المتصل (مش ضروري)',who:'بيحكي إنه من…',whoOpts:['بنك أو شركة بطاقات (إشراي)','الشرطة أو جهة حكومية','شركة توصيل أو بريد','دعم فني (مايكروسوفت، تلفون…)','قريب أو صاحب','ما حكى / غير هيك'],back:'رجوع',yes:'آه',no:'لا',
   qs:[['code','طلب منك رمز وصلك برسالة (SMS)؟'],['card','طلب رقم البطاقة، الرمز السري، أو كلمة السر؟'],['app','طلب تنزّل تطبيق أو تفتحله شاشتك؟'],['transfer','طلب تحوّل مصاري "لحساب آمن" أو تشتري بطاقات هدايا؟'],['rush','ضغط عليك إنه لازم هلأ وما تسكّر الخط؟'],['secret','حكالك ما تحكي لحدا؟']],
   high:'نعم — هاي على الأغلب مكالمة نصب',review:'مشكوك — لا تعطي أي معلومة',limited:'ما في علامات نصب واضحة',
   doHigh:'سكّر الخط هلأ. اتصل إنت على الرقم اللي على ظهر بطاقتك أو الرقم الرسمي للجهة، وإذا أعطيته إشي، بلّغ البنك فورًا.',doReview:'سكّر واتصل إنت على الرقم الرسمي للجهة لتتأكد. ولا جهة رسمية بتطلب رموز أو كلمات سر بالتلفون.',doLimited:'بس تذكّر: إذا طلب رمز أو كلمة سر أو تحويل بأي لحظة، سكّر الخط.',
   r:{code:'طلب رمز التحقق — البنوك والشركات عمرها ما بتطلبه، وهو المفتاح لحسابك',card:'طلب رقم البطاقة أو الرمز السري — ولا جهة رسمية بتطلبهم بالتلفون',app:'طلب تنزيل تطبيق أو فتح الشاشة — هيك بيسيطر على جهازك وحسابك',transfer:'تحويل "لحساب آمن" أو بطاقات هدايا — ما في إشي اسمه حساب آمن، هاي سرقة',rush:'ضغط واستعجال — عشان ما تفكر أو تسأل حدا',secret:'طلب السرية — عشان ما حدا ينبّهك'},st:'المكالمة',stNum:'رقم المتصل'},
  he:{btn:'שיחה',title:'מישהו התקשר אליכם?',sub:'ענו כן או לא, והוסיפו את מספר המתקשר אם אתם יודעים.',num:'מספר המתקשר (לא חובה)',who:'הוא טוען שהוא מ…',whoOpts:['בנק או חברת כרטיסי אשראי','משטרה או גוף ממשלתי','חברת משלוחים או דואר','תמיכה טכנית (מיקרוסופט, סלולר…)','קרוב משפחה או חבר','לא אמר / אחר'],back:'חזרה',yes:'כן',no:'לא',
   qs:[['code','ביקש קוד שקיבלתם ב-SMS?'],['card','ביקש מספר כרטיס, קוד סודי או סיסמה?'],['app','ביקש להתקין אפליקציה או לשתף מסך?'],['transfer','ביקש להעביר כסף "לחשבון בטוח" או לקנות כרטיסי מתנה?'],['rush','לחץ שחייבים עכשיו ולא לנתק?'],['secret','אמר לא לספר לאף אחד?']],
   high:'כן — זו כנראה שיחת הונאה',review:'חשוד — אל תמסרו שום פרט',limited:'אין סימני הונאה ברורים',
   doHigh:'נתקו עכשיו. התקשרו בעצמכם למספר שעל גב הכרטיס או למספר הרשמי, ואם מסרתם משהו – דווחו לבנק מיד.',doReview:'נתקו והתקשרו בעצמכם למספר הרשמי כדי לוודא. אף גוף רשמי לא מבקש קודים או סיסמאות בטלפון.',doLimited:'רק זכרו: אם בשלב כלשהו מבקשים קוד, סיסמה או העברה – נתקו.',
   r:{code:'ביקש קוד אימות — בנקים וחברות לעולם לא מבקשים אותו, והוא המפתח לחשבון',card:'ביקש מספר כרטיס או קוד סודי — אף גוף רשמי לא מבקש בטלפון',app:'ביקש להתקין אפליקציה או לשתף מסך — כך משתלטים על המכשיר והחשבון',transfer:'העברה "לחשבון בטוח" או כרטיסי מתנה — אין דבר כזה חשבון בטוח, זו גניבה',rush:'לחץ ודחיפות — כדי שלא תחשבו או תתייעצו',secret:'בקשת סודיות — כדי שאף אחד לא יזהיר אתכם'},st:'השיחה',stNum:'מספר המתקשר'},
  en:{btn:'Phone call',title:'Did someone call you?',sub:'Answer yes or no, and add the caller’s number if you know it.',num:'Caller number (optional)',who:'They said they are from…',whoOpts:['A bank or credit-card company','Police or a government office','A delivery company or the post','Tech support (Microsoft, phone company…)','A relative or friend','Didn’t say / other'],back:'Back',yes:'Yes',no:'No',
   qs:[['code','Did they ask for a code you got by SMS?'],['card','Did they ask for your card number, PIN or password?'],['app','Did they ask you to install an app or share your screen?'],['transfer','Did they ask you to move money to a "safe account" or buy gift cards?'],['rush','Did they pressure you to act now and not hang up?'],['secret','Did they tell you not to tell anyone?']],
   high:'Yes — this is likely a scam call',review:'Suspicious — don’t give any details',limited:'No clear scam signs',
   doHigh:'Hang up now. Call the number on the back of your card or the official number yourself, and if you gave anything, tell your bank right away.',doReview:'Hang up and call the official number yourself to check. No real organization asks for codes or passwords by phone.',doLimited:'Just remember: if at any point they ask for a code, password or transfer, hang up.',
   r:{code:'Asked for a verification code — banks never ask for it; it unlocks your account',card:'Asked for card number or PIN — no real organization asks by phone',app:'Asked to install an app or share the screen — that is how they take over your device and account',transfer:'A "safe account" or gift cards — there is no such thing as a safe account; this is theft',rush:'Pressure and urgency — so you don’t stop to think or ask someone',secret:'Asked for secrecy — so nobody warns you'},st:'The call',stNum:'Caller number'}
 };
 const cq=k=>CQ[L()][k];
 for(const lang of ['ar','he','en']){Q[lang].st.call=CQ[lang].st;Q[lang].st.callnum=CQ[lang].stNum;}
 const CW={code:60,card:60,app:60,transfer:60,rush:15,secret:20};
 const call={on:false,ans:{},num:'',who:''};
 const CM={
  ar:{org:'المتصل بيحكي إنه من…',other:'جهة ثانية / مش بالقائمة',num:'رقم المتصل',more:'أسئلة إضافية (اختياري)',
   match:o=>`الرقم هو رقم رسمي لـ${o}`,matchDo:n=>`بس انتبه: المحتالين بيقدروا يزيّفوا الرقم اللي بيطلعلك. إذا طلب رمز أو كلمة سر أو تحويل مصاري — سكّر واتصل إنت على ${n}.`,
   miss:o=>`هاد مش الرقم الرسمي اللي عنا لـ${o}`,missDo:n=>`لا تعطيه أي معلومة. سكّر الخط واتصل إنت على الرقم الرسمي: ${n}`,missWhy:(o,n)=>`الرقم الرسمي لـ${o} هو ${n}، والرقم اللي اتصل مختلف`,
   owner:o=>`هاد الرقم تابع لـ${o}، مش للجهة اللي حكى إنه منها`,noOrg:'ما عنا الأرقام الرسمية لهاي الجهة — اتصل إنت على الرقم اللي بموقعها الرسمي أو على ظهر البطاقة.',src:'مصدر الأرقام:'},
  he:{org:'המתקשר טוען שהוא מ…',other:'גוף אחר / לא ברשימה',num:'מספר המתקשר',more:'שאלות נוספות (לא חובה)',
   match:o=>`המספר הוא מספר רשמי של ${o}`,matchDo:n=>`אבל שימו לב: נוכלים יכולים לזייף את המספר שמופיע אצלכם. אם מבקשים קוד, סיסמה או העברת כסף — נתקו והתקשרו בעצמכם ל-${n}.`,
   miss:o=>`זה לא המספר הרשמי של ${o} שמופיע אצלנו`,missDo:n=>`אל תמסרו שום פרט. נתקו והתקשרו בעצמכם למספר הרשמי: ${n}`,missWhy:(o,n)=>`המספר הרשמי של ${o} הוא ${n}, והמספר שהתקשר שונה`,
   owner:o=>`המספר שייך ל${o}, לא לגוף שהמתקשר טען`,noOrg:'אין לנו את המספרים הרשמיים של הגוף הזה — התקשרו בעצמכם למספר שבאתר הרשמי או על גב הכרטיס.',src:'מקור המספרים:'},
  en:{org:'The caller says they are from…',other:'Another organization / not listed',num:'Caller number',more:'Extra questions (optional)',
   match:o=>`This is an official number of ${o}`,matchDo:n=>`But careful: scammers can fake the number you see. If they ask for a code, password or money transfer — hang up and call ${n} yourself.`,
   miss:o=>`This is not the official ${o} number we have`,missDo:n=>`Don’t give any details. Hang up and call the official number yourself: ${n}`,missWhy:(o,n)=>`The official number of ${o} is ${n}; the caller’s number is different`,
   owner:o=>`This number belongs to ${o}, not to the organization the caller named`,noOrg:'We don’t have the official numbers for this organization — call the number on its official website or on the back of your card.',src:'Number source:'}
 };
 const cm=k=>CM[L()][k];
 function callPanel(){
  const orgs=RC_Phonebook.ORGS;
  return `<section class="v3-quick"><h1>📞 ${esc(cq('title'))}</h1>
  <div class="v3-call">
  <label class="v3-call-field"><span>${esc(cm('num'))}</span><input id="v3-call-num" dir="ltr" inputmode="tel" maxlength="30" value="${esc(call.num)}" placeholder="03-6178800"></label>
  <label class="v3-call-field"><span>${esc(cm('org'))}</span><select id="v3-call-who"><option value=""></option>${orgs.map(o=>`<option value="${o.id}" ${call.who===o.id?'selected':''}>${esc(o.name[L()])}</option>`).join('')}<option value="other" ${call.who==='other'?'selected':''}>${esc(cm('other'))}</option></select></label>
  <details class="v3-call-more" ${Object.keys(call.ans).length?'open':''}><summary>${esc(cm('more'))}</summary>${cq('qs').map(([k,t])=>`<div class="v3-call-q"><span>${esc(t)}</span><div class="v3-yn" role="group" aria-label="${esc(t)}"><button type="button" class="${call.ans[k]===true?'on yes':''}" data-v3="call-ans" data-k="${k}" data-v="1" aria-pressed="${call.ans[k]===true}">${esc(cq('yes'))}</button><button type="button" class="${call.ans[k]===false?'on no':''}" data-v3="call-ans" data-k="${k}" data-v="0" aria-pressed="${call.ans[k]===false}">${esc(cq('no'))}</button></div></div>`).join('')}</details></div>
  <button class="v3-quick-btn" data-v3="call-check" ${call.num.trim()||Object.keys(call.ans).length?'':'disabled'}>${icon('search')}${esc(q('btn'))}</button><small class="v3-call-src">${esc(cm('src'))} ${esc(RC_Phonebook.SOURCE[L()])}</small><button class="v3-quick-link" data-v3="call-back">${esc(cq('back'))}</button></section>`;
 }
 function runCall(){
  const yes=Object.keys(call.ans).filter(k=>call.ans[k]);
  let score=yes.reduce((t,k)=>t+CW[k],0);
  const reasons=yes.sort((a,b)=>CW[b]-CW[a]).map(k=>cq('r')[k]);
  const steps=[];let custom=null;
  const num=call.num.trim(),pb=num&&call.who&&call.who!=='other'?RC_Phonebook.check(num,call.who):null,owner=num?RC_Phonebook.whoOwns(num):null;
  if(pb&&pb.known){
   const o=pb.org.name[L()],off=pb.org.numbers[0];
   if(pb.matched){custom={emoji:'✅',title:cm('match')(o),todo:cm('matchDo')(off)};steps.push({id:'callnum',status:'ok',detail:cm('match')(o)});}
   else{score+=30;custom={emoji:'⚠️',title:cm('miss')(o),todo:cm('missDo')(off)};reasons.unshift(owner?cm('owner')(owner.name[L()]):cm('missWhy')(o,off));steps.push({id:'callnum',status:'warn',detail:cm('missWhy')(o,off)});}
  }else if(num&&call.who==='other'){custom={emoji:'ℹ️',title:cq('limited'),todo:cm('noOrg')};}
  const plist=num?RC_Smart.phones(num):[],pf=RC_Smart.phoneFindings(plist,pb&&pb.known?'government':null);
  score=Math.min(100,score+pf.reduce((t,f)=>t+f.weight,0));
  reasons.push(...pf.map(f=>typeof q('pf')[f.code]==='function'?q('pf')[f.code](f.phone.country?.[L()]||f.phone.e164):q('pf')[f.code]));
  if(plist.length&&!steps.length)steps.push({id:'callnum',status:pf.length?'warn':'ok',detail:plist.map(p=>`${p.e164}${p.country?' · '+p.country[L()]:''}`).join(' · ')});
  if(yes.length)steps.unshift({id:'call',status:'warn',detail:cq('r')[yes[0]]});
  const verdict=RC_Smart.verdictOf(score);
  if(verdict==='high'&&yes.some(k=>CW[k]>=60))custom=null; // a request for codes/cards/apps/transfers always wins
  qs.steps=steps;qs.result={kind:'call',custom,verdict,score,reasons:reasons.slice(0,3),steps,report:{verdict,score,original_text:'',signals:[],urls:[]},realSites:[]};call.on=false;render();window.scrollTo({top:0,behavior:'smooth'});
 }
 async function runCheck(){
  const text=qs.text.trim();if(!text&&!qs.image&&!qs.file)return;
  if(qs.file&&!qs.image)return runFileCheck(text);
  qs.running=true;qs.result=null;const kind=qs.image?'image':RC_Smart.detectKind(text);
  qs.steps=['content','links','identity','phone',...(qs.image?['image']:[]),'hidden','ai'].map(id=>({id,status:'pending',detail:''}));render();
  let img=null,full=text;
  if(qs.image){img=await readImage(qs.image,p=>{const st=qs.steps.find(s=>s.id==='image');st.detail=q('d').imgLoading(p);const el=document.querySelector('[data-step="image"] small');if(el)el.textContent=st.detail;});full=[text,img.text,...img.qr].filter(Boolean).join('\n');}
  const res=buildResult(full,kind==='image'?'message':kind,img);
  for(let i=0;i<res.steps.length;i++){qs.steps[i]=res.steps[i];render();await new Promise(r=>setTimeout(r,matchMedia('(prefers-reduced-motion: reduce)').matches?0:200));}
  qs.result=res;qs.running=false;render();window.scrollTo({top:0,behavior:'smooth'});
 }
 async function runFileCheck(text){
  qs.running=true;qs.result=null;
  qs.steps=['file','links','content'].map(id=>({id,status:'pending',detail:''}));render();
  let info;try{info=await RC_FileCheck.inspect(qs.file);}catch{qs.running=false;qs.steps=null;toast(t('invalidInput'));render();return;}
  const body=[text,...info.urls,info.text].filter(Boolean).join('\n');
  const res=buildResult(body||' ', 'message',null);
  const extra=info.findings.reduce((t,f)=>t+f.weight,0);
  res.score=Math.min(100,(body.trim()?res.score:0)+extra);
  res.verdict=RC_Smart.verdictOf(res.score);res.report.verdict=res.verdict;
  res.reasons=[...info.findings.sort((a,b)=>b.weight-a.weight).map(fileReason),...(body.trim()?res.reasons:[])].slice(0,3);
  res.file=info;res.kind='file';
  const typeName=(info.ext||info.real||'?').toUpperCase();
  const keep=res.steps.filter(s=>['links','content','identity','hidden'].includes(s.id)&&(body.trim()?true:false)&&s.status!=='na');
  res.steps=[{id:'file',status:info.findings.length?'warn':'ok',detail:info.findings.length?fileReason(info.findings[0]):fq('ok')(typeName)},...keep];
  if(!body.trim()){res.realSites=[];}
  for(let i=0;i<res.steps.length;i++){qs.steps[i]=res.steps[i];render();await new Promise(r=>setTimeout(r,matchMedia('(prefers-reduced-motion: reduce)').matches?0:200));}
  qs.steps=res.steps;qs.result=res;qs.running=false;render();window.scrollTo({top:0,behavior:'smooth'});
 }
 const STEP_ICON={pending:'<span class="v3-spin"></span>',ok:'✓',warn:'!',na:'–',off:'○'};
 function stepsHtml(){
  if(!qs.steps)return '';
  return `<div class="v3-steps"><b>${esc(qs.running?q('investigating'):q('sources'))}</b><ul>${qs.steps.filter(x=>qs.running||x.status!=='na').map(s=>`<li class="${s.status}" data-step="${s.id}"><i>${STEP_ICON[s.status]}</i><div><span>${esc(q('st')[s.id])}</span>${s.status==='pending'?(s.detail?`<small>${esc(s.detail)}</small>`:''):`<small>${esc(s.detail||(s.status==='off'?q('off'):s.status==='na'?q('na'):q(s.status)))}</small>`}</div></li>`).join('')}</ul></div>`;
 }
 function quick(){
  const r=qs.result;
  if(!r&&call.on)return callPanel();
  if(!r){
   const kind=qs.image?'image':qs.file?'file':RC_Smart.detectKind(qs.text);
   return `<section class="v3-quick"><h1>${esc(q('title'))}</h1><p>${esc(q('sub'))}</p>
   <div class="v3-quick-box"><textarea id="v3-quick-text" dir="auto" maxlength="12000" placeholder="${esc(q('ph'))}" aria-label="${esc(q('ph'))}" ${qs.running?'disabled':''}>${esc(qs.text)}</textarea>
   <div class="v3-quick-tools"><button type="button" class="v3-img-btn" data-v3="call-open">📞<span>${esc(cq('btn'))}</span></button><label class="v3-img-btn">📎<span>${esc(fq('btn'))}</span><input type="file" id="v3-quick-image" ${qs.running?'disabled':''}></label><span class="v3-kind" id="v3-kind">${kind==='empty'?'':esc(kind==='file'?fq('kind'):q('kinds')[kind])}</span></div>
   ${qs.file&&!qs.image?`<div class="v3-img-preview"><span class="v3-file-ico" aria-hidden="true">📄</span><span>${esc(qs.imageName)}</span><button class="icon-button" data-v3="quick-image-remove" aria-label="${esc(q('imgRemove'))}" title="${esc(q('imgRemove'))}">${icon('x')}</button></div>`:''}${qs.image?`<div class="v3-img-preview"><img src="${qs.image}" alt=""><span>${esc(qs.imageName)}</span><button class="icon-button" data-v3="quick-image-remove" aria-label="${esc(q('imgRemove'))}" title="${esc(q('imgRemove'))}">${icon('x')}</button></div>`:''}</div>
   <button class="v3-quick-btn" data-v3="quick-check" ${(qs.text.trim()||qs.image||qs.file)&&!qs.running?'':'disabled'}>${qs.running?'<span class="v3-spin"></span>':icon('search')}${esc(qs.running?q('investigating'):q('btn'))}</button>${stepsHtml()}<small>${icon('lock')}${esc(q('local'))}</small></section>`;}
  const v=r.verdict,emoji={high:'🚨',review:'⚠️',limited:'✅',unknown:'ℹ️',unread:'🖼️'}[v],isCall=r.kind==='call',isFile=r.kind==='file'&&(r.file?.findings.length>0||v==='limited'),todo=isCall?cq({high:'doHigh',review:'doReview',limited:'doLimited'}[v]):isFile?fq({high:'doHigh',review:'doReview',limited:'doLimited'}[v]):q({high:'doHigh',review:'doReview',limited:'doLimited',unknown:'doUnknown',unread:'doUnread'}[v]);
  let title=isCall?cq(v):isFile?fq(v):q(v);let emo=emoji;let todo2=todo;if(isCall&&r.custom){title=r.custom.title;emo=r.custom.emoji;todo2=r.custom.todo;}
  const fileExtra=r.kind==='file'?`<div class="v3-file-extra"><small>${esc(fq('caveat'))}</small>${r.file.sha256?`<a href="https://www.virustotal.com/gui/file/${r.file.sha256}" target="_blank" rel="noopener noreferrer">🛡️ ${esc(fq('vt'))}</a><small>${esc(fq('vtNote'))}</small>`:''}</div>`:'';
  return `<section class="v3-quick"><article class="v3-answer ${v}"><div class="v3-answer-icon" aria-hidden="true">${emo}</div><h1>${esc(title)}</h1><p class="v3-answer-do">${esc(todo2)}</p>${r.realSites?.length?`<p class="v3-real-site">${esc(q('realSite'))} ${r.realSites.map(d=>`<b dir="ltr">${esc(d)}</b>`).join(' · ')}</p>`:''}${r.reasons.length&&['high','review'].includes(v)?`<div class="v3-answer-why"><b>${esc(q('why'))}</b><ul>${r.reasons.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div>`:''}${fileExtra}</article>${mlCard(r)}${isFile||isCall?'':answerActions(r)}${stepsHtml()}<button class="v3-quick-btn" data-v3="quick-again">${esc(q('again'))}</button>${v==='unread'||SIMPLE()?'':`<button class="v3-quick-link" data-v3="quick-more">${esc(q('more'))}</button>`}</section>`;
 }
 function setImage(file){if(!file||file.size>50*1024*1024){toast(t('invalidInput'));return;}qs.file=file;qs.imageName=file.name||'file';qs.result=null;qs.steps=null;qs.image=null;if(/^image\/(png|jpeg|webp)$/.test(file.type)&&file.size<=8*1024*1024){const fr=new FileReader();fr.onload=()=>{qs.image=fr.result;render();};fr.readAsDataURL(file);}else render();}
 document.addEventListener('change',e=>{if(e.target.id==='v3-quick-image')setImage(e.target.files[0]);});
 document.addEventListener('paste',e=>{if(state.page!=='quick'||qs.running)return;const it=[...(e.clipboardData?.items||[])].find(i=>i.type.startsWith('image/'));if(it){e.preventDefault();setImage(it.getAsFile());}});
 async function copy(text){
  try{await navigator.clipboard.writeText(text);}catch{const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');}catch{}ta.remove();}
  toast(s('copied'));
 }
 async function click(el){
  const act=el.dataset.v3;if(!act)return false;
  if(act==='launch'||act==='attack-current'){
   if(act==='attack-current'){rt.text=state.report.original_text;state.page='redteam';}
   rt.result=null;
   try{rt.result=RC_RedTeam.attack(rt.text.slice(0,2000),{language:L(),expected_domain:act==='attack-current'?(state.report.expected_domain||''):''});}catch{toast(t('invalidInput'));}
   render();if(act==='attack-current')window.scrollTo({top:0});document.getElementById('v3-live-result')?.scrollIntoView({behavior:'smooth',block:'start'});return true;}
  if(act==='xray'){const row=rt.result?.rows[Number(el.dataset.idx)];if(!row?.mutated)return true;state.page='investigate';state.tab='message';state.text=row.mutated;state.domain='';state.error='';state.report=RC.analyze({text:row.mutated,language:L()});render();document.querySelector('.v3-xray')?.scrollIntoView({behavior:'smooth',block:'center'});return true;}
  if(act==='quick-check'){if(!qs.running)runCheck().catch(()=>{qs.running=false;toast(t('invalidInput'));render();});return true;}
  if(act==='quick-warn'){const r=qs.result;if(r)await copy(quickWarn(r));return true;}
  if(act==='example-fill'){const ex=vq('ex')[Number(el.dataset.i)];if(ex){qs.text=ex[1];qs.image=null;render();}return true;}
  if(act==='call-open'){call.on=true;call.ans={};call.num='';call.who='';qs.result=null;qs.steps=null;render();window.scrollTo({top:0});return true;}
  if(act==='call-back'){call.on=false;render();return true;}
  if(act==='call-ans'){call.ans[el.dataset.k]=el.dataset.v==='1';render();return true;}
  if(act==='call-check'){runCall();return true;}
  if(act==='quick-image-remove'){qs.image=null;qs.file=null;qs.imageName='';render();return true;}
  if(act==='quick-again'){Object.assign(qs,{text:'',file:null,image:null,imageName:'',result:null,steps:null});render();setTimeout(()=>document.getElementById('v3-quick-text')?.focus(),50);return true;}
  if(act==='quick-more'){const rep=qs.result.report;state.page='investigate';state.tab='message';state.text=rep.original_text;state.domain='';state.error='';state.report=rep;render();window.scrollTo({top:0});return true;}
  if(act==='example'){rt.text=EXAMPLE[L()];rt.result=null;render();return true;}
  if(act==='copy-warn'){const r=state.report;if(r)await copy(warnText(r,dna(r)));return true;}
  if(act==='arena-start'){Object.assign(ar,{round:0,vote:null,human:0,engine:0,report:null});render();return true;}
  if(act==='vote'){ar.vote=el.dataset.choice;const q=ROUNDS[ar.round];ar.report=RC.analyze({text:q.text[L()],language:L()});if(ar.vote===q.truth)ar.human++;if((ar.report.score>=25?'scam':'legit')===q.truth)ar.engine++;render();return true;}
  if(act==='next'){ar.round++;ar.vote=null;ar.report=null;render();window.scrollTo({top:0,behavior:'smooth'});return true;}
  return false;
 }
 function input(el){if(el.id==='v3-call-num'){call.num=el.value;const b=document.querySelector('[data-v3="call-check"]');if(b)b.disabled=!(el.value.trim()||Object.keys(call.ans).length);return;}if(el.id==='v3-call-who'){call.who=el.value;return;}if(el.id==='v3-quick-text'){qs.text=el.value;const b=document.querySelector('[data-v3="quick-check"]');if(b)b.disabled=!(el.value.trim()||qs.image||qs.file);const k=document.getElementById('v3-kind');if(k){const kind=qs.image?'image':qs.file?'file':RC_Smart.detectKind(el.value);k.textContent=kind==='empty'?'':kind==='file'?fq('kind'):q('kinds')[kind];}return;}if(el.id==='v3-text'){rt.text=el.value;const b=document.querySelector('[data-v3="launch"]');if(b)b.disabled=!el.value.trim();}}
 function langChanged(){if(qs.result&&!qs.image&&!qs.file)qs.result=buildResult(qs.result.report.original_text,qs.result.kind,null);if(Object.values(EXAMPLE).includes(rt.text)){rt.text=EXAMPLE[L()];rt.result=null;}if(ar.vote){ar.report=RC.analyze({text:ROUNDS[ar.round].text[L()],language:L()});}}
 return {quick,reportExtras,redteam,arena,click,input,langChanged,dna,ROUNDS};
}};
