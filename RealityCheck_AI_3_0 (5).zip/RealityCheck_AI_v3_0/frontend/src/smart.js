/* 3.0 Smart Check — one input for a message, link, phone number or screenshot.
   Pure helpers (no DOM). Phone analysis is offline: it can tell where a number is
   registered and whether it sits in an unusual range, but NOT who owns it. */
window.RC_Smart=(()=>{
 const AR_DIGITS=s=>String(s).replace(/[٠-٩]/g,d=>String(d.charCodeAt(0)-0x660)).replace(/[۰-۹]/g,d=>String(d.charCodeAt(0)-0x6f0));
 const COUNTRIES={
  '972':{ar:'إسرائيل',he:'ישראל',en:'Israel'},'970':{ar:'فلسطين',he:'פלסטין',en:'Palestine'},'962':{ar:'الأردن',he:'ירדן',en:'Jordan'},'20':{ar:'مصر',he:'מצרים',en:'Egypt'},
  '966':{ar:'السعودية',he:'ערב הסעודית',en:'Saudi Arabia'},'971':{ar:'الإمارات',he:'איחוד האמירויות',en:'UAE'},'974':{ar:'قطر',he:'קטאר',en:'Qatar'},'965':{ar:'الكويت',he:'כווית',en:'Kuwait'},
  '961':{ar:'لبنان',he:'לבנון',en:'Lebanon'},'963':{ar:'سوريا',he:'סוריה',en:'Syria'},'964':{ar:'العراق',he:'עיראק',en:'Iraq'},'212':{ar:'المغرب',he:'מרוקו',en:'Morocco'},'213':{ar:'الجزائر',he:'אלג׳יריה',en:'Algeria'},'216':{ar:'تونس',he:'תוניסיה',en:'Tunisia'},
  '90':{ar:'تركيا',he:'טורקיה',en:'Turkey'},'1':{ar:'الولايات المتحدة/كندا',he:'ארה״ב/קנדה',en:'USA/Canada'},'44':{ar:'بريطانيا',he:'בריטניה',en:'UK'},'49':{ar:'ألمانيا',he:'גרמניה',en:'Germany'},
  '33':{ar:'فرنسا',he:'צרפת',en:'France'},'39':{ar:'إيطاليا',he:'איטליה',en:'Italy'},'34':{ar:'إسبانيا',he:'ספרד',en:'Spain'},'31':{ar:'هولندا',he:'הולנד',en:'Netherlands'},'7':{ar:'روسيا/كازاخستان',he:'רוסיה/קזחסטן',en:'Russia/Kazakhstan'},
  '380':{ar:'أوكرانيا',he:'אוקראינה',en:'Ukraine'},'91':{ar:'الهند',he:'הודו',en:'India'},'92':{ar:'باكستان',he:'פקיסטן',en:'Pakistan'},'86':{ar:'الصين',he:'סין',en:'China'},'62':{ar:'إندونيسيا',he:'אינדונזיה',en:'Indonesia'},
  '63':{ar:'الفلبين',he:'הפיליפינים',en:'Philippines'},'234':{ar:'نيجيريا',he:'ניגריה',en:'Nigeria'},'61':{ar:'أستراليا',he:'אוסטרליה',en:'Australia'},'55':{ar:'البرازيل',he:'ברזיל',en:'Brazil'}
 };
 // ITU international ranges that are not tied to a country: satellite (870, 881), international networks (882, 883), premium-rate IPRS (979).
 const SPECIAL={'870':'satellite','881':'satellite','882':'network','883':'network','979':'premium'};
 const LOCAL_ENTITIES=new Set(['government','israel_post','hapoalim','leumi','discount','mizrahi','bank_of_palestine']);
 const PHONE_RE=/(?:\+|00)\d[\d\s\-().]{6,18}\d|(?<![\d\w])0\d{1,2}[\s-]?\d{3}[\s-]?\d{3,4}(?![\d\w])|(?<![\d\w])1[\s-]?(?:800|700|900|901|599)[\s-]?\d{2,3}[\s-]?\d{3,4}(?![\d\w])/g;
 function parsePhone(raw){
  const digits=AR_DIGITS(raw).replace(/[^\d+]/g,'');let intl=null,local=null;
  if(digits.startsWith('+'))intl=digits.slice(1);else if(digits.startsWith('00'))intl=digits.slice(2);else local=digits;
  if(intl){
   for(const len of [3,2,1]){const cc=intl.slice(0,len);if(SPECIAL[cc])return {raw,e164:'+'+intl,cc,special:SPECIAL[cc]};if(COUNTRIES[cc])return {raw,e164:'+'+intl,cc,country:COUNTRIES[cc]};}
   return {raw,e164:'+'+intl,cc:null};
  }
  if(/^1(?:900|901)/.test(local))return {raw,e164:local,cc:'972',country:COUNTRIES['972'],premium:true,local:true};
  if(/^1(?:800|700|599)/.test(local))return {raw,e164:local,cc:'972',country:COUNTRIES['972'],tollfree:true,local:true};
  return {raw,e164:local,cc:null,local:true};
 }
 function phones(text){const out=[];const seen=new Set();for(const m of AR_DIGITS(text).matchAll(PHONE_RE)){const p=parsePhone(m[0].trim());const key=p.e164;if(key.replace(/\D/g,'').length<8||seen.has(key))continue;seen.add(key);out.push(p);}return out;}
 function detectKind(text){
  const t=AR_DIGITS(String(text).trim());
  if(!t)return 'empty';
  if(/^[+\d][\d\s\-().+]{6,22}$/.test(t)&&t.replace(/\D/g,'').length>=7)return 'phone';
  if(/^(?:https?:\/\/|www\.)\S+$/i.test(t)||/^[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:\/\S*)?$/i.test(t))return 'url';
  return 'message';
 }
 const W={special:35,premium:20,local_entity_foreign:25};
 function phoneFindings(list,entityId){
  const f=[];
  for(const p of list){
   if(p.special){f.push({code:'phone_special',weight:W.special,phone:p});continue;}
   else if(p.premium)f.push({code:'phone_premium',weight:W.premium,phone:p});
   if(entityId&&LOCAL_ENTITIES.has(entityId)&&p.cc&&!['972','970'].includes(p.cc)&&!p.local)f.push({code:'phone_local_entity_foreign',weight:W.local_entity_foreign,phone:p});
  }
  return f;
 }
 // A well-known name planted inside a link that the organization does not own (works even when the message names nobody).
 function linkBrandFindings(urls,data){
  const out=[];if(!data)return out;
  const gov=(data.government_patterns||[]).map(p=>new RegExp(p));
  for(const u of urls||[]){
   const host=String(u.host||'').toLowerCase();if(!host)continue;
   const c=host.replace(/-/g,''),variants=[c,c.replace(/[01345]/g,d=>({'0':'o','1':'l','3':'e','4':'a','5':'s'}[d])),c.replace(/1/g,'i')];
   for(const e of data.entities){
    const official=e.official.some(d=>host===d||host.endsWith('.'+d))||(e.kind==='government'&&gov.some(p=>p.test(host)));if(official)continue;
    const tokens=[...new Set([...e.official.map(d=>d.split('.')[0].replace(/-/g,'')),...e.cues.map(x=>x.toLowerCase()).filter(x=>/^[a-z0-9]{4,}$/.test(x))])].filter(t=>t.length>=4);
    if(tokens.some(t=>variants.some(v=>v.includes(t)))){out.push({code:'link_brand',weight:30,host,entity:e});break;}
   }
  }
  return out;
 }
 // Offline website checks: where a link really goes and whether it looks like a throwaway payment/login page.
 const SECOND_LEVEL=new Set(['co','com','org','net','gov','ac','edu','muni','ltd','plc','or','ne','go']);
 function realDomain(host){const h=String(host||'').toLowerCase().replace(/\.$/,'');if(/^\d+(\.\d+){3}$/.test(h)||h.includes(':'))return h;const l=h.split('.');if(l.length<=2)return h;return SECOND_LEVEL.has(l[l.length-2])&&l[l.length-1].length===2?l.slice(-3).join('.'):l.slice(-2).join('.');}
 // TLDs frequently seen in phishing reports; a hint, never proof on its own.
 const RISKY_TLDS=new Set(['xyz','top','click','live','shop','icu','buzz','rest','cyou','sbs','cfd','monster','quest','lol','bond','support','help','online','site','store','vip','win','loan','work','tk','ml','ga','cf','gq','zip','mov']);
 const PAY_WORDS=/(^|[^a-z])(pay|payment|payments|visa|mastercard|card|billing|checkout|verify|verification|secure|login|signin|update|wallet|refund|bonus|prize|otp|kyc|unlock|confirm|bank)(?=[^a-z]|$)/;
 function isOfficial(host,data){const gov=(data?.government_patterns||[]).map(p=>new RegExp(p));return (data?.entities||[]).some(e=>e.official.some(d=>host===d||host.endsWith('.'+d)))||gov.some(p=>p.test(host));}
 function linkFindings(urls,data){
  const out=[];
  for(const u of urls||[]){
   const host=String(u.host||'').toLowerCase();if(!host||isOfficial(host,data))continue;
   const real=realDomain(host),tld=real.split('.').pop(),label=real.split('.')[0];
   let path='';try{const raw=u.raw||u.url||host;const x=new URL(/^[a-z]+:\/\//i.test(raw)?raw.replace(/^hxxp/i,'http'):'https://'+raw);path=(x.pathname+x.search).toLowerCase();}catch{}
   const words=(host.replace(/\./g,' ')+' '+path.replace(/[\/?=&#._-]/g,' ')).replace(/[01345]/g,d=>({'0':'o','1':'l','3':'e','4':'a','5':'s'}[d]));
   if(PAY_WORDS.test(words))out.push({code:'pay_page',weight:15,host,real});
   if(RISKY_TLDS.has(tld))out.push({code:'risky_tld',weight:12,host,real,tld});
   if(host!==real&&host.replace(/^www\./,'')!==real&&host.split('.').length-real.split('.').length>=2)out.push({code:'deep_sub',weight:15,host,real});
   if((label.match(/-/g)||[]).length>=2||/\d{4,}/.test(label))out.push({code:'odd_name',weight:8,host,real});
  }
  return out;
 }
 function verdictOf(score){return score>=55?'high':score>=25?'review':'limited';}
 return {phones,parsePhone,detectKind,phoneFindings,linkBrandFindings,linkFindings,realDomain,verdictOf,COUNTRIES};
})();

/* 3.0 File check — offline static inspection of a file the user selects (never executed, never uploaded).
   Looks at the real type (magic bytes), the name, and active content (macros, PDF actions, phishing forms,
   executables inside archives). It is NOT an antivirus scan. */
window.RC_FileCheck=(()=>{
 const EXEC_EXT=new Set(['exe','msi','scr','com','pif','bat','cmd','ps1','vbs','vbe','js','jse','wsf','wsh','hta','lnk','jar','apk','xapk','dmg','pkg','sh','run','cpl','reg','gadget','msc','appx','msix','iso','img','vhd','vhdx']);
 const MACRO_EXT=new Set(['docm','xlsm','pptm','dotm','xltm','xlam','ppsm']);
 const DOC_EXT=new Set(['pdf','doc','docx','xls','xlsx','ppt','pptx','jpg','jpeg','png','gif','webp','txt','mp3','mp4','mov','zip','rar']);
 const hex=b=>[...b].map(x=>x.toString(16).padStart(2,'0')).join('');
 function magic(b){
  const h=hex(b.slice(0,8)),s=String.fromCharCode(...b.slice(0,512)).toLowerCase();
  if(h.startsWith('4d5a'))return 'exe';if(h.startsWith('7f454c46'))return 'elf';if(/^(cefaedfe|cffaedfe|feedface|feedfacf|cafebabe)/.test(h))return 'macho';
  if(h.startsWith('504b0304')||h.startsWith('504b0506'))return 'zip';if(h.startsWith('25504446'))return 'pdf';if(h.startsWith('d0cf11e0'))return 'ole';
  if(h.startsWith('89504e47'))return 'png';if(h.startsWith('ffd8ff'))return 'jpg';if(h.startsWith('47494638'))return 'gif';if(h.startsWith('52494646')&&s.slice(8,12)==='webp')return 'webp';
  if(h.startsWith('52617221'))return 'rar';if(h.startsWith('377abcaf'))return '7z';if(h.startsWith('4c000000'))return 'lnk';
  if(/^\s*(<!doctype html|<html|<head|<script|<form|<body)/.test(s))return 'html';if(/^\s*(<\?xml[^>]*>\s*)?<svg/.test(s))return 'svg';
  if(s.slice(32769,32774)==='cd001'||String.fromCharCode(...b.slice(32769,32774)).toLowerCase()==='cd001')return 'iso';
  return 'unknown';
 }
 function zipEntries(b){
  const out=[];const dv=new DataView(b.buffer,b.byteOffset,b.byteLength);
  for(let i=0;i+46<=b.length&&out.length<2000;i++){
   if(b[i]===0x50&&b[i+1]===0x4b&&b[i+2]===0x01&&b[i+3]===0x02){
    const flags=dv.getUint16(i+8,true),nlen=dv.getUint16(i+28,true),elen=dv.getUint16(i+30,true),clen=dv.getUint16(i+32,true);
    const name=new TextDecoder().decode(b.slice(i+46,i+46+nlen));out.push({name,encrypted:!!(flags&1)});i+=45+nlen+elen+clen;
   }
  }
  return out;
 }
 const ext=n=>{const m=String(n).toLowerCase().match(/\.([a-z0-9]{1,6})$/);return m?m[1]:'';};
 async function sha256(buf){try{const d=await crypto.subtle.digest('SHA-256',buf);return hex(new Uint8Array(d));}catch{return '';}}
 async function inspect(file){
  const buf=await file.slice(0,Math.min(file.size,25*1024*1024)).arrayBuffer(),b=new Uint8Array(buf);
  const name=file.name||'file',e=ext(name),real=magic(b),f=[];
  const textish=['pdf','html','svg','unknown'].includes(real)||['txt','eml','htm','html','svg','csv','json','xml'].includes(e);
  const text=textish?new TextDecoder('utf-8',{fatal:false}).decode(b.slice(0,3*1024*1024)):'';
  if(/[‪-‮⁦-⁩]/.test(name))f.push({code:'rtlo_name',weight:60});
  const parts=name.toLowerCase().split('.');
  if(parts.length>=3&&DOC_EXT.has(parts[parts.length-2])&&EXEC_EXT.has(e))f.push({code:'double_ext',weight:45,shown:parts.slice(0,-1).join('.'),real:e});
  else if(/\s{4,}\.[a-z0-9]{2,5}$/i.test(name))f.push({code:'double_ext',weight:45,shown:name.replace(/\s{4,}\.[a-z0-9]{2,5}$/i,''),real:e});
  const execByMagic=['exe','elf','macho','lnk'].includes(real);
  if(e==='apk'||e==='xapk')f.push({code:'apk',weight:55});
  else if(EXEC_EXT.has(e)||execByMagic)f.push({code:'program',weight:60,ext:EXEC_EXT.has(e)?e:real});
  const looks={pdf:['pdf'],jpg:['jpg','jpeg'],png:['png'],gif:['gif'],webp:['webp'],zip:['zip','docx','xlsx','pptx','docm','xlsm','pptm','jar','apk','odt','ods','epub'],ole:['doc','xls','ppt','msi','msg'],rar:['rar'],'7z':['7z'],html:['html','htm','svg','txt'],svg:['svg','xml','html']};
  if(e&&real!=='unknown'&&looks[real]&&!looks[real].includes(e)&&!EXEC_EXT.has(e))f.push({code:'type_mismatch',weight:execByMagic?60:35,ext:e,real});
  else if(e&&execByMagic&&!EXEC_EXT.has(e)&&!['dll','sys','bin','dat'].includes(e))f.push({code:'type_mismatch',weight:60,ext:e,real});
  if(MACRO_EXT.has(e))f.push({code:'macro',weight:55});
  let entries=[];
  if(real==='zip'){
   entries=zipEntries(b);
   if(entries.some(x=>/vbaproject\.bin$/i.test(x.name))&&!f.some(x=>x.code==='macro'))f.push({code:'macro',weight:55});
   const inner=entries.filter(x=>EXEC_EXT.has(ext(x.name))&&!/^(meta-inf|res|assets)\//i.test(x.name));
   if(inner.length&&!['apk','xapk','jar'].includes(e))f.push({code:'archive_exec',weight:55,names:inner.slice(0,3).map(x=>x.name.split('/').pop())});
   if(entries.length&&entries.every(x=>x.encrypted))f.push({code:'encrypted',weight:20});
  }
  if(real==='ole'){const s=String.fromCharCode(...b.slice(0,Math.min(b.length,2e6)));if(/_VBA_PROJECT|Macros|VBA/.test(s)&&!f.some(x=>x.code==='macro'))f.push({code:'macro',weight:55});}
  if(real==='pdf'){const hits=['/JavaScript','/JS','/Launch','/EmbeddedFile','/OpenAction','/AA','/SubmitForm','/RichMedia'].filter(k=>text.includes(k));const strong=hits.filter(k=>['/JavaScript','/JS','/Launch','/EmbeddedFile','/RichMedia'].includes(k));if(strong.length)f.push({code:'pdf_active',weight:strong.includes('/Launch')||strong.includes('/EmbeddedFile')?60:45,keys:strong});}
  if(real==='html'||real==='svg'||['htm','html','svg'].includes(e)){
   const low=text.toLowerCase();
   if(/<input[^>]+type\s*=\s*["']?password/.test(low)||(/<form/.test(low)&&/(password|passwd|pin|card|cvv|otp|כרטיס|סיסמ|كلمة)/.test(low)))f.push({code:'html_phish',weight:60});
   else if(/<script/.test(low)&&/(atob\(|eval\(|unescape\(|window\.location|document\.write|fromcharcode)/.test(low))f.push({code:'html_script',weight:35});
   else if(real==='svg'&&/<script|onload=|javascript:/.test(low))f.push({code:'html_script',weight:35});
  }
  const urls=[...new Set((text.match(/https?:\/\/[^\s"'<>()\\\]]{4,200}/gi)||[]).map(u=>u.replace(/[),.;]+$/,'')))].slice(0,20);
  const words=real==='pdf'?'':text.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,6000);
  return {name,size:file.size,ext:e,real,findings:f,urls,text:words,entries:entries.length,sha256:await sha256(buf),isImage:['png','jpg','gif','webp'].includes(real)};
 }
 return {inspect};
})();

/* Official phone numbers (Bank of Israel list of bank and credit-card fraud hotlines,
   boi.org.il/roles/supervisionregulation/scam_phone/, updated 10/06/2026). A match does NOT prove a call is real:
   caller ID can be spoofed. A mismatch means "not one of the official numbers we know". */
window.RC_Phonebook=(()=>{
 const SOURCE={ar:'بنك إسرائيل — أرقام البنوك وشركات البطاقات للإبلاغ عن الاحتيال (تحديث 10/06/2026)',he:'בנק ישראל — מוקדי הבנקים וחברות האשראי לדיווח על הונאה (עדכון 10/06/2026)',en:'Bank of Israel — bank and credit-card fraud hotlines (updated 10/06/2026)'};
 const ORGS=[
  {id:'max',name:{ar:'ماكس (بطاقات ائتمان)',he:'מקס',en:'Max (credit cards)'},numbers:['03-6178800']},
  {id:'isracard',name:{ar:'إيزراكارد (بطاقات ائتمان)',he:'ישראכרט',en:'Isracard'},numbers:['03-6364400']},
  {id:'cal',name:{ar:'كال (بطاقات ائتمان)',he:'כ.א.ל',en:'CAL (credit cards)'},numbers:['03-5723666']},
  {id:'hapoalim',name:{ar:'بنك هبوعليم',he:'בנק הפועלים',en:'Bank Hapoalim'},numbers:['*9391']},
  {id:'leumi',name:{ar:'بنك لئومي',he:'בנק לאומי',en:'Bank Leumi'},numbers:['*5946']},
  {id:'mizrahi',name:{ar:'بنك مزراحي طفحوت',he:'מזרחי טפחות',en:'Mizrahi Tefahot'},numbers:['*8860']},
  {id:'discount',name:{ar:'بنك ديسكونت',he:'בנק דיסקונט',en:'Discount Bank'},numbers:['076-8050010']},
  {id:'fibi',name:{ar:'البنك الدولي (הבינלאומי)',he:'הבינלאומי',en:'First International Bank'},numbers:['*3009']},
  {id:'mercantile',name:{ar:'مركنتيل-ديسكونت',he:'מרכנתיל-דיסקונט',en:'Mercantile Discount'},numbers:['076-8050009']},
  {id:'yahav',name:{ar:'بنك يهاف',he:'בנק יהב',en:'Bank Yahav'},numbers:['*2638']},
  {id:'masad',name:{ar:'بنك مساد',he:'בנק מסד',en:'Bank Massad'},numbers:['03-5130016']},
  {id:'onezero',name:{ar:'وان زيرو',he:'וואן זירו',en:'One Zero'},numbers:['03-3767424']}
 ];
 function canon(raw){
  const s=String(raw||'').replace(/[٠-٩]/g,d=>String(d.charCodeAt(0)-0x660)).replace(/[۰-۹]/g,d=>String(d.charCodeAt(0)-0x6f0)).trim();
  if(/^\*/.test(s))return '*'+s.replace(/\D/g,'');
  let d=s.replace(/[^\d+]/g,'');
  if(d.startsWith('+972'))d='0'+d.slice(4);else if(d.startsWith('00972'))d='0'+d.slice(5);else if(d.startsWith('972')&&d.length>=11)d='0'+d.slice(3);
  d=d.replace(/\+/g,'');
  if(/^\d{4}$/.test(d))return '*'+d; // star numbers are often typed without the star
  return d;
 }
 function check(number,orgId){
  const org=ORGS.find(o=>o.id===orgId)||null,c=canon(number);
  if(!org||!c)return {org,known:!!org,matched:null,canon:c};
  return {org,known:true,matched:org.numbers.map(canon).includes(c),canon:c};
 }
 function whoOwns(number){const c=canon(number);return ORGS.find(o=>o.numbers.map(canon).includes(c))||null;}
 return {ORGS,SOURCE,check,whoOwns,canon};
})();
