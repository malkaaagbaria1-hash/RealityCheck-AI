"""Run the local server first. This example uses only fictional messages."""
import json
import httpx

BASE = "http://127.0.0.1:8000"  # Use the port printed by your server.
payload = {
    "title": "Local integration demo",
    "language": "en",
    "records": [
        {"id": "A", "text": "Enter password immediately https://sample-risk.example/check"},
        {"id": "B", "text": "ادخل كلمة المرور فورا https://sample-risk.example/check"},
    ],
}
try:
    with httpx.Client(base_url=BASE, timeout=30) as client:
        response = client.post("/api/intelligence/analyze", json=payload,
                               headers={"X-RealityCheck-Client": "web"})
        response.raise_for_status()
        report = response.json()
        print(json.dumps(report["summary"], indent=2))
        print("Candidate groups only; nothing saved. No URL was visited.")
except httpx.HTTPError as exc:
    raise SystemExit(f"Local request failed: {exc}. Start the server and check its port.")
