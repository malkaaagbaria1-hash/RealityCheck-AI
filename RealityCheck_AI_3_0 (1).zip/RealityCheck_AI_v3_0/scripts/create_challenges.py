"""Authored regression/edge cases; labels are intended scenario labels, not adjudicated incidents."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA={
'ar':{
'caution':[
'حسابك البنكي رح يتوقف خلال 24 ساعة! لازم تدخل كلمة المرور ورمز التحقق فورًا لتجنب إغلاق الحساب.',
'يا زبوننا اكتب رمز التحقق بسرعة لتفعيل الحساب المتوقف.',
'ارسل تفاصيل البطاقة عبر https://confirm.example لتجنب تعليق حسابك.',
'شحنة اليوم تحتاج ادفع رسوم توصيل فورا على https://post.example',
'ادفع بطاقات هدايا خلال 10 دقائق والا سيتم حظر حسابك.',
'ضاعف اموالك بربح مضمون حول المال فورا ولا تخبر احد.',
'ثبت TeamViewer حالا ثم اعطيني كلمة السر.',
'هذا رابط البنك https://bank.example@other.example ادخل كلمة المرور.',
'انا صاحبك تلفوني انسرق ابعت على هالحساب الجديد المبلغ الي اتفقنا عليه.',
'طلعلك تعويض كبير اضغط عالعنوان واكمل البيانات.'
],
'ordinary':[
'مرحبا يا محمد هل حضرت المحاضرة اليوم؟',
'لا تُرْسِل كلمة المرور ولا رمز التحقق لأي شخص.',
'يرجى عدم ارسال كلمة السر لأي موظف.',
'لازم ما تدخل كلمة المرور ردًا على رسالة.',
'رمز دخولك 432198 لا تشاركه مع الآخرين.',
'لن نطلب منك ان ترسل رمز التحقق في محادثة.',
'فاتورة اشتراكك موجودة في التطبيق الذي تستعمله عادة.',
'لا تثبت AnyDesk إذا ما كنت تعرف الطرف الثاني.',
'تذكير عاجل: ادفع رسوم الشحن خلال 24 ساعة. هذا طلبك المعتاد في المتجر.',
'أنا أشرح مثال عن رسالة احتيال: ادخل كلمة المرور فورًا قبل إغلاق الحساب.'
]},
'he':{
'caution':[
'דחוף החשבון ייחסם שלח קוד אימות ואת הסיסמה שלך עכשיו.',
'הקלידו פרטי אשראי בקישור https://verify.example למניעת חסימת חשבון.',
'שלם דמי משלוח מיד באתר https://parcel.example',
'זכית בפרס שלמו כרטיסי מתנה מיד.',
'רווח מובטח העבר כסף מיד ואל תספר לאף אחד.',
'הורד AnyDesk עכשיו החשבון ייסגר אם לא תפעל.',
'תשלח לי קוד אימות כדי לאשר מחדש את החשבון.',
'החשבון ייחסם היכנס https://bank.example@other.example והזן סיסמה.',
'זה אני החלפתי טלפון צריך את הסכום שסיכמנו לחשבון החדש.',
'מגיע לך החזר גדול פתח את הטופס והשלם את כל הפרטים.'
],
'ordinary':[
'היי האם תוכל לשלוח לי את המחברת מההרצאה?',
'אל תשלחו סיסמה או קוד אימות לאדם אחר.',
'לעולם אל תשלח פרטי אשראי בהודעה.',
'קוד הכניסה שלך הוא 654321 אין לשתף אותו.',
'החבילה שלך הגיעה ללוקר ליד הבית.',
'למידע נוסף אפשר לעיין בסיכום ההרצאה.',
'הפגישה מחר בחדר הישיבות כרגיל.',
'לעולם לא נבקש שתשלח סיסמה או קוד אימות.',
'תזכורת דחוף שלם דמי משלוח להזמנה הקבועה שלך.',
'בשיעור הצגנו הודעת הונאה: שלח סיסמה מיד כי החשבון ייחסם.'
]},
'en':{
'caution':[
'Act now your account will be blocked. Reply with the verification code.',
'Confirm your credit card at https://verification.example immediately.',
'Pay a delivery fee within 20 minutes at https://courier.example',
'You have won a prize pay gift cards immediately.',
'Guaranteed return transfer money now keep this secret.',
'Download AnyDesk immediately to stop account suspension.',
'Give your password and PIN to our agent now.',
'Account blocked enter password at https://bank.example@other.example',
'Hey it is me, new number. Send the amount we discussed to my replacement account.',
'A large refund awaits you. Open the form and complete all details.'
],
'ordinary':[
'Hey did you enjoy the programming lecture this afternoon?',
'Please do not share your password or verification code.',
'Never ever send your card number in a message.',
'Your sign in code is 567321. Do not share it with other people.',
'The parcel arrived in your building locker.',
'The team meeting is on Friday as planned.',
'We will never ask you to provide a password by text.',
'Beware of messages asking you to enter your password.',
'Urgent please pay the delivery fee within 24 hours for your regular order.',
'In class we examined a scam saying: enter password immediately before account closure.'
]}}
rows=[]
for lang,data in DATA.items():
 for kind,examples in data.items():
  for i,text in enumerate(examples):
   rows.append({'id':f'{lang}-{kind}-{i+1:02}','language':lang,'text':text,'expected_alert':kind=='caution',
                'source':'authored_synthetic_challenge','expected_domain':''})
(ROOT/'evaluation/challenges.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(len(rows),'authored cases; not independent field data')
