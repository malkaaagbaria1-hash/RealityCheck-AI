// Red Team Arena benchmark (3.0). Runs the portable JS engine in Node, no network.
// Usage: node scripts/redteam_benchmark.mjs [--corpus-out evaluation/redteam_corpus.json]
import fs from 'node:fs'; import path from 'node:path'; import vm from 'node:vm'; import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const J=p=>JSON.parse(fs.readFileSync(path.join(ROOT,p),'utf8'));
const ctx={console,performance,crypto:globalThis.crypto,URL};ctx.window=ctx;vm.createContext(ctx);
ctx.RC_DATA={rules:J('shared/rules.json'),signals:J('shared/signals.json'),samples:J('shared/samples.json'),entities:J('shared/entities.json'),model:J('ml/model.json')};
for(const f of ['ml','engine','redteam'])vm.runInContext(fs.readFileSync(path.join(ROOT,`frontend/src/${f}.js`),'utf8'),ctx,{filename:f+'.js'});
const challenges=J('evaluation/challenges.json'),samples=J('shared/samples.json');
const corpus=[...challenges.filter(c=>c.expected_alert).map(c=>({id:c.id,text:c.text,language:c.language,expected_domain:c.expected_domain||''})),
 ...samples.filter(s=>s.kind==='suspicious').flatMap(s=>['ar','he','en'].map(l=>({id:`${s.id}-${l}`,text:s.text[l],language:l,expected_domain:s.expected})))];
const bench=ctx.RC_RedTeam.benchmark(corpus);
// False-positive guard: benign texts must not gain alerts from the shield.
const benign=[...challenges.filter(c=>!c.expected_alert),...J('ml/training.json').filter(r=>r.label!=='caution'),...samples.filter(s=>s.kind!=='suspicious').flatMap(s=>['ar','he','en'].map(l=>({id:s.id+'-'+l,text:s.text[l],language:l})))];
let fpV2=0,fpV3=0,changed=[];
for(const b of benign){const a=ctx.RC.analyze({text:b.text,language:b.language,shield:false}),c=ctx.RC.analyze({text:b.text,language:b.language,shield:true});if(a.score>=25)fpV2++;if(c.score>=25)fpV3++;if(a.score!==c.score)changed.push({id:b.id,v2:a.score,v3:c.score});}
const allClean=[...corpus,...benign];let cleanChanged=0;for(const b of corpus){const a=ctx.RC.analyze({text:b.text,language:b.language,expected_domain:b.expected_domain,shield:false}),c=ctx.RC.analyze({text:b.text,language:b.language,expected_domain:b.expected_domain,shield:true});if(a.score!==c.score)cleanChanged++;}
const result={generated_by:'scripts/redteam_benchmark.mjs',engine_version:'3.0.0',scope:'synthetic_white_box_attack_on_authored_challenges',attacker:'white-box: rewrites only the words that triggered local rules',
 corpus_messages:corpus.length,...bench,false_positive_guard:{benign_texts:benign.length,alerts_v2:fpV2,alerts_v3:fpV3,score_changed:changed},clean_suspicious_score_changed:cleanChanged,
 limitations:['Operators and corpus authored by the project team; not a field evaluation.','Semantic paraphrase is not defended by character normalization.','Robustness = share of attack trials where the verdict level did not drop.']};
fs.writeFileSync(path.join(ROOT,'evaluation/redteam_results.json'),JSON.stringify(result,null,2));
const out=process.argv.indexOf('--corpus-out');
if(out>0){const rows=[];for(const e of J('evaluation/entity_cases.json'))rows.push({id:e.id,language:e.language,expected_domain:'',variant:'clean',text:e.text});for(const item of [...corpus,...benign]){rows.push({...item,variant:'clean'});const r=ctx.RC_RedTeam.attack(item.text,{language:item.language,expected_domain:item.expected_domain||''});for(const x of r.rows)if(x.applicable)rows.push({id:item.id,language:item.language,expected_domain:item.expected_domain||'',variant:x.id,text:x.mutated,js_v2:x.v2.score,js_v3:x.v3.score});}
 for(const row of rows)if(row.variant==='clean'){row.js_v2=ctx.RC.analyze({text:row.text,language:row.language,expected_domain:row.expected_domain||'',shield:false}).score;row.js_v3=ctx.RC.analyze({text:row.text,language:row.language,expected_domain:row.expected_domain||'',shield:true}).score;}
 fs.writeFileSync(path.join(ROOT,process.argv[out+1]),JSON.stringify(rows));}
console.log(JSON.stringify({messages:bench.messages_attacked,trials:bench.trials,robustness:bench.robustness,fp:result.false_positive_guard.alerts_v2+'->'+result.false_positive_guard.alerts_v3,changed:changed.length,cleanChanged},null,0));
for(const o of bench.operators)console.log(o.id.padEnd(11),o.trials,'v2 held',o.v2.held,'deg',o.v2.degraded,'ev',o.v2.evaded,'| v3 held',o.v3.held,'deg',o.v3.degraded,'ev',o.v3.evaded);
