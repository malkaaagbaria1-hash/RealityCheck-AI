"""Disposable local UI-test server. Never uses the real case database or live keys."""
from pathlib import Path
import sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from backend.app import create_app
from backend.integrations import Connectors
import uvicorn
if __name__=='__main__':
 with tempfile.TemporaryDirectory(prefix='realitycheck-ui-') as folder:
  print('Disposable test database; local unconfigured providers. Port 8765.')
  uvicorn.run(create_app(Path(folder)/'test.sqlite3',testing=True,connectors=Connectors()),host='127.0.0.1',port=8765,access_log=False)
