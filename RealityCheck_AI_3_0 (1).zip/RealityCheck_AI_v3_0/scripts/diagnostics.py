"""No secrets or messages printed. Runs local configuration and import checks only."""
from pathlib import Path
import importlib,importlib.metadata as md,platform,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
print('RealityCheck AI 1.0.0 diagnostics')
print('Python:',platform.python_version(),'OS:',platform.system(),platform.machine())
for mod,pkg in [('fastapi','fastapi'),('uvicorn','uvicorn'),('httpx','httpx'),('pydantic','pydantic'),('dotenv','python-dotenv'),('PIL','Pillow')]:
 try:importlib.import_module(mod);print(pkg,md.version(pkg),'OK')
 except Exception as e:print(pkg,'UNAVAILABLE',type(e).__name__)
for name in ['web/index.html','shared/rules.json','ml/model.json','backend/analyzer.py']:
 print(name,'OK' if (ROOT/name).is_file() else 'MISSING')
try:
 from backend.analyzer import analyze
 r=analyze('لازم تدخل كلمة المرور فورا')
 print('Core smoke:', 'PASS' if r['score']>=55 else 'FAIL')
except Exception as e:print('Core error type:',type(e).__name__)
print('API keys are never printed. Do not share .env or data/cases.sqlite3.')
