"""Transparent, deterministic evaluation. No credentialed service calls.
Rule benchmark is an authored development challenge. Model CV keeps families together.
Abstentions are reported in coverage; precision/recall/F1 use classified cases only.
"""
import hashlib,json,sys,platform,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from backend.analyzer import analyze
from backend.ml_model import train,predict

def metrics(tp,fp,fn,tn):
 p=tp/(tp+fp) if tp+fp else 0;r=tp/(tp+fn) if tp+fn else 0
 return {'precision':p,'recall':r,'f1':2*p*r/(p+r) if p+r else 0,'accuracy':(tp+tn)/max(1,tp+fp+fn+tn),
         'confusion':{'tp':tp,'fp':fp,'fn':fn,'tn':tn}}

def run():
 tests=json.loads((ROOT/'evaluation/challenges.json').read_text(encoding='utf-8'))
 counts={'tp':0,'fp':0,'fn':0,'tn':0};errors=[];details=[];t0=time.perf_counter()
 for row in tests:
  result=analyze(row['text'],language=row['language'],expected_domain=row['expected_domain'])
  actual=result['score']>=25;want=row['expected_alert'];key=('tp' if want else 'fp') if actual else ('fn' if want else 'tn');counts[key]+=1
  detail={**row,'score':result['score'],'predicted_alert':actual,'correct':actual==want,'codes':[s['code'] for s in result['signals']]};details.append(detail)
  if actual!=want:errors.append(detail)
 rules={**metrics(**counts),'samples':len(tests),'threshold':25,'source':'authored_synthetic_challenge','independent':False,'errors':errors,'elapsed_ms':round((time.perf_counter()-t0)*1000,2)}
 rows=json.loads((ROOT/'ml/training.json').read_text(encoding='utf-8'))
 # Each language/label group has 20 families; two augmentations in each family.
 family_fold={}
 for lang in ('ar','he','en'):
  for label in ('ordinary','caution'):
   families=sorted({r['family'] for r in rows if r['language']==lang and r['label']==label},key=lambda f:hashlib.sha256(('fixed-seed-42/'+f).encode()).hexdigest())
   family_fold.update({f:i%5 for i,f in enumerate(families)})
 counts={'tp':0,'fp':0,'fn':0,'tn':0};abstain=0;folds=[];predictions=[]
 for fold in range(5):
  training=[r for r in rows if family_fold[r['family']]!=fold];validation=[r for r in rows if family_fold[r['family']]==fold]
  assert not ({r['family'] for r in training}&{r['family'] for r in validation})
  model=train(training);folds.append({'fold':fold,'train':len(training),'validation':len(validation),'family_overlap':0})
  for row in validation:
   out=predict(row['text'],model);predictions.append({'id':row['id'],'fold':fold,'label':row['label'],'prediction':out['label'],'status':out['status']})
   if out['status']!='completed':abstain+=1;continue
   actual=out['label']=='caution_pattern';want=row['label']=='caution';key=('tp' if want else 'fp') if actual else ('fn' if want else 'tn');counts[key]+=1
 model={**metrics(**counts),'samples':len(rows),'classified':len(rows)-abstain,'abstentions':abstain,'coverage':(len(rows)-abstain)/len(rows),'folds':folds,'source':'authored_synthetic','real_world_validated':False,'metric_scope':'classified_cases_only','family_overlap':0}
 old=json.loads((ROOT/'evaluation/results.json').read_text()) if (ROOT/'evaluation/results.json').exists() else {}
 result={'version':'1.0.0','date':'2026-11-05','scope':'synthetic_only','rules':rules,'model':model,
         'functional':old.get('functional',{}),'browser':old.get('browser',{}),
         'external_providers':'Mock tested only; no live API credentials used.',
         'environment':f'{platform.system()} / Python {platform.python_version()}'}
 (ROOT/'evaluation/results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'evaluation/rule_predictions.json').write_text(json.dumps(details,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'evaluation/model_predictions.json').write_text(json.dumps(predictions,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Rules:',rules['confusion'],'precision',round(rules['precision'],3),'recall',round(rules['recall'],3))
 print('Synthetic model CV:',model['confusion'],'coverage',round(model['coverage'],3),'F1',round(model['f1'],3))
 return result
if __name__=='__main__':run()
