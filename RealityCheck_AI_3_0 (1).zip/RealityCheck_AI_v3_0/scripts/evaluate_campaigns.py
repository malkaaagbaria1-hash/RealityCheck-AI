"""Standalone synthetic correlation benchmark, distinct from the 37-message UI demo.

No training occurs here. Thresholds are fixed in backend/campaigns.py. Includes
intentional difficult cases: cross-language domain rotation (misses) and shared
compromised infrastructure (possible false merges). Results are not field accuracy.
"""
from pathlib import Path
import hashlib, json, sys, time
from itertools import combinations
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from backend.campaigns import analyze_campaign, redact, ENGINE
from backend.campaign_models import CampaignRequest

def dataset():
 rows=[];labels={}
 def add(text,label):
  rid=f'E{len(rows)+1:03}';rows.append({'id':rid,'text':text});labels[rid]=label
 # Unseen domains / texts, with multilingual variants and repeated action cues.
 credential=[
  'Atlas service requires an access review. Please provide your password immediately at {url}',
  'مراجعة خدمة أطلس: ادخل كلمة المرور فورا لإعادة التفعيل عبر {url}',
  'שירות אטלס: מסור סיסמה מיד לצורך בדיקת הגישה {url}',
  'Service access expires today. Enter your verification code immediately using {url}',
  'أطلس: لازم تبعت رمز التحقق فورا من الرابط {url}',
  'בדיקת שירות: הזן קוד אימות מיד בקישור {url}',
 ]
 payments=[
  'Your import notice has arrived. Pay the processing fee immediately {url}',
  'معاملة الاستيراد معلقة. ادفع رسوم الشحن فورا عبر {url}',
  'תשלום נדרש. שלם דמי משלוח מיד בקישור {url}',
  'Customs release pending: transfer money immediately at {url}',
  'ادفع رسوم توصيل فورا قبل إرجاع الطرد {url}',
 ]
 for i in range(6):
  for k,template in enumerate(credential if i%2==0 else payments):
   add(template.format(url=f'https://atlas-case-{i}.example/p/{k}'),f'family-{i}')
 # Distinctive same-language template with rotating domains.
 for i in range(6):
  add('Research grant eligibility has reached the final identity step. Send your password and verification code immediately to maintain eligibility for the current award review. '+f'https://grant-node-{i}.example/check','grant')
 # Hard positive: shared contact and reformulated text do not reliably pass threshold.
 for text in ['ارسال كلمة المرور مطلوب للمراجعة فورا. بريد الدعم help@case-contact.example',
              'Provide your password immediately for the verification review: help@case-contact.example',
              'מסור סיסמה מיד לצורך בדיקה. help@case-contact.example']:
  add(text,'contact-family')
 # Hard positive: translations on different domains have no observable anchor.
 for text in ['ادخل كلمة المرور فورا https://lang-one.example/a',
              'הזן סיסמה מיד https://lang-two.example/b',
              'Enter password immediately https://lang-three.example/c']:
  add(text,'translated-rotating')
 # Hard negative: two different hypothetical campaigns hosted on a compromised host.
 # The algorithm cannot know their independent identities from hostname/intent alone.
 for k,text in enumerate([
  'Bright checking: enter your password immediately https://compromised-host.example/checking',
  'Bright login: provide your verification code immediately https://compromised-host.example/bright',
  'Ledger app: enter password immediately https://compromised-host.example/ledger',
  'Ledger recovery: send your verification code immediately https://compromised-host.example/recover']):
  add(text,'shared-host-A' if k<2 else 'shared-host-B')
 benign=[
  'اجتماع الفريق مساء الخميس. لا ترسل كلمة المرور لأي شخص.',
  'אל תשלח קוד אימות. המפגש המקוון מתחיל מחר.',
  'Never share your password. Your booking is confirmed.',
  'Reminder: the workshop room is now open.',
  'وصل طلبك إلى مركز الاستلام ويمكنك استلامه غدا.',
  'המשלוח הגיע לנקודת האיסוף, תודה רבה.',
 ]
 for i in range(24):add(benign[i%len(benign)]+f' Reference {1000+i}.',f'benign-{i}')
 for i in range(10):
  text=('Enter your password immediately ' if i%2==0 else 'ادفع رسوم الشحن فورا ')
  add(text+f'https://bit.ly/independent-{i}',f'shortener-single-{i}')
 return {'scope':'synthetic_only','records':rows,'labels':labels}

def main():
 data=dataset();request=CampaignRequest(records=data['records'],title='Synthetic development benchmark v2',language='en')
 started=time.perf_counter();r=analyze_campaign(request);elapsed=(time.perf_counter()-started)*1000
 actual=data['labels'];pred={row['id']:(row['group_id'] or row['id']) for row in r['records']}
 previews={row['id']:row['preview'] for row in r['records']}
 tp=fp=fn=tn=0;errors=[]
 for a,b in combinations(sorted(actual),2):
  want=actual[a]==actual[b];got=pred[a]==pred[b]
  if want and got:tp+=1
  elif not want and got:fp+=1
  elif want and not got:fn+=1
  else:tn+=1
  if want!=got:errors.append({'a':a,'b':b,'kind':'false_merge' if got else 'missed_link','preview_a':previews[a],'preview_b':previews[b]})
 precision=tp/(tp+fp) if tp+fp else 0;recall=tp/(tp+fn) if tp+fn else 0
 f1=2*precision*recall/(precision+recall) if precision+recall else 0
 canonical=json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':'))
 output={'status':'completed','scope':'synthetic_only','real_world_validated':False,
  'engine_version':ENGINE,'records':len(data['records']),'pairs':tp+fp+fn+tn,
  'dataset_sha256':hashlib.sha256(canonical.encode()).hexdigest(),
  'config':r['config'],'analysis_ms':round(elapsed,2),
  'pair_metrics':{'tp':tp,'fp':fp,'fn':fn,'tn':tn,'precision':round(precision,6),'recall':round(recall,6),'f1':round(f1,6)},
  'groups':r['summary']['candidate_groups'],'errors':errors,
  'note':'Separate synthetic development fixture, used during debugging; not a blind holdout or collected incidents. Shared infrastructure can cause false merges; translations without shared indicators can be missed. No inference about field accuracy or commercial superiority.'}
 (ROOT/'evaluation/campaign_benchmark.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'evaluation/campaign_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:output[k] for k in ['records','pairs','groups','analysis_ms','pair_metrics']},indent=2))
if __name__=='__main__':main()
