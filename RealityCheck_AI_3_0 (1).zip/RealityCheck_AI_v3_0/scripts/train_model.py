"""Reproducible synthetic baseline training; no external service or hidden download."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from backend.ml_model import train
p=ROOT/'ml/training.json'; rows=json.loads(p.read_text(encoding='utf-8'))
model=train(rows);model['training_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'ml/model.json').write_text(json.dumps(model,ensure_ascii=False,sort_keys=True,separators=(',',':')),encoding='utf-8')
print(f"Trained {model['algorithm']} on {len(rows)} synthetic rows, {len(model['weights'])} features.")
print('Not a pre-trained language model. Not validated on real-world phishing.')
