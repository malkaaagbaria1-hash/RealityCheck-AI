"""Reproducible SYNTHETIC fixtures. They are not collected messages or real incidents."""
from pathlib import Path
from datetime import datetime, timedelta, timezone
import csv, json
ROOT=Path(__file__).resolve().parents[1]

def record(i,text,hours=0,channel='sms'):
    return {'id':f'M{i:03}','text':text,'channel':channel,
            'received_at':(datetime(2026,10,26,8,tzinfo=timezone.utc)+timedelta(hours=hours)).isoformat()}

rows=[]; truth={}
def group(name,texts):
    for text in texts:
        i=len(rows)+1
        rows.append(record(i,text,hours=(i*7)%150,channel=['sms','email','whatsapp'][i%3]))
        truth[f'M{i:03}']=name

group('cedar',[
 'بنك الأرز: حسابك رح يتوقف خلال 24 ساعة. لازم تدخل كلمة المرور ورمز التحقق فورا على https://cedar-verify.example/confirm',
 'Cedar Bank: your account will be suspended. Enter your password and verification code immediately at https://cedar-verify.example/confirm',
 'בנק ארז: החשבון ייסגר. שלח סיסמה וקוד אימות מיד באתר https://cedar-verify.example/check',
 'بنك الأرز: يرجى ارسال كلمة السر الآن لتجنب اغلاق الحساب: https://cedar-verify.example/activate',
 'Cedar Bank security review. Provide your password at https://cedar-verify.example/access immediately.',
 'בנק ארז: הזן קוד אימות מיד לפני חסימת חשבון https://cedar-verify.example/check',
])
group('parcel',[
 'شحنة سحاب: ادفع رسوم الشحن فورا لإتمام التوصيل https://parcel-fee.example/pay',
 'Sahab Parcel: payment required. Pay the delivery fee immediately at https://parcel-fee.example/pay',
 'דואר סחאב: תשלום נדרש. שלם דמי משלוח מיד באתר https://parcel-fee.example/track',
 'شحنة سحاب متوقفة: ادفع رسوم توصيل فورا https://parcel-fee.example/release',
 'Your parcel is waiting. Transfer money for the processing fee immediately https://parcel-fee.example/checkout',
])
group('support',[
 'خدمة الدعم: ثبت AnyDesk فورا. لا تخبر احد. https://desk-support.example/install',
 'Technical support: install AnyDesk immediately. Keep this secret. https://desk-support.example/install',
 'תמיכה: התקן AnyDesk מיד. אל תספר לאף אחד. https://desk-support.example/start',
 'نزل TeamViewer فورا لحل مشكلة جهازك من https://desk-support.example/help',
])
group('investment',[
 'ارباح مضمونة بدون مخاطر! ادفع بيتكوين فورا عبر https://bright-invest.example/join',
 'Guaranteed profit. Send bitcoin immediately and double your money at https://bright-invest.example/join',
 'רווח מובטח ללא סיכון. שלם ביטקוין מיד https://bright-invest.example/pay',
 'ضاعف اموالك. حول عملات رقمية فورا من https://bright-invest.example/join',
])
group('rotating_template',[
 'Your subscription identity needs a final check. Send your password and verification code immediately so that the membership is not suspended. https://member-proof-a.example/check',
 'Your subscription identity needs a final check. Send your password and verification code immediately so that the membership is not suspended. https://member-proof-b.example/check',
 'Your subscription identity needs a final check. Send your password and verification code immediately so that the membership is not suspended. https://member-proof-c.example/check',
])
# An exact repeat is included deliberately, and reported separately from message count.
rows.append(record(len(rows)+1,rows[0]['text'],hours=149,channel='whatsapp'));truth[rows[-1]['id']]='cedar'
benign=[
 'مرحبًا، موعد اجتماع الفريق غدا الساعة العاشرة. لا ترسل كلمة المرور لأي شخص.',
 'Your appointment is confirmed for next Tuesday. No action is required.',
 'שלום, ההרצאה תתחיל מחר בשעה עשר. אין צורך למסור פרטים.',
 'بنك الأرز: لا ترسل كلمة المرور أو رمز التحقق. افتح تطبيق البنك بنفسك.',
 'Cedar Bank: never share your password. Information is at https://cedarbank.example/security',
 'השיעור הבא יתמקד במבני נתונים. פרטי הקורס ב https://courses.example/syllabus',
 'Your receipt is ready. Thank you for visiting our shop.',
 'شحنة سحاب وصلت لنقطة الاستلام. يمكنك استلامها غدا.',
 'A colleague shared a document: https://docs.google.com/document/d/example-one',
 'A different team shared notes: https://docs.google.com/document/d/example-two',
 'Do not send your password to anyone. Beware of messages using https://cedar-verify.example/confirm',
 'אל תשלח קוד אימות לאף אחד. זוהי תזכורת אבטחה.',
]
for text in benign:
 i=len(rows)+1;rows.append(record(i,text,hours=i*4));truth[f'M{i:03}']=f'single-{i}'
# Two suspicious but unrelated links on a shared shortening service must NOT link.
for text in ['Enter your password immediately at https://bit.ly/unique-a',
             'Pay the processing fee immediately at https://bit.ly/unique-b']:
 i=len(rows)+1;rows.append(record(i,text,hours=i*4));truth[f'M{i:03}']=f'single-{i}'
# No timestamp supplied: preserve unknown rather than inventing an observation date.
rows[-1]['received_at']=None
profile={'name':'Cedar Bank','aliases':['بنك الأرز','בנק ארז'], 'official_domains':['cedarbank.example']}
demo={'synthetic':True,'description':'Fictional multilingual training exercise. No real incidents or customers.',
      'title':'Cedar / Parcel / Support — synthetic exercise','records':rows,'profile':profile}
(ROOT/'shared/campaign_demo.json').write_text(json.dumps(demo,ensure_ascii=False,indent=2),encoding='utf-8')
examples=ROOT/'examples';examples.mkdir(exist_ok=True)
(examples/'campaign_demo.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
with (examples/'campaign_demo.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','text','channel','received_at']);w.writeheader();w.writerows(rows)
(examples/'campaign_demo.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows),encoding='utf-8')
(examples/'messages.txt').write_text('\n'.join(r['text'] for r in rows),encoding='utf-8')
(ROOT/'evaluation/campaign_demo_truth.json').write_text(json.dumps(truth,indent=2),encoding='utf-8')
print(f'Created {len(rows)} synthetic demo messages; {len(set(v for v in truth.values() if not v.startswith("single")))} campaign families.')
