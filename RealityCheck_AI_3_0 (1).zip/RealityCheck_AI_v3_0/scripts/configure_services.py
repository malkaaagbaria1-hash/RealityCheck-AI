"""Optional server-only key setup. Never exposes keys to browser or prints their values."""
from pathlib import Path
import getpass,re,os
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'.env'
print('Optional external services. Local rules, ML, and local assistant work without keys.')
print('Your own provider account, permissions, model access and usage charges may be required.')
if path.exists() and input('Replace existing .env settings? Type YES: ').strip()!='YES':raise SystemExit('No changes made.')
key=getpass.getpass('OpenAI API key (blank to disable): ').strip()
model=input('OpenAI model id enabled in your account (blank to disable): ').strip() if key else ''
vt=getpass.getpass('VirusTotal key (blank to disable): ').strip()
for value in [key,model,vt]:
 if value and not re.fullmatch(r'[A-Za-z0-9_.:/-]+',value):raise SystemExit('Unexpected characters; settings not saved.')
path.write_text(f'OPENAI_API_KEY={key}\nOPENAI_MODEL={model}\nVIRUSTOTAL_API_KEY={vt}\n',encoding='utf-8')
try:os.chmod(path,0o600)
except OSError:pass
print('Saved locally. Restart START_WINDOWS.bat. Approve each external analysis in the app.')
print('Do not upload or share .env. Provider retention policies still apply.')
