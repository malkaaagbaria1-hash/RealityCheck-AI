"""Create an isolated environment with the selected interpreter and launch locally.

Invoked by START_WINDOWS.bat / START_MAC_LINUX.sh. No credentials, user messages,
or private report content are written to the installation log.
"""
from __future__ import annotations
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import venv
ROOT = Path(__file__).resolve().parents[1]

def main() -> int:
    os.chdir(ROOT)
    print('RealityCheck AI 3.0.0 | Red Team Edition\n', flush=True)
    print('Local computer only. Keep this window open. No API keys needed for local features.', flush=True)
    print(f'Interpreter: {sys.version.split()[0]}', flush=True)
    if sys.version_info < (3,11):
        print('Python 3.11 or newer is required. On Windows: py install 3.13', flush=True)
        return 1
    env = ROOT/'.venv'
    interpreter = env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    logs = ROOT/'data'; logs.mkdir(exist_ok=True)
    if not interpreter.is_file():
        print('[1/3] Creating the local Python environment...', flush=True)
        try:
            venv.EnvBuilder(with_pip=True).create(env)
        except Exception as exc:
            print(f'Environment creation failed: {type(exc).__name__}. Run DIAGNOSTICS.bat.',flush=True)
            return 1
    requirement = ROOT/'requirements.txt'
    digest = hashlib.sha256(requirement.read_bytes()).hexdigest()
    marker = env/'realitycheck-requirements.sha256'
    valid = subprocess.run([str(interpreter),'-c','import fastapi,uvicorn,httpx,pydantic,dotenv,PIL'],
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode == 0
    if not valid or not marker.exists() or marker.read_text().strip()!=digest:
        print('[2/3] Installing project packages. Internet is needed for this step.',flush=True)
        cmd = [str(interpreter),'-m','pip','install','--disable-pip-version-check','--prefer-binary','-r',str(requirement)]
        try:
            with (logs/'startup.log').open('w',encoding='utf-8') as log:
                process = subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                           text=True,encoding='utf-8',errors='replace',bufsize=1)
                assert process.stdout is not None
                for line in process.stdout:
                    print(line,end='',flush=True);log.write(line)
                code = process.wait()
            if code:
                print('Installation did not finish. See data/startup.log. Do not edit source code.',flush=True)
                print('Python 3.13 is a good fallback if a newer runtime has no binary package wheels.',flush=True)
                return code
            marker.write_text(digest,encoding='ascii')
        except OSError as exc:
            print(f'Cannot run installation: {type(exc).__name__}',flush=True)
            return 1
    else:
        print('[2/3] Project packages are already available.',flush=True)
    print('[3/3] Starting the server. Your browser opens after the health check.',flush=True)
    try:
        return subprocess.call([str(interpreter),str(ROOT/'run.py')])
    except KeyboardInterrupt:
        print('\nServer stopped. Your saved investigations remain on this computer.',flush=True)
        return 0

if __name__=='__main__':
    raise SystemExit(main())
