@echo off
setlocal
cd /d "%~dp0"
echo RealityCheck AI 2.0 diagnostics - no secret values are printed.
where py
where python
py list
if exist ".venv\Scripts\python.exe" goto venv
py -3.13 scripts\diagnostics.py
goto done
:venv
.venv\Scripts\python.exe scripts\diagnostics.py
:done
pause
