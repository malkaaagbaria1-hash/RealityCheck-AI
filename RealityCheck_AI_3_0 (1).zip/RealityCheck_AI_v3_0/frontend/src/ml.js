/* Learned baseline in the browser. Same JSON weights as Python. No network. */
window.RC_ML=(()=>{
 const matching=text=>text.normalize('NFKC').replace(/[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7\u0640\u200b-\u200d\ufeff]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/[’‘]/g,"'");
 function features(text){
  const content=matching(text.toLowerCase()).replace(/https?:\/\/\S+/g,' urltoken ').replace(/[\p{N}]+/gu,' numtoken ');
  const words=content.match(/\p{L}+/gu)||[],out={}; const add=k=>out[k]=(out[k]||0)+1;
  words.forEach(w=>add('w:'+w));for(let i=0;i<words.length-1;i++)add('b:'+words[i]+' '+words[i+1]);
  for(const w of words)if([...w].length>=4){const p='^'+w+'$';for(let i=0;i<p.length-2;i++)add('c:'+p.slice(i,i+3));}
  return out;
 }
 function predict(text){
  const model=RC_DATA.model;if(!model)return {status:'unavailable',label:null,top_features:[]};
  const f=features(text),known=Object.entries(f).filter(([k])=>Object.hasOwn(model.weights,k));
  const coverage=known.reduce((a,[,n])=>a+n,0)/Math.max(1,Object.values(f).reduce((a,b)=>a+b,0));
  const margin=model.prior_log_odds+known.reduce((a,[k,n])=>a+n*model.weights[k],0);
  const reason=coverage<model.minimum_coverage||known.length<model.minimum_known_features?'low_coverage':Math.abs(margin)<model.abstain_margin?'close_margin':null;
  const top=known.filter(([k])=>k.startsWith('w:')||k.startsWith('b:')).map(([k,n])=>({feature:k.slice(2),contribution:n*model.weights[k]})).sort((a,b)=>Math.abs(b.contribution)-Math.abs(a.contribution)).slice(0,6);
  return {status:reason?'abstained':'completed',reason,label:reason?null:margin>0?'caution_pattern':'ordinary_pattern',raw_margin:Math.round(margin*1000)/1000,coverage,top_features:top,model_version:model.version,source:model.source,training_rows:model.training_rows,is_probability:false,affects_rule_score:false,real_world_validated:false};
 }
 return {matching,predict,features};
})();
