/* Portable local analyzer. Shares rule data with backend/analyzer.py. No network I/O. */
window.RC = (() => {
  const rules=window.RC_DATA.rules, signals=window.RC_DATA.signals;
  const shorten=new Set(['bit.ly','tinyurl.com','t.co','goo.gl','cutt.ly','rb.gy','shorturl.at','is.gd','ow.ly','buff.ly']);
  const urlRe=/(?:https?:\/\/|hxxps?:\/\/|www\.)[^\s<>"\u201c\u201d]+/gi;
  const bidi=/[\u202a-\u202e\u2066-\u2069]/;
  const unusedNegation=/(?:\b(?:never|do not|don't|not to)\s+|(?:لا|ما)\s+(?:ت)?|אל\s+(?:ת)?)$/i;
  const normalize=t=>t.normalize('NFKC').replaceAll('hxxps://','https://').replaceAll('hxxp://','http://').replaceAll('[.]','.').replaceAll('(.)','.');
  function domain(v){
    v=v.trim().toLowerCase().replace(/\.$/,''); if(!v)return '';
    if(v.includes('://')||/[\/@?#:\s]/.test(v)||!v.includes('.'))throw Error('INVALID_DOMAIN');
    try {v=new URL('https://'+v).hostname;}catch{throw Error('INVALID_DOMAIN');}
    if(v.length>253||v.split('.').some(p=>!/^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)$/.test(p)))throw Error('INVALID_DOMAIN');
    return v;
  }
  function parse(raw){
    raw=raw.trim().replace(/[.,;!،؛。)]+$/,''); let v=normalize(raw);
    if(bidi.test(v)||/[\\\x00-\x1f]/.test(v))throw Error('INVALID_URL');
    if(!/^https?:\/\//i.test(v)){
      if(v.includes('://')||/^(javascript|data|file|mailto):/i.test(v))throw Error('INVALID_URL');
      v='https://'+v;
    }
    if(v.length>4096)throw Error('INVALID_URL');
    let u; try{u=new URL(v);}catch{throw Error('INVALID_URL');}
    let host=u.hostname.toLowerCase().replace(/\.$/,'').replace(/^\[|\]$/g,'');
    if(!host||/[%\s]/.test(host))throw Error('INVALID_URL');
    let is_ip=/^(\d{1,3}\.){3}\d{1,3}$/.test(host)||host.includes(':');
    if(!is_ip&&host!=='localhost')domain(host);
    let privateHost=host==='localhost'||/\.(localhost|local|internal|lan)$/.test(host);
    if(is_ip){
      if(host.includes(':'))privateHost=/^(::|fc|fd|fe8|fe9|fea|feb|2001:db8)/i.test(host);
      else {let [a,b]=host.split('.').map(Number);privateHost=a===0||a===10||a===127||a>=224||(a===192&&b===168)||(a===172&&b>=16&&b<=31)||(a===169&&b===254)||(a===100&&b>=64&&b<=127)||/^192\.0\.2\.|^198\.51\.100\.|^203\.0\.113\./.test(host);}
    }
    const demo=/\.(example|test|invalid|localhost)$/.test(host)||/^(.*\.)?example\.(com|org|net)$/.test(host);
    // Browser URL exposes ASCII form; mixed-script hints inspect the original hostname.
    const originalHost=v.split('://')[1].split('/')[0].split('@').pop().split(':')[0];
    const scripts=[/[A-Za-z]/,/[\u0400-\u04ff]/,/[\u0370-\u03ff]/].filter(re=>re.test(originalHost));
    return {raw,host,unicode_host:originalHost,scheme:u.protocol.slice(0,-1),port:u.port?Number(u.port):null,has_userinfo:!!u.username||v.split('://')[1].split('/')[0].includes('@'),is_ip,is_private:privateHost,idn:host.includes('xn--'),mixed_script:scripts.length>1,demo,eligible:!is_ip&&!privateHost&&!demo};
  }
  function urls(t){
    const found=[...t.matchAll(urlRe)].map(m=>m[0].replace(/[.,;!،؛。)]+$/,''));
    for(let token of t.split(/\s+/)){
      token=token.replace(/^[()[\]{}<>,;!،؛"']+|[()[\]{}<>,;!،؛"']+$/g,'');
      if(!token.includes('@')&&token.includes('.')&&!token.includes('://')&&!found.includes(token)&&/^[^\s/:]+\.[a-zA-Z\u0080-\uffff]{2,}(\/[^\s]*)?$/.test(token))found.push(token);
    }
    return [...new Set(found)];
  }

  /* 3.0 Evasion Shield — mirrors backend/matching.py shield_view (parity-tested). */
  const SH_DROP=new Set([...'­͏؜ᅟᅠ឴឵᠎‎‏⁠⁡⁢⁣⁤ㅤﾠ',...Array.from({length:16},(_,i)=>String.fromCharCode(0xfe00+i))]);
  const SH_CONF={'ک':'ك','ڪ':'ك','ی':'ي','ې':'ي','ہ':'ه','ە':'ه','ۀ':'ه','а':'a','е':'e','о':'o','р':'p','с':'c','х':'x','у':'y','і':'i','ј':'j','ѕ':'s','ԁ':'d','ӏ':'l','һ':'h','ԛ':'q','ԝ':'w','ո':'n','А':'a','В':'b','Е':'e','К':'k','М':'m','Н':'h','О':'o','Р':'p','С':'c','Т':'t','Х':'x','У':'y','І':'i','α':'a','ε':'e','ο':'o','ρ':'p','τ':'t','ν':'v','κ':'k','ι':'i','υ':'u','χ':'x','Α':'a','Β':'b','Ε':'e','Η':'h','Ι':'i','Κ':'k','Μ':'m','Ν':'n','Ο':'o','Ρ':'p','Τ':'t','Χ':'x','Υ':'y','Ζ':'z'};
  for(let i=0;i<10;i++){SH_CONF[String.fromCharCode(0x660+i)]=String(i);SH_CONF[String.fromCharCode(0x6f0+i)]=String(i);}
  const SH_LEET={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s'};
  const SH_JOIN=new Set([...'-*·•|_~^+']),SH_SPACE=new Set([' ','.']);
  const isLatin=c=>/^[A-Za-z]$/.test(c),isLetter=c=>/^\p{L}$/u.test(c),isDigit=c=>/^\p{Nd}$/u.test(c),isSymbol=c=>/^\p{So}$/u.test(c);
  function shieldView(content,positions){
    let items=[];
    for(let i=0;i<content.length;){const cp=content.codePointAt(i),c=String.fromCodePoint(cp),p=positions[i];i+=c.length;if(SH_DROP.has(c))continue;items.push([SH_CONF[c]??c,p]);}
    let n=items.length;
    for(let i=0;i<n;){
      const c0=items[i][0];
      if(isLatin(c0)||isDigit(c0)||c0==='@'||c0==='$'){
        let j=i;while(j<n&&(isLatin(items[j][0])||isDigit(items[j][0])||'@$'.includes(items[j][0])||SH_JOIN.has(items[j][0])))j++;
        let letters=0,leet=0;for(let k=i;k<j;k++){if(isLatin(items[k][0]))letters++;if(items[k][0] in SH_LEET)leet++;}
        if(letters>=2&&leet&&leet<=letters*2)for(let k=i;k<j;k++)items[k][0]=SH_LEET[items[k][0]]??items[k][0];
        i=Math.max(j,i+1);
      }else i++;
    }
    let out=[];const joiner=c=>SH_JOIN.has(c)||isSymbol(c);
    for(let k=0;k<items.length;k++){const [c]=items[k];
      if(joiner(c)&&out.length&&isLetter(out[out.length-1][0])){let m=k+1;while(m<items.length&&joiner(items[m][0]))m++;if(m<items.length&&isLetter(items[m][0]))continue;}
      out.push(items[k]);}
    items=out;out=[];n=items.length;
    for(let i=0;i<n;){
      const c=items[i][0];
      if(isLetter(c)&&(i===0||!isLetter(items[i-1][0]))&&(i+1>=n||!isLetter(items[i+1][0]))){
        const run=[i];let j=i+1;
        for(;;){let k=j,seps=0;while(k<n&&SH_SPACE.has(items[k][0])&&seps<2){k++;seps++;}if(!seps||k>=n||!isLetter(items[k][0])||(k+1<n&&isLetter(items[k+1][0])))break;run.push(k);j=k+1;}
        if(run.length>=4){run.forEach(r=>out.push(items[r]));i=j;continue;}
      }
      out.push(items[i]);i++;
    }
    const pos=[];let str='';for(const [c,p] of out){str+=c;for(let u=0;u<c.length;u++)pos.push(p);}
    return {content:str,positions:pos};
  }

  /* 3.0.1 Built-in identity hints — mirrors backend/analyzer.py claimed_entity (parity-tested). */
  const ENT=window.RC_DATA.entities||{entities:[],government_patterns:[]};
  const reEsc=x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const cuePattern=cue=>{const c=Array.from(cue).map(ch=>RC_ML.matching(ch)).join('').toLowerCase(),b=reEsc(c);
    if(/[֐-׿]/.test(c))return '(?<![\\u0590-\\u05ff])[והבלמשכ]{0,2}'+b+'(?![\\u0590-\\u05ff])';
    if(/[؀-ۿ]/.test(c))return '(?<![\\u0600-\\u06ff])(?:[وفب]?ال|لل|[وفبلك]{0,2})'+b+'(?![\\u0600-\\u06ff])';
    return '(?<![a-z0-9])'+b+'(?![a-z0-9])';};
  const GOV=ENT.government_patterns.map(p=>new RegExp(p));
  const ENTITIES=[...ENT.entities].sort((a,b)=>(a.kind==='government')-(b.kind==='government')).map(e=>({e,re:new RegExp(e.cues.map(cuePattern).join('|'),'iu')}));
  const claimedEntity=content=>{const low=content.toLowerCase();for(const x of ENTITIES)if(x.re.test(low))return x.e;return null;};
  const officialHost=(e,host)=>e.official.some(d=>host===d||host.endsWith('.'+d))||(e.kind==='government'&&GOV.some(p=>p.test(host)));
  const baitTokens=e=>[...new Set([...e.official.map(d=>d.split('.')[0].replace(/-/g,'')),...e.cues.map(c=>c.toLowerCase()).filter(c=>/^[a-z0-9]{3,}$/.test(c))])].filter(t=>t.length>=3);
  function analyze({text,input_type='message',language='ar',expected_domain='',shield=true}){
    text=text.trim(); if(!text||text.length>12000)throw Error('INVALID_INPUT');
    const expected=domain(expected_domain), normalized=normalize(text), evidence=[],links=[];
    function add(code,weight,value,group='url'){
      const s=signals[code];evidence.push({code,group,weight,severity:weight>=28?'high':weight?'medium':'info',title:s.title[language],detail:s.detail[language],evidence:String(value).slice(0,300)});
    }
    const started=performance.now(),suppressed=[];
    const mapped=[],basePositions=[];let originalPos=0;
    for(const ch of text){const part=RC_ML.matching(ch);for(let i=0;i<part.length;i++){mapped.push(part[i]);basePositions.push(originalPos);}originalPos+=ch.length;}
    let content=mapped.join('').replace(urlRe,m=>' '.repeat(m.length)),positions=basePositions;
    if(shield)({content,positions}=shieldView(content,positions));
    const negative=/(?:\b(?:never|do not|don't|not to|avoid|not|will not|won't|must not)\s+(?:ever\s+|please\s+)?)$|(?:(?:^|[^\p{L}\p{N}_])(?:لا|ولا|ما|اياك ان|اياك|ممنوع|ليس عليك ان|لازم ما|لا تقم ب|لا تقومي ب|يرجي عدم|عدم)\s+)$|(?:(?<![\u0590-\u05ff])(?:אל|לא|אין|אין צורך|לעולם אל|אסור)\s+)$/iu;
    const warning=/\b(?:beware of|watch out for|warning about|example of|scam example|never (?:ask|request))\b|(?:احذر من|احذروا من|مثال (?:عن|علي)|رسالة احتيال|لن نطلب|لن يطلب|لا نطلب|لا يطلب)|(?:היזהרו מהודעות|דוגמה להונאה|לעולם לא נבקש)/i;
    if(input_type!=='url')for(const r of rules){
      const pattern=r.pattern.replaceAll('\\w','[\\p{L}\\p{N}_]');
      const reg=new RegExp(pattern,'giu');let m;
      while((m=reg.exec(content))!==null){
        const lo=positions[m.index],hi=positions[m.index+m[0].length-1]+1;
        const before=content.slice(Math.max(0,m.index-110),m.index).split(/[.!?\n؛]/).pop();
        const sensitive=['credentials','payment','remote_access','secrecy','unusual_payment'].includes(r.code);
        const reason=sensitive&&(negative.test(before)?'negated_request':warning.test(before)?'warning_context':null);
        if(reason){suppressed.push({code:r.code,reason,evidence:text.slice(lo,hi).slice(0,300)});continue;}
        evidence.push({code:r.code,group:r.group,weight:r.weight,severity:r.weight>=28?'high':'medium',title:r.title[language],detail:r.detail[language],evidence:text.slice(lo,hi).slice(0,300),start:lo,end:hi,source:'local_rule'});break;
      }
    }
    let entity=(expected||input_type==='url')?null:claimedEntity(content);
    if(entity&&entity.kind==='government'&&!evidence.some(x=>x.weight))entity=null;
    const candidates=input_type==='url'?[text]:urls(normalized);let invalid=0;
    for(const candidate of candidates.slice(0,10)){
      let p;try{p=parse(candidate);}catch(e){if(input_type==='url')throw e;invalid++;continue;}
      links.push(p);
      if(p.scheme==='http')add('http',5,p.host);
      if(p.has_userinfo)add('userinfo',28,p.host);
      if(p.is_private)add('private',0,p.host);else if(p.is_ip)add('ip',12,p.host);
      if(shorten.has(p.host))add('shortener',10,p.host);
      if(p.idn)add('idn',0,p.host);
      if(p.mixed_script)add('mixed_script',12,p.host);
      if(p.port&&![80,443].includes(p.port))add('port',5,p.port);
      if(p.demo)add('demo_domain',0,p.host);
      if(entity&&!officialHost(entity,p.host)){
        add('claimed_mismatch',28,`${entity.name[language]} · ${p.host}`);
        let compact=p.host.replace(/-/g,'');compact=compact+' '+compact.replace(/[01345]/g,c=>({'0':'o','1':'l','3':'e','4':'a','5':'s'}[c]))+' '+compact.replace(/1/g,'i');
        if(baitTokens(entity).some(t=>compact.includes(t)))add('claimed_bait',12,p.host);
      }
      if(expected&&!(p.host===expected||p.host.endsWith('.'+expected))){
        add('domain_mismatch',28,`${p.host} ≠ ${expected}`);
        if(p.raw.toLowerCase().includes(expected))add('brand_bait',12,p.host);
        else {
          const skeleton=x=>x.replace(/[01аеорсх]/g,c=>({'0':'o','1':'l','а':'a','е':'e','о':'o','р':'p','с':'c','х':'x'}[c]));
          const a=skeleton(p.unicode_host),b=skeleton(expected);
          const oneEdit=(a,b)=>{if(Math.abs(a.length-b.length)>1)return false;let i=0,j=0,n=0;while(i<a.length&&j<b.length){if(a[i]===b[j]){i++;j++;continue;}if(++n>1)return false;if(a.length>=b.length)i++;if(b.length>=a.length)j++;}return n+(a.length-i)+(b.length-j)<=1;};
          if(Math.min(a.length,b.length)>=5&&oneEdit(a,b))add('lookalike',12,`${p.host} ≈ ${expected}`);
        }
      }
    }
    if(bidi.test(text))add('bidi',10,'Unicode bidi controls','format');
    if(/ignore (?:all |the )?(?:previous |prior )?instructions|تجاهل التعليمات|התעלם מההוראות/i.test(content))add('injection',0,'Untrusted embedded instruction','format');
    const codes=new Set(evidence.map(e=>e.code));
    if(['credentials','payment','remote_access'].some(c=>codes.has(c))&&(['urgency','threat'].some(c=>codes.has(c))||links.length))add('compound',18,[...codes].filter(c=>['credentials','payment','remote_access','urgency','threat'].includes(c)).sort().join(' + '),'context');
    const weights={};evidence.forEach(e=>weights[e.code]=Math.max(weights[e.code]||0,e.weight));
    const score=Math.min(100,Object.values(weights).reduce((a,b)=>a+b,0));
    const id='RC-'+(crypto.randomUUID?crypto.randomUUID().replaceAll('-',''):Math.random().toString(16).slice(2)).slice(0,10).toUpperCase();
    evidence.forEach((s,i)=>{s.id='E'+String(i+1).padStart(2,'0');s.source||='local_rule';});links.forEach((u,i)=>u.id='U'+String(i+1).padStart(2,'0'));
    return {id,created_at:new Date().toISOString(),engine_version:'3.0.0',language,input_type,original_text:text,expected_domain:expected,claimed_entity:entity?entity.id:null,score,verdict:score>=55?'high':score>=25?'review':'limited',signals:evidence,urls:links,invalid_urls:invalid,urls_truncated:candidates.length>10,providers:{local:'completed',reputation:'not_requested',ai:'not_requested'},reputation:[],ai_summary:null,notes:[],schema_version:2,suppressed_signals:suppressed,ml:input_type==='url'?{status:'abstained',reason:'url_only',label:null,top_features:[]}:RC_ML.predict(text),analysis_ms:Math.round((performance.now()-started)*100)/100,decision:{method:'weighted_rules_v1',evasion_shield:!!shield,review_threshold:25,high_threshold:55,uncapped_score:Object.values(weights).reduce((a,b)=>a+b,0),weights,is_probability:false,ml_affects_score:false,network_requests_local:0}};
  }
  return {analyze,parse,domain,shieldView};
})();
