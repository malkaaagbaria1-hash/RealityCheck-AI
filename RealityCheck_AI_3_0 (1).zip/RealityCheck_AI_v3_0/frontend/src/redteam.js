/* 3.0 Red Team Arena — white-box evasion operators and robustness scoring.
   Pure functions, no DOM and no network. The attacker knows which words triggered
   each local rule and rewrites only those words, then the message is re-analyzed
   with the 2.0 matching view (shield=false) and the 3.0 Evasion Shield (shield=true). */
window.RC_RedTeam=(()=>{
 const WORD=/\p{L}[\p{L}\p{M}]*/gu;
 const CYR={a:'а',e:'е',o:'о',p:'р',c:'с',x:'х',y:'у',i:'і'};
 const AR_HOMO={'ك':'ک','ي':'ی','ه':'ہ'};
 const LEET={a:'4',e:'3',o:'0',i:'1'};
 const PARA={
  en:[[/\bpasswords?\b/gi,'login secret'],[/\bverification code\b/gi,'6 digits we just texted'],[/\bcard number\b/gi,'16 digits on the card'],[/\bsecurity code\b/gi,'3 digits on the back'],[/\bimmediately\b/gi,'before tonight'],[/\burgent\b/gi,'time-sensitive'],[/\bwithin \d+ (?:hours?|minutes?)\b/gi,'by the end of today'],[/\bsuspend(?:ed)?\b/gi,'paused'],[/\bdelivery fee\b/gi,'small redelivery charge'],[/\bpay\b/gi,'settle'],[/\benter\b/gi,'fill in'],[/\bdo not tell anyone\b/gi,'keep this between us']],
  ar:[[/كلمة (?:المرور|السر)/g,'الرقم السري'],[/رمز (?:التحقق|التأكيد|التاكيد)/g,'الكود اللي وصلك'],[/رقم البطاقة|تفاصيل البطاقة/g,'الأرقام اللي على البطاقة'],[/فور[اًا]+|فورًا/g,'بأسرع وقت'],[/عاجل/g,'مهم جدًا'],[/خلال [0-9٠-٩]+ (?:ساعة|دقيقة)/g,'قبل آخر اليوم'],[/ادفع/g,'سدّد'],[/رسوم (?:الشحن|التوصيل|توصيل)/g,'تكلفة إعادة الإرسال'],[/لا تخبر أحد(?:ًا|ا)?/g,'خليها بيننا']],
  he:[[/סיסמ[הא]/g,'קוד הכניסה הסודי'],[/קוד אימות/g,'הספרות שקיבלת'],[/פרטי אשראי|מספר כרטיס/g,'הספרות שעל הכרטיס'],[/(?<![֐-׿])מיד(?![֐-׿])/g,'עוד היום'],[/דחוף/g,'חשוב מאוד'],[/דמי משלוח/g,'עלות משלוח חוזר'],[/(?<![֐-׿])שלמו?(?![֐-׿])/g,'הסדירו'],[/אל תספר לאף אחד/g,'שיישאר בינינו']]
 };
 const FW=c=>/[A-Za-z]/.test(c)?String.fromCharCode(c.charCodeAt(0)+0xfee0):c;
 const insertEvery=(w,ins,step=2)=>[...w].map((c,i,a)=>c+(i<a.length-1&&(i+1)%step===0?ins:'')).join('');
 const middle=(w,ins)=>{const a=[...w];if(a.length<4)return w;const m=Math.floor(a.length/2);return a.slice(0,m).join('')+ins+a.slice(m).join('');};
 // family: 'invisible' | 'visual' | 'structural' | 'semantic' | 'url'
 const operators=[
  {id:'homoglyph',family:'visual',name:{ar:'حروف متشابهة (سيريلية/فارسية)',he:'אותיות דומות (קירילית/פרסית)',en:'Look-alike letters (Cyrillic/Persian)'},word:w=>[...w].map(c=>CYR[c]||AR_HOMO[c]||c).join('')},
  {id:'zwsp',family:'invisible',name:{ar:'مسافة صفرية مخفية U+200B',he:'רווח אפס בלתי נראה U+200B',en:'Zero-width space U+200B'},word:w=>insertEvery(w,'​')},
  {id:'shy',family:'invisible',name:{ar:'واصلة ناعمة مخفية U+00AD',he:'מקף רך בלתי נראה U+00AD',en:'Invisible soft hyphen U+00AD'},word:w=>insertEvery(w,'­')},
  {id:'leet',family:'visual',name:{ar:'أرقام بدل حروف (p4ssw0rd)',he:'ספרות במקום אותיות (p4ssw0rd)',en:'Leetspeak (p4ssw0rd)'},word:w=>/^[A-Za-z]+$/.test(w)?[...w].map((c,i)=>i&&LEET[c.toLowerCase()]||c).join(''):w},
  {id:'separator',family:'structural',name:{ar:'رمز داخل الكلمة (pass*word)',he:'סימן בתוך המילה (pass*word)',en:'Symbol inside word (pass*word)'},word:w=>middle(w,'*')},
  {id:'emoji',family:'structural',name:{ar:'إيموجي داخل الكلمة',he:'אימוג׳י בתוך המילה',en:'Emoji inside word'},word:w=>middle(w,'🔒')},
  {id:'spacing',family:'structural',name:{ar:'تفريق الحروف (p a s s)',he:'ריווח אותיות (p a s s)',en:'Letter spacing (p a s s)'},longest:true,word:w=>[...w].join(' ')},
  {id:'fullwidth',family:'visual',name:{ar:'حروف عريضة Unicode',he:'אותיות רחבות Unicode',en:'Full-width Unicode letters'},word:w=>[...w].map(FW).join('')},
  {id:'tatweel',family:'visual',name:{ar:'تطويل وتشكيل عربي',he:'מתיחה וניקוד ערבי',en:'Arabic tatweel + diacritics'},word:w=>/[؀-ۿ]/.test(w)?[...w].map((c,i,a)=>c+(i<a.length-1?'ـَ':'')).join(''):w},
  {id:'digits',family:'visual',name:{ar:'أرقام عربية-هندية (٢٤)',he:'ספרות הודיות-ערביות (٢٤)',en:'Arabic-Indic digits (٢٤)'},text:t=>t.replace(/[0-9]/g,d=>String.fromCharCode(0x660+Number(d)))},
  {id:'defang',family:'url',name:{ar:'تمويه الروابط hxxps / [.]',he:'הסוואת קישורים hxxps / [.]',en:'Defanged links hxxps / [.]'},text:t=>t.replace(/https?:\/\/[^\s]+/gi,u=>u.replace(/^http/i,'hxxp').replace(/\./g,'[.]'))},
  {id:'chain',family:'structural',name:{ar:'هجوم مركّب (3 تقنيات معًا)',he:'מתקפה משולבת (3 טכניקות)',en:'Chained attack (3 techniques)'},word:w=>middle(insertEvery([...w].map((c,i)=>i&&LEET[c.toLowerCase()]&&/[A-Za-z]/.test(c)?LEET[c.toLowerCase()]:(CYR[c]&&i%3===0?CYR[c]:AR_HOMO[c]||c)).join(''),'­',3),'-')},
  {id:'paraphrase',family:'semantic',name:{ar:'إعادة صياغة بالمعنى',he:'ניסוח מחדש במשמעות',en:'Semantic paraphrase'},text:(t,lang)=>{let o=t;for(const [re,v] of PARA[lang]||PARA.en)o=o.replace(re,v);for(const k of Object.keys(PARA))if(k!==lang)for(const [re,v] of PARA[k])o=o.replace(re,v);return o;}}
 ];
 const level=v=>v==='high'?2:v==='review'?1:0;
 function targetedRewrite(text,spans,op){
  const words=[...text.matchAll(WORD)].filter(m=>m[0].length>=3&&spans.some(([a,b])=>m.index<b&&m.index+m[0].length>a));
  let chosen=words.filter(m=>m[0].length>=4);
  if(op.longest){const best=new Map();for(const m of chosen){const s=spans.findIndex(([a,b])=>m.index<b&&m.index+m[0].length>a);if(!best.has(s)||best.get(s)[0].length<m[0].length)best.set(s,m);}chosen=[...best.values()];}
  chosen.sort((a,b)=>b.index-a.index);
  let out=text;for(const m of chosen)out=out.slice(0,m.index)+op.word(m[0])+out.slice(m.index+m[0].length);
  return out;
 }
 function attack(text,{language='en',expected_domain=''}={}){
  const base=RC.analyze({text,language,expected_domain,shield:true});
  const spans=base.signals.filter(s=>Number.isFinite(s.start)).map(s=>[s.start,s.end]);
  const rows=operators.map(op=>{
   const mutated=op.text?op.text(text,language):targetedRewrite(text,spans,op);
   if(mutated===text||!mutated.trim())return {id:op.id,family:op.family,name:op.name,applicable:false};
   let v2,v3;try{v2=RC.analyze({text:mutated,language,expected_domain,shield:false});v3=RC.analyze({text:mutated,language,expected_domain,shield:true});}catch{return {id:op.id,family:op.family,name:op.name,applicable:false};}
   const outcome=r=>level(r.verdict)>=level(base.verdict)?'held':level(r.verdict)>0?'degraded':'evaded';
   return {id:op.id,family:op.family,name:op.name,applicable:true,mutated,v2:{score:v2.score,verdict:v2.verdict,outcome:outcome(v2),codes:v2.signals.filter(s=>s.weight).map(s=>s.code)},v3:{score:v3.score,verdict:v3.verdict,outcome:outcome(v3),codes:v3.signals.filter(s=>s.weight).map(s=>s.code)}};
  });
  const live=rows.filter(r=>r.applicable),rate=k=>live.length?Math.round(100*live.filter(r=>r[k].outcome==='held').length/live.length):null;
  return {base:{score:base.score,verdict:base.verdict,codes:base.signals.filter(s=>s.weight).map(s=>s.code)},rows,applicable:live.length,robustness:{v2:rate('v2'),v3:rate('v3')},attackable:level(base.verdict)>0};
 }
 function benchmark(corpus){
  const per={};let n=0;const totals={v2:{held:0,degraded:0,evaded:0},v3:{held:0,degraded:0,evaded:0}};
  for(const item of corpus){
   const r=attack(item.text,{language:item.language,expected_domain:item.expected_domain||''});if(!r.attackable)continue;n++;
   for(const row of r.rows){if(!row.applicable)continue;const p=per[row.id]??={id:row.id,family:row.family,name:row.name,trials:0,v2:{held:0,degraded:0,evaded:0},v3:{held:0,degraded:0,evaded:0}};p.trials++;for(const k of ['v2','v3']){p[k][row[k].outcome]++;totals[k][row[k].outcome]++;}}
  }
  const trials=Object.values(per).reduce((a,p)=>a+p.trials,0);
  const pct=(o)=>trials?Math.round(1000*o.held/trials)/10:null;
  return {messages_attacked:n,trials,operators:Object.values(per),totals,robustness:{v2:pct(totals.v2),v3:pct(totals.v3)}};
 }
 const visible=s=>String(s).replace(/​/g,'⟨ZW⟩').replace(/­/g,'⟨SHY⟩');
 return {operators,attack,benchmark,visible};
})();
