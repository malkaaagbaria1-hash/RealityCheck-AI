/* UI deliberately has no remote scripts, fonts, analytics or clickable suspect URLs. */
(() => {
'use strict';
const $=s=>document.querySelector(s), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}};
const pref=(key,val)=>{try{localStorage.setItem(key,JSON.stringify(val));}catch{}};
const state={lang:read('rc-language','ar'),theme:read('rc-theme','dark'),page:'intelligence',tab:'message',text:'',domain:'',report:null,cases:[],mode:'portable',health:null,busy:false,error:'',filter:'',image:null,imageName:'',ai:false,vt:false,serverError:false};
if(!['ar','he','en'].includes(state.lang))state.lang='ar';
if(!['dark','light'].includes(state.theme))state.theme='dark';
const t=k=>window.RC_I18N[state.lang][k]||window.RC_I18N.en[k]||k;
const paths={
 shield:'M12 3 4 6v6c0 4 4 7 8 9 4-2 8-5 8-9V6l-8-3Z M9 12l2 2 4-4',search:'M21 21l-5-5 M18 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0',folder:'M3 7h6l2 2h10v11H3V7Z M3 7V4h7l2 3',flask:'M9 3h6 M10 3v6l-6 10a1 1 0 0 0 1 2h14a1 1 0 0 0 1-2L14 9V3 M7 15h10',info:'M12 11v6 M12 7h.01 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Z',moon:'M20 15A9 9 0 0 1 9 3a9 9 0 1 0 11 12Z',message:'M21 4H3v14h6l3 3 3-3h6V4Z M7 9h10 M7 13h7',link:'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2 M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2',image:'M3 3h18v18H3V3Z M3 16l6-6 6 6 3-3 3 3 M16 7h.01',arrow:'M5 12h14 M13 6l6 6-6 6',check:'M5 12l4 4L19 6',lock:'M6 10h12v11H6V10Z M8 10V6a4 4 0 0 1 8 0v4',file:'M5 3h9l5 5v13H5V3Z M14 3v5h5 M8 13h8 M8 17h6',save:'M4 3h14l3 3v15H3V3h1Z M7 3v6h10V3 M7 21v-8h10v8',download:'M12 3v12 M7 10l5 5 5-5 M4 17v4h16v-4',print:'M6 8V3h12v5 M6 17H3V9h18v8h-3 M6 14h12v7H6v-7',trash:'M4 6h16 M9 6V3h6v3 M6 6l1 15h10l1-15 M10 10v7 M14 10v7',spark:'m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z',alert:'m12 3 10 18H2L12 3Z M12 9v5 M12 17h.01',globe:'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0 M2 12h20 M12 2c6 5 6 15 0 20-6-5-6-15 0-20',x:'M6 6l12 12 M6 18 18 6',code:'m8 6-6 6 6 6 M16 6l6 6-6 6 M14 3l-4 18',clock:'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0 M12 6v6l4 2',chevron:'m8 5 7 7-7 7',plus:'M12 4v16 M4 12h16'};
const icon=(name,cls='')=>`<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.info}"/></svg>`;
const badge=(text,cls='')=>`<span class="badge ${cls}">${esc(text)}</span>`;
const canAI=()=>state.mode==='server'&&state.health?.ai_configured;
const canVT=()=>state.mode==='server'&&state.health?.reputation_configured;
const date=v=>{try{return new Intl.DateTimeFormat(state.lang==='ar'?'ar':state.lang==='he'?'he':'en-GB',{dateStyle:'medium',timeStyle:'short'}).format(new Date(v));}catch{return String(v);}};
const status=s=>t(({not_requested:'notRequested',not_configured:'notConfigured',completed:'completed',unavailable:'unavailable',excluded:'excluded',rate_limited:'rateLimited',no_data:'noData',no_urls:'noUrls',partial:'partial'})[s]||'unknown');
const verdict=r=>t(r.verdict);
const intelligence=RC_Intelligence.create({state,t,esc,icon,api,render,toast,date});
for(const lang of ['ar','he','en']) window.RC_I18N[lang].intelligence=({ar:'مركز الحملات',he:'מרכז קמפיינים',en:'Campaign workbench'})[lang];
const v3=RC_V3.create({state,t,esc,icon,render,toast});
const advanced=RC_Advanced.create({state,t,esc,icon,badge,api,render,toast,date,refreshHistory});
function toast(text){const el=$('#toast');el.textContent=text;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),4200);}
async function api(path,options={}){
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),70000);
  try{
    const response=await fetch('/api'+path,{...options,signal:controller.signal,headers:{'Content-Type':'application/json','X-RealityCheck-Client':'web',...(options.headers||{})}});
    const body=await response.json();if(!response.ok){const e=Error(typeof body.detail==='string'?body.detail:Array.isArray(body.detail)?body.detail.map(d=>(d.loc||[]).join('.')+': '+d.msg).join('; '):'REQUEST_FAILED');e.incident=body.incident_id;e.status=response.status;throw e;}return body;
  }finally{clearTimeout(timeout);}
}
function sidebar(){
 const pages=[['quick','check'],['investigate','search'],['redteam','alert'],['arena','spark'],['intelligence','globe'],['dashboard','globe'],['history','folder'],['compare','code'],['lab','flask'],['evaluation','check']];
 return `<aside class="sidebar"><a class="brand" href="#" data-page="quick" aria-label="RealityCheck AI">${icon('shield','brand-icon')}<span><strong dir="ltr">RealityCheck<span class="brand-ai">AI</span></strong><small>${t('brandSub')}</small></span></a><div class="side-label">WORKSPACE / 01</div><nav aria-label="${t('workspace')}">${pages.filter(([p])=>state.mode==='server'||!['intelligence','dashboard','compare'].includes(p)).map(([p,i])=>`<button class="nav-item ${state.page===p?'active':''}" data-page="${p}">${icon(i)}<span>${t(p)}</span>${p==='history'?`<span class="nav-count">${state.cases.length}</span>`:''}${p==='redteam'||p==='arena'?`<span class="nav-new">3.0</span>`:''}</button>`).join('')}</nav><div class="sidebar-bottom"><div class="local-card"><span class="status-dot"></span><strong>${t('local')}</strong><p>${t('privacyBadge')}</p><code>${state.mode==='server'?'PYTHON / LOCALHOST':'BROWSER / OFFLINE'}</code></div>${[['about','info'],['settings','settings']].filter(([p])=>p!=='settings'||state.mode==='server').map(([p,i])=>`<button class="nav-item ${state.page===p?'active':''}" data-page="${p}">${icon(i)}<span>${t(p)}</span></button>`).join('')}<div class="version">RED TEAM EDITION <span>v3.0.0</span></div></div></aside>`;
}
function header(){return `<header class="topbar"><div class="breadcrumb"><span>RealityCheck</span><span class="crumb-slash">/</span><strong>${t(state.page==='investigate'?'workspace':state.page)}</strong></div><div class="top-tools"><button class="icon-button presentation-toggle" data-adv="presentation" aria-label="${t('presentation')}" title="${t('presentation')}">${icon('globe')}</button><button class="mode-pill" data-page="settings" aria-label="${t('settings')}"><span class="status-dot"></span>${t(state.mode==='server'?'server':'portable')}</button><div class="languages" role="group" aria-label="${t('language')}">${[['ar','ع'],['he','עב'],['en','EN']].map(([k,label])=>`<button data-lang="${k}" class="${state.lang===k?'selected':''}" aria-pressed="${state.lang===k}" title="${esc(t('viewLanguage'))}">${label}</button>`).join('')}</div><button class="icon-button" data-action="theme" aria-label="${t('night')}">${icon('moon')}</button></div></header>`;}
function hero(){return `<section class="hero"><div><div class="eyebrow"><span class="tiny-line"></span>${t('heroTag')}</div><h1>${t('heroA')}<br><span>${t('heroB')}</span></h1><p>${t('heroBody')}</p><div class="privacy-line">${icon('lock')}${t('privacyBadge')}</div></div><div class="hero-mark" aria-hidden="true"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="scan-grid"></div><div class="shield-outline">${icon('shield')}</div><span class="coordinate c1">01 / INPUT</span><span class="coordinate c2">02 / EVIDENCE</span><span class="orbit-point"></span></div></section>`;}
function inputPanel(){
 return `<section class="card input-card"><div class="card-head"><div><h2>${t('newCase')}</h2><p>${t('caseSub')}</p></div><span class="card-number">01</span></div><div class="input-tabs" role="tablist">${[['message','message'],['url','link'],['image','image']].map(([k,i])=>`<button role="tab" aria-selected="${state.tab===k}" class="${state.tab===k?'active':''}" data-tab="${k}">${icon(i)}${t(k)}</button>`).join('')}</div><form id="investigation-form">${state.tab==='image'?`<div class="image-input"><label class="upload-button">${icon('image')}${t('upload')}<input type="file" id="image-file" accept="image/png,image/jpeg,image/webp"></label><p class="help">${t('uploadHint')}</p>${state.image?`<div class="image-preview"><img src="${state.image}" alt="${esc(state.imageName)}"><span>${esc(state.imageName)}</span></div>`:''}<button type="button" class="button secondary small" data-action="extract" ${!canAI()||!state.image||state.busy?'disabled':''}>${icon('spark')}${t('extract')}</button><p class="help">${t('extractManual')}</p></div>`:''}<div class="field-top"><label for="content">${t(state.tab==='url'?'urlLabel':state.tab==='image'?'imageLabel':'messageLabel')}</label><span id="character-count">${state.text.length} / 12000</span></div><textarea id="content" maxlength="12000" rows="6" spellcheck="false" dir="${state.tab==='url'?'ltr':'auto'}" placeholder="${esc(t(state.tab==='url'?'urlPlaceholder':'placeholder'))}" ${state.busy?'disabled':''}>${esc(state.text)}</textarea><details class="domain-details" ${state.domain?'open':''}><summary>${icon('globe')}${t('domainLabel')}</summary><input id="expected-domain" type="text" maxlength="253" dir="ltr" autocomplete="off" placeholder="example.org" value="${esc(state.domain)}"><p class="help">${t('domainHelp')}</p></details><details class="external-details"><summary>${icon('settings')}${t('optional')}</summary><label class="checkbox-row"><input id="opt-ai" type="checkbox" ${state.ai?'checked':''} ${canAI()?'':'disabled'}><span>${t('aiOption')}</span></label><label class="checkbox-row"><input id="opt-vt" type="checkbox" ${state.vt?'checked':''} ${canVT()?'':'disabled'}><span>${t('vtOption')}</span></label>${!canAI()||!canVT()?`<button type="button" class="text-button" data-page="settings">${t('enabledOnlyServer')} ${icon('chevron')}</button>`:''}</details>${state.error?`<div role="alert" class="error-box">${icon('alert')}${esc(state.error)}</div>`:''}<button id="start-button" type="submit" class="button primary" ${state.busy||!state.text.trim()?'disabled':''}>${state.busy?'<span class="spinner"></span>':icon('search')}<span>${t(state.busy?'working':'start')}</span>${!state.busy?icon('arrow','button-arrow'):''}</button><div class="form-foot"><span>${icon('lock')}${t('fresh')}</span><span dir="auto">${t('shortcut')}</span></div></form><div class="examples"><div class="mini-label">${t('examples')}</div><div class="sample-pills">${RC_DATA.samples.slice(0,3).map(s=>`<button data-sample="${s.id}">${s.kind==='suspicious'?icon('message'):icon('check')}${esc(s.label[state.lang])}</button>`).join('')}</div><p>${t('examplesNote')}</p></div></section>`;
}
function summaryPanel(){
 const r=state.report;
 if(!r)return `<aside class="summary-column"><section class="card empty-result"><div class="mini-label">${t('result')} <span>02</span></div><div class="empty-visual">${icon('file')}<span class="search-bubble">${icon('search')}</span><div class="dash-line"></div></div><span class="eyebrow">${t('emptyTag')}</span><h3>${t('emptyTitle')}</h3><p>${t('emptyBody')}</p><div class="placeholder-lines"><i></i><i></i><i></i></div></section><section class="tip-card">${icon('info')}<div><strong>${t('limitations')}</strong><p>${t('summaryLimited')}</p></div></section></aside>`;
 return `<aside class="summary-column"><section class="card result-summary ${r.verdict}"><div class="mini-label">${t('result')}<span>02</span></div><div class="score-row"><div><span class="score-label">${t('score')}</span><div class="score-value" dir="ltr">${r.score}<span>/ 100</span></div></div><div class="result-emblem">${icon(r.verdict==='limited'?'info':'alert')}</div></div><div class="meter" role="meter" aria-valuenow="${r.score}" aria-valuemin="0" aria-valuemax="100" aria-label="${t('score')}"><i style="width:${r.score}%"></i></div><h3>${verdict(r)}</h3><p>${t(r.verdict==='high'?'summaryHigh':r.verdict==='review'?'summaryReview':'summaryLimited')}</p><p class="score-note">${t('scoreNote')}</p>${r.reputation.some(v=>v.status==='completed'&&(v.malicious||v.suspicious))?`<div class="error-box">${icon('alert')}${t('externalWarning')}</div>`:''}<div class="source-list"><h4>${t('source')}</h4>${[['localRules','local'],['reputation','reputation'],['ai','ai']].map(([k,p])=>`<div><span>${t(k)}</span><span class="source-status ${r.providers[p]==='completed'?'done':''}">${r.providers[p]==='completed'?icon('check'):icon('clock')}${status(r.providers[p])}</span></div>`).join('')}</div></section><section class="tip-card"><div class="case-fingerprint"><span>${t('reportId')}</span><code>${esc(r.id)}</code><small>${date(r.created_at)}</small></div></section></aside>`;
}
function evidencePanel(){
 const r=state.report;if(!r)return '';
 return `<section id="case-report" class="case-report"><div class="section-title"><div><div class="eyebrow">CASE FILE / ${esc(r.id)}</div><h2>${t('sectionEvidence')}</h2></div><div class="report-actions"><button class="button secondary small" data-adv="export-html">${icon('download')}${t('htmlExport')}</button><button class="button secondary small" data-action="save">${icon('save')}${t('save')}</button><button class="icon-button" data-action="export" title="${t('export')}" aria-label="${t('export')}">${icon('download')}</button><button class="icon-button" data-action="print" title="${t('print')}" aria-label="${t('print')}">${icon('print')}</button></div></div><div class="report-grid"><div><section class="card evidence-card"><div class="card-head"><h3>${t('evidence')}</h3><span class="number-badge">${r.signals.length}</span></div>${r.signals.length?r.signals.map((s,i)=>`<article class="evidence-item ${s.weight?'':'informational'}"><div class="evidence-index">${esc(s.id||String(i+1).padStart(2,'0'))}</div><div class="evidence-content"><div class="evidence-heading"><h4 dir="auto">${esc(s.title)}</h4><span class="weight ${s.weight?'':'zero'}">${s.weight?'+'+s.weight:t('info')}</span></div><p dir="auto">${esc(s.detail)}</p><blockquote dir="auto">${esc(s.evidence)}</blockquote></div></article>`).join(''):`<div class="empty-inline">${icon('info')}<p>${t('noSignals')}</p></div>`}</section>${r.urls.length?`<section class="card links-card"><h3>${t('urls')}</h3>${r.urls.map(u=>`<div class="url-item"><span>${t('host')}</span><code dir="ltr">${esc(u.host)}</code><div class="url-raw" dir="ltr">${esc(u.raw)}</div><small>${t('notVisited')}</small></div>`).join('')}</section>`:''}${r.ai_summary?`<section class="card ai-card"><h3>${icon('spark')}${t('ai')}</h3><p class="plain-text" dir="auto">${esc(r.ai_summary)}</p><div class="callout">${t('aiNote')}</div></section>`:''}${r.reputation.length?`<section class="card links-card"><h3>${t('reputation')} / VirusTotal</h3>${r.reputation.map(v=>`<div class="url-item"><code dir="ltr">${esc(v.host)}</code><p>${status(v.status)}</p>${v.status==='completed'?`<div class="vt-stats"><span>${t('malicious')}: <b>${v.malicious}</b></span><span>${t('suspiciousVT')}: <b>${v.suspicious}</b></span></div><small>${t('lastScan')}: ${v.last_analysis_date?date(v.last_analysis_date*1000):t('unknown')}</small>`:''}</div>`).join('')}<p class="help">${t('providerNote')}</p></section>`:''}</div><div class="report-rail"><section class="card next-card"><div class="mini-label">${icon('shield')}${t('next')}</div>${['advice1','advice2','advice3'].map((k,i)=>`<div class="next-step"><span>${i+1}</span><p>${t(k)}</p></div>`).join('')}</section><section class="limitations-card"><h3>${icon('info')}${t('limitations')}</h3><p>${t('limitsBody')}</p>${r.urls_truncated?`<p>${t('truncated')}</p>`:''}${r.invalid_urls?`<p>${t('invalidLinks')}</p>`:''}<code>RULE ENGINE ${esc(r.engine_version)}</code></section></div></div>${advanced.report()}<div class="print-original"><h3>${t('messageLabel')}</h3><p dir="auto">${esc(r.original_text)}</p></div></section>`;
}
function stats(){return `<div class="stats-strip">${[['file',state.cases.length,'savedCount'],['alert',state.report?state.report.signals.filter(s=>s.weight).length:'—','signalCount'],['link',state.report?state.report.urls.length:'—','linksCount']].map(([i,n,k])=>`<div>${icon(i)}<strong>${n}</strong><span>${t(k)}</span></div>`).join('')}</div>`;}
function investigate(){return `${hero()}${state.serverError?`<div class="callout">${t('serverError')}</div>`:''}<div class="investigation-grid">${inputPanel()}${summaryPanel()}</div>${v3.reportExtras()}${stats()}${evidencePanel()}`;}
function history(){
 const q=state.filter.toLowerCase();const rows=state.cases.filter(r=>(r.id+' '+r.original_text).toLowerCase().includes(q));
 return `<section class="page-intro"><div class="eyebrow">YOUR PRIVATE CASE FILES</div><h1>${t('historyTitle')}</h1><p>${t('historyBody')}</p></section><div class="history-tools"><label class="search-input">${icon('search')}<input id="case-search" placeholder="${t('filter')}" value="${esc(state.filter)}"></label><button class="button secondary small" data-action="clear" ${state.cases.length?'':'disabled'}>${icon('trash')}${t('clear')}</button></div><div id="case-list" class="case-list">${historyRows(rows)}</div>`;
}
function historyRows(rows){return rows.length?rows.map(r=>`<article class="card history-card"><div class="history-icon ${r.verdict}">${icon('file')}</div><div class="history-content"><code>${esc(r.id)}</code><p dir="auto">${esc(r.original_text.slice(0,130))}${r.original_text.length>130?'…':''}</p><small>${date(r.created_at)}</small></div><div class="history-side">${badge(verdict(r),r.verdict)}<div><button class="button secondary small" data-open="${esc(r.id)}">${t('open')}</button><button class="icon-button danger" data-delete="${esc(r.id)}" aria-label="${t('delete')}">${icon('trash')}</button></div></div></article>`).join(''):`<div class="card empty-page">${icon('folder')}<p>${t(state.filter?'emptyFilter':'noHistory')}</p><button class="button secondary small" data-page="investigate">${t('investigate')}</button></div>`;}
function lab(){return `<section class="page-intro"><div class="eyebrow">CONTROLLED TEST ENVIRONMENT</div><h1>${t('labTitle')}</h1><p>${t('labBody')}</p></section><div class="lab-grid">${RC_DATA.samples.map((s,i)=>`<article class="card sample-card"><div class="mini-label">${t('synthetic')}<span>0${i+1}</span></div><div class="sample-icon">${icon(s.kind==='suspicious'?'message':'check')}</div><h2>${esc(s.label[state.lang])}</h2><p class="muted">${t(s.kind==='suspicious'?'suspicious':'ordinary')}</p><blockquote dir="auto">${esc(s.text[state.lang])}</blockquote><button class="button secondary" data-sample="${s.id}">${t('loadSample')}${icon('arrow')}</button></article>`).join('')}</div>`;}
function about(){return `<section class="page-intro"><div class="eyebrow">EVIDENCE, NOT ASSUMPTIONS</div><h1>${t('aboutTitle')}</h1><p>${t('aboutBody')}</p></section><div class="about-steps">${[['code','how1'],['file','how2'],['info','how3']].map(([i,k],n)=>`<article class="card"><span class="card-number">0${n+1}</span>${icon(i)}<h3>${t(k)}</h3></article>`).join('')}</div><section class="card prose"><h2>${t('limitations')}</h2><p>${t('limitsBody')}</p><h2>${t('privacyTitle')}</h2><p>${t('privacyBody')}</p><div class="callout">${t('notProduction')}</div><code>RULES + LOCAL ML + OPTIONAL CLOUD · 2.0.0</code></section>`;}
function settings(){return `<section class="page-intro"><div class="eyebrow">TRANSPARENT BY DESIGN</div><h1>${t('settingsTitle')}</h1><p>${t('settingsBody')}</p></section><section class="card config-card"><div class="config-row">${icon('code')}<div><h3>${t('mode')}</h3><p>${t(state.mode==='server'?'server':'portable')}</p></div>${badge(t('completed'),'done')}</div><div class="config-row">${icon('spark')}<div><h3>OpenAI</h3><p>${t(canAI()?'configured':'notConfigured')}</p></div><span class="config-indicator ${canAI()?'enabled':''}"></span></div><div class="config-row">${icon('globe')}<div><h3>VirusTotal</h3><p>${t(canVT()?'configured':'notConfigured')}</p></div><span class="config-indicator ${canVT()?'enabled':''}"></span></div><div class="setup-help">${icon('info')}<p>${t('setup')}</p></div></section><div class="settings-grid"><section class="card prose"><h2>${icon('lock')}${t('privacyTitle')}</h2><p>${t('privacyBody')}</p><p>${t('aiTerms')}</p><p>${t('vtTerms')}</p></section><section class="card prose"><h2>${t('limitations')}</h2><p>${t('notProduction')}</p><p>${t('portableNote')}</p><code>.env → Python → providers</code></section></div>`;}
function render(){
 document.documentElement.lang=state.lang;document.documentElement.dir=state.lang==='en'?'ltr':'rtl';document.documentElement.dataset.theme=state.theme;
 $('#app').innerHTML=`${sidebar()}<div class="app-shell">${header()}<main id="main-content">${({investigate,history,lab,about,settings,intelligence:intelligence.page,quick:v3.quick,redteam:v3.redteam,arena:v3.arena,dashboard:advanced.dashboard,compare:advanced.compare,evaluation:advanced.evaluation})[state.page]()}</main><footer><span>${t('footer')}</span><button class="footer-link" data-page="about">${t('academic')}</button></footer></div>`;
}
function errorMessage(e){const m=String(e.message||e);if(e.incident)return t('internalError')+e.incident;if(m==='REPORT_EXPIRED_RUN_AGAIN')return t('expiredError');if(/Failed to fetch|fetch failed|NetworkError|aborted|timeout/i.test(m))return t('networkError');if(/domain|hostname|INVALID_DOMAIN/i.test(m))return t('invalidDomain');if(/url|HTTP|INVALID_URL/i.test(m))return t('invalidUrl');if(/INVALID_INPUT|blank|12000/i.test(m))return t('invalidInput');return t('error');}
async function refreshHistory(){
 if(state.mode==='server')state.cases=(await api('/cases')).cases;
 else state.cases=read('rc-cases-v1',[]).filter(r=>r&&r.id&&r.providers&&Array.isArray(r.signals)&&Array.isArray(r.urls)&&typeof r.original_text==='string');
}
async function run(){
 if(state.busy)return;
 const payload={text:state.text,input_type:state.tab==='image'?'image_text':state.tab,language:state.lang,expected_domain:state.domain,use_ai:state.ai&&canAI(),use_reputation:state.vt&&canVT()};
 if(payload.use_ai&&!confirm(t('aiConsent')))return;if(payload.use_reputation&&!confirm(t('vtConsent')))return;
 state.busy=true;state.error='';state.report=null;advanced.reset();render();
 try{
  // Allow the browser to paint before a synchronous local check, without artificial progress.
  await new Promise(resolve=>requestAnimationFrame(()=>resolve()));
  state.report=state.mode==='server'?await api('/analyze',{method:'POST',body:JSON.stringify(payload)}):RC.analyze(payload);
 }catch(e){state.error=errorMessage(e);}finally{state.busy=false;state.ai=false;state.vt=false;render();if(state.report)$('#case-report')?.scrollIntoView({behavior:'smooth',block:'start'});}
}
function loadSample(id){const s=RC_DATA.samples.find(s=>s.id===id);if(!s)return;state.page='investigate';state.tab='message';state.text=s.text[state.lang];state.domain=s.expected;state.error='';state.report=null;state.image=null;advanced.reset();render();$('#content')?.focus();}
async function save(){
 if(!state.report||!confirm(t('saveConfirm')))return;
 try{
  if(state.mode==='server')await api('/cases',{method:'POST',body:JSON.stringify({case_id:state.report.id,consent:true})});
  else{const cases=[state.report,...state.cases.filter(c=>c.id!==state.report.id)].slice(0,200);localStorage.setItem('rc-cases-v1',JSON.stringify(cases));}
  await refreshHistory();render();toast(t('saved'));
 }catch(e){toast(state.mode==='server'?t('error'):t('storageError'));}
}
async function remove(id){
 if(!confirm(t(id?'deleteConfirm':'clearConfirm')))return;
 try{
  if(state.mode==='server')await api('/cases'+(id?'/'+encodeURIComponent(id):''),{method:'DELETE'});
  else localStorage.setItem('rc-cases-v1',JSON.stringify(id?state.cases.filter(c=>c.id!==id):[]));
  await refreshHistory();render();toast(t('deleted'));
 }catch{toast(t('error'));}
}
function exportReport(){if(!state.report||!confirm(t('exportConfirm')))return;const blob=new Blob([JSON.stringify(state.report,null,2)],{type:'application/json;charset=utf-8'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=state.report.id+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
async function extractImage(){
 if(!canAI()||!state.image||!confirm(t('imageConsent')))return;state.busy=true;render();
 try{const response=await api('/extract-image',{method:'POST',body:JSON.stringify({data_url:state.image,consent:true,language:state.lang})});state.text=response.text;state.error='';toast(t('reviewImage'));}catch{state.error=t('error');}finally{state.busy=false;render();}
}
document.addEventListener('click',async event=>{
 const el=event.target.closest('button,a[data-page],[data-ci]');if(!el)return;
 if(el.disabled)return;
 if(await v3.click(el))return;
 if(await intelligence.click(el))return;
 if(await advanced.click(el))return;
 if(el.dataset.page){event.preventDefault();state.page=el.dataset.page;state.error='';render();window.scrollTo({top:0});return;}
 if(el.dataset.lang){state.lang=el.dataset.lang;pref('rc-language',state.lang);v3.langChanged();render();return;}
 if(el.dataset.tab){state.tab=el.dataset.tab;state.text='';state.error='';state.report=null;render();return;}
 if(el.dataset.sample){loadSample(el.dataset.sample);return;}
 if(el.dataset.open){advanced.reset();state.report=state.cases.find(r=>r.id===el.dataset.open);state.text=state.report.original_text;state.domain=state.report.expected_domain;state.tab=state.report.input_type==='image_text'?'image':state.report.input_type;state.page='investigate';render();$('#case-report')?.scrollIntoView();return;}
 if(el.dataset.delete){await remove(el.dataset.delete);return;}
 switch(el.dataset.action){
 case 'theme':state.theme=state.theme==='dark'?'light':'dark';pref('rc-theme',state.theme);render();break;
 case 'save':await save();break;
 case 'clear':await remove();break;
 case 'export':exportReport();break;
 case 'print':window.print();break;
 case 'extract':await extractImage();break;
 }
});
document.addEventListener('submit',event=>{if(advanced.submit(event))return;if(event.target.id==='investigation-form'){event.preventDefault();run();}});
document.addEventListener('input',event=>{
 const el=event.target;advanced.input(el);intelligence.input(el);v3.input(el);
 if(el.id==='content'){state.text=el.value;$('#character-count').textContent=el.value.length+' / 12000';$('#start-button').disabled=!el.value.trim()||state.busy;}
 if(el.id==='expected-domain')state.domain=el.value;
 if(el.id==='case-search'){state.filter=el.value;const q=el.value.toLowerCase();$('#case-list').innerHTML=historyRows(state.cases.filter(r=>(r.id+' '+r.original_text).toLowerCase().includes(q)));}
});
document.addEventListener('change',async event=>{
 const el=event.target;await intelligence.change(el);if(el.id==='opt-ai')state.ai=el.checked;if(el.id==='opt-vt')state.vt=el.checked;
 if(el.id==='image-file'&&el.files?.[0]){
  const f=el.files[0];if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>4000000){toast(t('imageError'));return;}
  const reader=new FileReader();reader.onload=()=>{state.image=reader.result;state.imageName=f.name;render();};reader.onerror=()=>toast(t('imageError'));reader.readAsDataURL(f);
 }
});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('svg [data-ci]')){e.preventDefault();e.target.dispatchEvent(new MouseEvent('click',{bubbles:true}));return;}if((e.ctrlKey||e.metaKey)&&e.key==='Enter'&&state.page==='investigate'){e.preventDefault();run();}});
async function boot(){
 render();
 if(location.protocol==='http:'||location.protocol==='https:'){
  try{const response=await fetch('/api/health',{signal:AbortSignal.timeout(4000)});if(!response.ok)throw Error();const h=await response.json();if(h.status!=='ok')throw Error();state.health=h;state.mode='server';}catch{state.serverError=true;}
 }
 try{await refreshHistory();}catch{state.cases=[];}
 // Portable file: campaign mode needs the Python server, so open the 3.0 investigation workspace instead.
 if(state.mode!=='server'&&state.page==='intelligence')state.page='quick';
 render();
}
boot();
})();
