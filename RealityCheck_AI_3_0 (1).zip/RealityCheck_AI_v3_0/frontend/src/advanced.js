/* Academic release features. Every report field is escaped before DOM rendering. */
window.RC_Advanced={create(ctx){
 const {state,t,esc,icon,badge,api,render,toast,date,refreshHistory}=ctx;
 const a={chat:[],question:'',chatBusy:false,compareBefore:'',compareAfter:'',compareDomain:'',comparison:null,busy:false,error:'',selfCheck:null,note:'',presentation:false};
 const tr=(key)=>t(key), pct=x=>Number.isFinite(x)?(100*x).toFixed(1)+'%':'—';
 const label=code=>RC_DATA.rules.find(r=>r.code===code)?.title[state.lang]||RC_DATA.signals[code]?.title[state.lang]||code;
 const metric=(title,value,sub='')=>`<article class="card metric-card"><span>${esc(title)}</span><strong dir="auto">${esc(value)}</strong><small>${esc(sub)}</small></article>`;
 function dashboard(){
  const rows=state.cases, count=v=>rows.filter(r=>r.verdict===v).length,mean=rows.length?Math.round(rows.reduce((n,r)=>n+r.score,0)/rows.length):'—';
  return `<section class="page-intro"><div class="eyebrow">CASE INTELLIGENCE / LOCAL ONLY</div><h1>${t('dashTitle')}</h1><p>${t('dashBody')}</p></section><div class="metric-grid">${metric(t('savedCount'),rows.length)}${metric(t('high'),count('high'))}${metric(t('review'),count('review'))}${metric(t('meanScore'),mean)}</div><section class="card dashboard-cases"><div class="card-head"><h2>${t('recentCases')}</h2><button class="button secondary small" data-page="investigate">${icon('plus')}${t('investigate')}</button></div>${rows.length?rows.slice(0,8).map(r=>`<button class="case-row" data-open="${esc(r.id)}"><span class="case-id"><code>${esc(r.id)}</code><small>${esc(date(r.created_at))}</small></span><span class="case-excerpt" dir="auto">${esc(r.original_text.slice(0,100))}</span>${badge(t(r.verdict),r.verdict)}<strong>${Number(r.score)}</strong></button>`).join(''):`<div class="empty-page">${icon('folder')}<p>${t('noCasesDash')}</p></div>`}</section><section class="card release-note"><div>${icon('shield')}<h3>RealityCheck AI · 3.0.0</h3></div><p>${t('mlNotice')}</p><button class="text-button" data-page="evaluation">${t('evaluation')} ${icon('arrow')}</button></section>`;
 }
 function comparisonCard(r){
  return `<section class="card compare-result"><div class="comparison-scores"><div><span>${t('beforeText')}</span><strong>${r.before.score}<small>/100</small></strong>${badge(t(r.before.verdict),r.before.verdict)}</div><div class="delta-score"><span>${t('delta')}</span><strong dir="ltr">${r.score_delta>0?'+':''}${r.score_delta}</strong></div><div><span>${t('afterText')}</span><strong>${r.after.score}<small>/100</small></strong>${badge(t(r.after.verdict),r.after.verdict)}</div></div><div class="comparison-diff"><div><h3>${t('addedSignals')}</h3>${r.added.length?r.added.map(c=>badge(label(c),'review')).join(' '):t('noneLabel')}</div><div><h3>${t('removedSignals')}</h3>${r.removed.length?r.removed.map(c=>badge(label(c))).join(' '):t('noneLabel')}</div></div><div class="callout">${t('compareBody')}</div></section>`;
 }
 function compare(){
  return `<section class="page-intro"><div class="eyebrow">CONTROLLED COMPARISON</div><h1>${t('compareTitle')}</h1><p>${t('compareBody')}</p></section><div class="comparison-tools"><button class="button secondary small" data-adv="compare-current">${t('compareCurrent')}</button><button class="button secondary small" data-adv="compare-demo">${t('compareDemo')}</button></div><form id="compare-form"><div class="compare-inputs"><section class="card"><label for="compare-before">${t('beforeText')}</label><textarea id="compare-before" maxlength="12000" rows="7" dir="auto" required>${esc(a.compareBefore)}</textarea></section><section class="card"><label for="compare-after">${t('afterText')}</label><textarea id="compare-after" maxlength="12000" rows="7" dir="auto" required>${esc(a.compareAfter)}</textarea></section></div><div class="compare-controls"><label>${t('domainLabel')}<input id="compare-domain" dir="ltr" value="${esc(a.compareDomain)}" placeholder="bank.example"></label><button class="button primary" type="submit" ${a.busy?'disabled':''}>${icon('code')}${t(a.busy?'working':'compareRun')}</button></div>${a.error?`<div role="alert" class="error-box">${esc(a.error)}</div>`:''}</form>${a.comparison?comparisonCard(a.comparison):''}`;
 }
 function evaluation(){
  const e=RC_DATA.evaluation||{}, f=e.functional||{},c=e.rules||{},cv=e.model||{},conf=c.confusion||{};
  const errors=c.errors||[];
  return `<section class="page-intro"><div class="eyebrow">REPRODUCIBLE EVALUATION / NOT A SAFETY GUARANTEE</div><h1>${t('evalTitle')}</h1><p>${t('evalBody')}</p></section><div class="metric-grid">${metric(t('functionalTests'),f.passed??t('notRun'),f.environment||'')}${metric(t('browserTests'),e.browser?.passed??t('notRun'),e.browser?.environment||'')}${metric(t('precision'),pct(c.precision),t('regressionTitle'))}${metric(t('recall'),pct(c.recall),t('regressionTitle'))}</div><div class="evaluation-grid"><section class="card evaluation-card"><h2>${t('regressionTitle')}</h2><p>${t('challengeNote')}</p><div class="confusion-matrix">${metric(t('correctAlert'),conf.tp??'—')}${metric(t('falseNegative'),conf.fn??'—')}${metric(t('falsePositive'),conf.fp??'—')}${metric(t('correctLimited'),conf.tn??'—')}</div><p class="help">${Number(c.samples)||0} ${t('synthetic')} · ${c.threshold??25}/100</p></section><section class="card evaluation-card"><h2>${t('cvTitle')}</h2><p>${t('cvNote')}</p><dl class="definition-list"><div><dt>${t('precision')}</dt><dd>${pct(cv.precision)}</dd></div><div><dt>${t('recall')}</dt><dd>${pct(cv.recall)}</dd></div><div><dt>${t('coverage')}</dt><dd>${pct(cv.coverage)}</dd></div><div><dt>F1</dt><dd>${pct(cv.f1)}</dd></div><div><dt>Data</dt><dd>${cv.samples??240} / synthetic</dd></div></dl><div class="callout">${t('mlNotice')}</div></section></div><section class="card evaluation-card"><h2>${t('readyCheck')}</h2><p>${t('smokeNote')}</p><button class="button secondary" data-adv="self-check" ${a.busy?'disabled':''}>${icon('check')}${t('runCheck')}</button>${a.selfCheck?`<div class="check-results">${a.selfCheck.checks.map(x=>`<div><code>${esc(x.name)}</code>${badge(t(x.passed?'passedLabel':'failedLabel'),x.passed?'done':'high')}</div>`).join('')}</div>`:''}</section>${errors.length?`<section class="card evaluation-card"><h2>${t('errorsTitle')}</h2><p>${t('evalBody')}</p>${errors.slice(0,6).map(x=>`<details class="boundary-case"><summary><code>${esc(x.id)}</code> ${t(x.expected_alert?'falseNegative':'falsePositive')}</summary><blockquote dir="auto">${esc(x.text)}</blockquote><span>${t('score')}: ${x.score}/100</span></details>`).join('')}</section>`:''}`;
 }
 function localAnswer(r,q){
  const lang=RC_DATA.assistant.text[state.lang],text=RC_ML.matching(q.toLowerCase());
  let intent='fallback';for(const [key,p] of RC_DATA.assistant.patterns)if(new RegExp(p,'i').test(text)){intent=key;break;}
  let answer=lang[intent],references=[];
  if(intent==='why'){
   const signals=r.signals.filter(s=>s.weight);references=signals.map(s=>s.id);
   answer=signals.length?lang.why.replace('{score}',r.score)+'\n'+signals.map(s=>`[${s.id}] ${s.title} (+${s.weight}) — ${s.detail}`).join('\n'):lang.none;
  }
  if(intent==='url')answer=r.urls.length?lang.url.replace('{hosts}',r.urls.map(u=>u.host).join(', ')):lang.no_url;
  return {answer,references,intent,mode:'local_templates',case_id:r.id,external_request:false};
 }
 function report(){
  const r=state.report;if(!r)return '';
  const m=r.ml||{},supp=r.suppressed_signals||[];
  return `<section class="card pipeline-card"><div class="pipeline-heading"><h3>${t('pipeline')}</h3><code>v${esc(r.engine_version)} · ${Number(r.analysis_ms)||0} ms</code></div><div class="pipeline-stages">${['normalizeStage','rulesStage','contextStage','urlsStage','modelStage'].map((k,i)=>`<div><span>0${i+1}</span><strong>${t(k)}</strong>${icon(i===4&&m.status!=='completed'?'info':'check')}</div>`).join('')}</div></section><div class="advanced-report-grid"><section class="card ml-card"><div class="mini-label">${icon('code')} ${t('localML')}</div><h3>${t(m.label||'abstained')}</h3><p>${t('mlNotice')}</p>${m.top_features?.length?`<h4>${t('featuresLabel')}</h4><div class="feature-chips">${m.top_features.map(f=>`<span class="feature-chip" dir="auto">${esc(f.feature)} <b dir="ltr">${f.contribution>0?'+':''}${Number(f.contribution).toFixed(2)}</b></span>`).join('')}</div><small class="help">${t('featuresHint')}</small>`:''}${supp.length?`<details class="suppressed"><summary>${t('suppressed')} (${supp.length})</summary><p>${t('suppressedNotice')}</p>${supp.map(s=>`<blockquote dir="auto">${esc(s.evidence)}</blockquote>`).join('')}</details>`:''}</section><section class="card assistant-card"><div class="mini-label">${icon('message')}${t('assistantTitle')}</div><p>${t('assistantLocal')}</p><div class="ask-pills">${['askWhy','askNext','askModel'].map(k=>`<button data-ask="${k}">${t(k)}</button>`).join('')}</div><div class="chat-thread" role="log" aria-live="polite">${a.chat.map(c=>`<article class="chat-entry"><div class="chat-question" dir="auto">${esc(c.question)}</div><div class="chat-answer" dir="auto">${esc(c.answer)}</div><small>${t(c.mode==='cloud_ai'?'cloudAnswer':c.mode==='local_fallback'?'fallbackAnswer':'localAnswer')}</small></article>`).join('')}</div><form id="assistant-form"><label class="sr-only" for="assistant-question">${t('askPlaceholder')}</label><div class="assistant-input"><input id="assistant-question" maxlength="1200" dir="auto" placeholder="${esc(t('askPlaceholder'))}" value="${esc(a.question)}" ${a.chatBusy?'disabled':''}><button class="button primary small" type="submit" ${a.chatBusy?'disabled':''}>${t(a.chatBusy?'working':'askSend')}</button></div>${state.mode==='server'&&state.health?.ai_configured?`<label class="checkbox-row"><input type="checkbox" id="assistant-cloud"><span>${t('cloudOption')}</span></label>`:''}</form></section></div><section class="card notes-card"><h3>${t('analystNote')}</h3><label class="sr-only" for="analyst-note">${t('analystNote')}</label><textarea id="analyst-note" maxlength="2000" rows="3" dir="auto" placeholder="${esc(t('notePlaceholder'))}">${esc(a.note||r.analyst_note||'')}</textarea><div><label class="checkbox-row"><input id="reviewed-note" type="checkbox" ${r.review_status==='reviewed'?'checked':''}><span>${t('reviewed')}</span></label><button class="button secondary small" data-adv="save-note">${t('saveNote')}</button></div></section>`;
 }
 async function ask(question,cloud=false){
  if(!state.report||a.chatBusy||!question.trim())return;
  if(cloud&&!confirm(t('privacyCloud')))return;
  a.chatBusy=true;a.question='';render();
  try{
   const result=state.mode==='server'?await api('/assistant',{method:'POST',body:JSON.stringify({case_id:state.report.id,question,language:state.lang,use_ai:cloud,consent:cloud})}):localAnswer(state.report,question);
   a.chat.push({question,...result});if(a.chat.length>12)a.chat.shift();
  }catch(e){toast(e.message==='REPORT_EXPIRED_RUN_AGAIN'?t('expiredError'):t('networkError'));}
  finally{a.chatBusy=false;render();document.querySelector('.chat-thread')?.scrollTo({top:100000,behavior:'smooth'});}
 }
 async function runCompare(){
  if(a.busy||!a.compareBefore.trim()||!a.compareAfter.trim())return;
  a.busy=true;a.error='';render();
  try{
   if(state.mode==='server')a.comparison=await api('/compare',{method:'POST',body:JSON.stringify({before:a.compareBefore,after:a.compareAfter,language:state.lang,expected_domain:a.compareDomain})});
   else{
    const before=RC.analyze({text:a.compareBefore,language:state.lang,expected_domain:a.compareDomain}),after=RC.analyze({text:a.compareAfter,language:state.lang,expected_domain:a.compareDomain});
    const x=new Set(before.signals.map(s=>s.code)),y=new Set(after.signals.map(s=>s.code));
    a.comparison={before,after,score_delta:after.score-before.score,added:[...y].filter(c=>!x.has(c)),removed:[...x].filter(c=>!y.has(c))};
   }
  }catch(e){a.error=/domain|host/i.test(e.message)?t('invalidDomain'):t('error');}
  finally{a.busy=false;render();}
 }
 function download(name,text,type='text/html;charset=utf-8'){
  const u=URL.createObjectURL(new Blob([text],{type})),el=document.createElement('a');el.href=u;el.download=name;el.click();setTimeout(()=>URL.revokeObjectURL(u),2000);
 }
 function exportHTML(){
  const r=state.report;if(!r||!confirm(t('exportConfirm')))return;
  const html=`<!doctype html><html lang="${state.lang}" dir="${state.lang==='en'?'ltr':'rtl'}"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta name="referrer" content="no-referrer"><title>${esc(r.id)} — RealityCheck AI</title><style>body{font:16px/1.8 system-ui,sans-serif;max-width:900px;margin:40px auto;padding:20px;color:#172739}h1,h2{line-height:1.3}header{border-bottom:3px solid #137966;padding-bottom:24px}code{direction:ltr;display:inline-block}section{margin:24px 0;padding:20px;border:1px solid #b8cad3;border-radius:12px}blockquote{background:#f2f6f8;padding:12px;white-space:pre-wrap;overflow-wrap:anywhere}small{color:#536577}article{border-bottom:1px solid #d8e2e8;padding:14px 0}p{white-space:pre-wrap} @media print{body{margin:0;font-size:12px}section{break-inside:avoid}}</style><header><small>ACADEMIC RELEASE 3.0.0 · EVIDENCE REPORT</small><h1>RealityCheck AI</h1><code>${esc(r.id)}</code><p>${esc(date(r.created_at))}</p></header><section><h2>${t(r.verdict)} · ${r.score}/100</h2><p>${t('scoreNote')}</p><p>${t('limitsBody')}</p></section><section><h2>${t('messageLabel')}</h2><blockquote dir="auto">${esc(r.original_text)}</blockquote></section><section><h2>${t('evidence')}</h2>${r.signals.map(s=>`<article><h3>[${esc(s.id)}] ${esc(s.title)} (+${s.weight})</h3><p>${esc(s.detail)}</p><blockquote dir="auto">${esc(s.evidence)}</blockquote></article>`).join('')||t('noSignals')}</section>${r.urls.length?`<section><h2>${t('urls')}</h2>${r.urls.map(u=>`<p><code>${esc(u.host)}</code></p><blockquote dir="ltr">${esc(u.raw)}</blockquote>`).join('')}<p>${t('notVisited')}</p></section>`:''}<section><h2>${t('localML')}</h2><p>${t(r.ml?.label||'abstained')}</p><p>${t('mlNotice')}</p></section>${r.analyst_note?`<section><h2>${t('analystNote')}</h2><p dir="auto">${esc(r.analyst_note)}</p></section>`:''}<section><h2>${t('next')}</h2><p>${t('advice1')}\n${t('advice2')}\n${t('advice3')}</p></section><small>${t('notProduction')} · ${esc(r.fingerprint||'Portable report')}<br>${t('footer')}</small></html>`;
  download(r.id+'_report.html',html);
 }
 async function click(el){
  if(el.dataset.ask){await ask(t(el.dataset.ask));return true;}
  const act=el.dataset.adv;if(!act)return false;
  if(act==='compare-current'){a.compareBefore=state.report?.original_text||state.text;a.compareDomain=state.domain;render();}
  if(act==='compare-demo'){
   const samples={ar:['لازم تدخل كلمة المرور ورمز التحقق فورا قبل إغلاق الحساب.','لا ترسل كلمة المرور أو رمز التحقق لأي شخص.'],he:['שלח סיסמה וקוד אימות מיד לפני חסימת חשבון.','אל תשלח סיסמה או קוד אימות לאף אחד.'],en:['Send your password and verification code immediately to avoid account closure.','Never share your password or verification code.']};
   [a.compareBefore,a.compareAfter]=samples[state.lang];a.compareDomain='';a.comparison=null;render();
  }
  if(act==='self-check'){
   a.busy=true;render();
   try{
    if(state.mode==='server')a.selfCheck=await api('/self-check',{method:'POST',body:'{}'});
    else {const checks=[['credential_request','لازم تدخل كلمة المرور فورا',true],['negative_request','لا ترسل كلمة المرور لأي شخص',false],['english_request','Share your verification code immediately',true],['hebrew_request','שלח קוד אימות מיד',true]].map(([name,text,want])=>({name,passed:RC.analyze({text}).signals.some(s=>s.code==='credentials')===want}));a.selfCheck={checks,passed:checks.every(c=>c.passed)};}
   }catch(e){toast(t('networkError'));}finally{a.busy=false;render();}
  }
  if(act==='save-note'){
   const r=state.report;if(!state.cases.some(c=>c.id===r.id)){toast(t('saveFirst'));return true;}
   const note=document.getElementById('analyst-note').value,status=document.getElementById('reviewed-note').checked?'reviewed':'open';
   try{
    if(state.mode==='server')await api('/cases/'+encodeURIComponent(r.id)+'/note',{method:'POST',body:JSON.stringify({note,status,consent:true})});
    else{const rows=state.cases.map(c=>c.id===r.id?{...c,analyst_note:note,review_status:status}:c);localStorage.setItem('rc-cases-v1',JSON.stringify(rows));}
    r.analyst_note=note;r.review_status=status;a.note=note;await refreshHistory();render();toast(t('saved'));
   }catch(e){toast(t('error'));}
  }
  if(act==='export-html')exportHTML();
  if(act==='presentation'){a.presentation=!a.presentation;document.body.classList.toggle('presentation-mode',a.presentation);}
  return true;
 }
 function input(el){
  const map={'compare-before':'compareBefore','compare-after':'compareAfter','compare-domain':'compareDomain','assistant-question':'question','analyst-note':'note'};
  if(map[el.id])a[map[el.id]]=el.value;
 }
 function submit(event){
  if(event.target.id==='assistant-form'){event.preventDefault();const cloud=!!document.getElementById('assistant-cloud')?.checked;ask(a.question,cloud);return true;}
  if(event.target.id==='compare-form'){event.preventDefault();runCompare();return true;}
  return false;
 }
 function reset(){a.chat=[];a.question='';a.note='';}
 return {dashboard,compare,evaluation,report,click,input,submit,reset,localAnswer,exportHTML};
}};
