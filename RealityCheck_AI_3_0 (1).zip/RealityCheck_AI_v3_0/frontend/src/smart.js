/* 3.0 Smart Check — one input for a message, link, phone number or screenshot.
   Pure helpers (no DOM). Phone analysis is offline: it can tell where a number is
   registered and whether it sits in an unusual range, but NOT who owns it. */
window.RC_Smart=(()=>{
 const AR_DIGITS=s=>String(s).replace(/[٠-٩]/g,d=>String(d.charCodeAt(0)-0x660)).replace(/[۰-۹]/g,d=>String(d.charCodeAt(0)-0x6f0));
 const COUNTRIES={
  '972':{ar:'إسرائيل',he:'ישראל',en:'Israel'},'970':{ar:'فلسطين',he:'פלסטין',en:'Palestine'},'962':{ar:'الأردن',he:'ירדן',en:'Jordan'},'20':{ar:'مصر',he:'מצרים',en:'Egypt'},
  '966':{ar:'السعودية',he:'ערב הסעודית',en:'Saudi Arabia'},'971':{ar:'الإمارات',he:'איחוד האמירויות',en:'UAE'},'974':{ar:'قطر',he:'קטאר',en:'Qatar'},'965':{ar:'الكويت',he:'כווית',en:'Kuwait'},
  '961':{ar:'لبنان',he:'לבנון',en:'Lebanon'},'963':{ar:'سوريا',he:'סוריה',en:'Syria'},'964':{ar:'العراق',he:'עיראק',en:'Iraq'},'212':{ar:'المغرب',he:'מרוקו',en:'Morocco'},'213':{ar:'الجزائر',he:'אלג׳יריה',en:'Algeria'},'216':{ar:'تونس',he:'תוניסיה',en:'Tunisia'},
  '90':{ar:'تركيا',he:'טורקיה',en:'Turkey'},'1':{ar:'الولايات المتحدة/كندا',he:'ארה״ב/קנדה',en:'USA/Canada'},'44':{ar:'بريطانيا',he:'בריטניה',en:'UK'},'49':{ar:'ألمانيا',he:'גרמניה',en:'Germany'},
  '33':{ar:'فرنسا',he:'צרפת',en:'France'},'39':{ar:'إيطاليا',he:'איטליה',en:'Italy'},'34':{ar:'إسبانيا',he:'ספרד',en:'Spain'},'31':{ar:'هولندا',he:'הולנד',en:'Netherlands'},'7':{ar:'روسيا/كازاخستان',he:'רוסיה/קזחסטן',en:'Russia/Kazakhstan'},
  '380':{ar:'أوكرانيا',he:'אוקראינה',en:'Ukraine'},'91':{ar:'الهند',he:'הודו',en:'India'},'92':{ar:'باكستان',he:'פקיסטן',en:'Pakistan'},'86':{ar:'الصين',he:'סין',en:'China'},'62':{ar:'إندونيسيا',he:'אינדונזיה',en:'Indonesia'},
  '63':{ar:'الفلبين',he:'הפיליפינים',en:'Philippines'},'234':{ar:'نيجيريا',he:'ניגריה',en:'Nigeria'},'61':{ar:'أستراليا',he:'אוסטרליה',en:'Australia'},'55':{ar:'البرازيل',he:'ברזיל',en:'Brazil'}
 };
 // ITU international ranges that are not tied to a country: satellite (870, 881), international networks (882, 883), premium-rate IPRS (979).
 const SPECIAL={'870':'satellite','881':'satellite','882':'network','883':'network','979':'premium'};
 const LOCAL_ENTITIES=new Set(['government','israel_post','hapoalim','leumi','discount','mizrahi','bank_of_palestine']);
 const PHONE_RE=/(?:\+|00)\d[\d\s\-().]{6,18}\d|(?<![\d\w])0\d{1,2}[\s-]?\d{3}[\s-]?\d{3,4}(?![\d\w])|(?<![\d\w])1[\s-]?(?:800|700|900|901|599)[\s-]?\d{2,3}[\s-]?\d{3,4}(?![\d\w])/g;
 function parsePhone(raw){
  const digits=AR_DIGITS(raw).replace(/[^\d+]/g,'');let intl=null,local=null;
  if(digits.startsWith('+'))intl=digits.slice(1);else if(digits.startsWith('00'))intl=digits.slice(2);else local=digits;
  if(intl){
   for(const len of [3,2,1]){const cc=intl.slice(0,len);if(SPECIAL[cc])return {raw,e164:'+'+intl,cc,special:SPECIAL[cc]};if(COUNTRIES[cc])return {raw,e164:'+'+intl,cc,country:COUNTRIES[cc]};}
   return {raw,e164:'+'+intl,cc:null};
  }
  if(/^1(?:900|901)/.test(local))return {raw,e164:local,cc:'972',country:COUNTRIES['972'],premium:true,local:true};
  if(/^1(?:800|700|599)/.test(local))return {raw,e164:local,cc:'972',country:COUNTRIES['972'],tollfree:true,local:true};
  return {raw,e164:local,cc:null,local:true};
 }
 function phones(text){const out=[];const seen=new Set();for(const m of AR_DIGITS(text).matchAll(PHONE_RE)){const p=parsePhone(m[0].trim());const key=p.e164;if(key.replace(/\D/g,'').length<8||seen.has(key))continue;seen.add(key);out.push(p);}return out;}
 function detectKind(text){
  const t=AR_DIGITS(String(text).trim());
  if(!t)return 'empty';
  if(/^[+\d][\d\s\-().+]{6,22}$/.test(t)&&t.replace(/\D/g,'').length>=7)return 'phone';
  if(/^(?:https?:\/\/|www\.)\S+$/i.test(t)||/^[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:\/\S*)?$/i.test(t))return 'url';
  return 'message';
 }
 const W={special:35,premium:20,local_entity_foreign:25};
 function phoneFindings(list,entityId){
  const f=[];
  for(const p of list){
   if(p.special){f.push({code:'phone_special',weight:W.special,phone:p});continue;}
   else if(p.premium)f.push({code:'phone_premium',weight:W.premium,phone:p});
   if(entityId&&LOCAL_ENTITIES.has(entityId)&&p.cc&&!['972','970'].includes(p.cc)&&!p.local)f.push({code:'phone_local_entity_foreign',weight:W.local_entity_foreign,phone:p});
  }
  return f;
 }
 // A well-known name planted inside a link that the organization does not own (works even when the message names nobody).
 function linkBrandFindings(urls,data){
  const out=[];if(!data)return out;
  const gov=(data.government_patterns||[]).map(p=>new RegExp(p));
  for(const u of urls||[]){
   const host=String(u.host||'').toLowerCase();if(!host)continue;
   const c=host.replace(/-/g,''),variants=[c,c.replace(/[01345]/g,d=>({'0':'o','1':'l','3':'e','4':'a','5':'s'}[d])),c.replace(/1/g,'i')];
   for(const e of data.entities){
    const official=e.official.some(d=>host===d||host.endsWith('.'+d))||(e.kind==='government'&&gov.some(p=>p.test(host)));if(official)continue;
    const tokens=[...new Set([...e.official.map(d=>d.split('.')[0].replace(/-/g,'')),...e.cues.map(x=>x.toLowerCase()).filter(x=>/^[a-z0-9]{4,}$/.test(x))])].filter(t=>t.length>=4);
    if(tokens.some(t=>variants.some(v=>v.includes(t)))){out.push({code:'link_brand',weight:30,host,entity:e});break;}
   }
  }
  return out;
 }
 // Offline website checks: where a link really goes and whether it looks like a throwaway payment/login page.
 const SECOND_LEVEL=new Set(['co','com','org','net','gov','ac','edu','muni','ltd','plc','or','ne','go']);
 function realDomain(host){const h=String(host||'').toLowerCase().replace(/\.$/,'');if(/^\d+(\.\d+){3}$/.test(h)||h.includes(':'))return h;const l=h.split('.');if(l.length<=2)return h;return SECOND_LEVEL.has(l[l.length-2])&&l[l.length-1].length===2?l.slice(-3).join('.'):l.slice(-2).join('.');}
 // TLDs frequently seen in phishing reports; a hint, never proof on its own.
 const RISKY_TLDS=new Set(['xyz','top','click','live','shop','icu','buzz','rest','cyou','sbs','cfd','monster','quest','lol','bond','support','help','online','site','store','vip','win','loan','work','tk','ml','ga','cf','gq','zip','mov']);
 const PAY_WORDS=/(^|[^a-z])(pay|payment|payments|visa|mastercard|card|billing|checkout|verify|verification|secure|login|signin|update|wallet|refund|bonus|prize|otp|kyc|unlock|confirm|bank)(?=[^a-z]|$)/;
 function isOfficial(host,data){const gov=(data?.government_patterns||[]).map(p=>new RegExp(p));return (data?.entities||[]).some(e=>e.official.some(d=>host===d||host.endsWith('.'+d)))||gov.some(p=>p.test(host));}
 function linkFindings(urls,data){
  const out=[];
  for(const u of urls||[]){
   const host=String(u.host||'').toLowerCase();if(!host||isOfficial(host,data))continue;
   const real=realDomain(host),tld=real.split('.').pop(),label=real.split('.')[0];
   let path='';try{const raw=u.raw||u.url||host;const x=new URL(/^[a-z]+:\/\//i.test(raw)?raw.replace(/^hxxp/i,'http'):'https://'+raw);path=(x.pathname+x.search).toLowerCase();}catch{}
   const words=(host.replace(/\./g,' ')+' '+path.replace(/[\/?=&#._-]/g,' ')).replace(/[01345]/g,d=>({'0':'o','1':'l','3':'e','4':'a','5':'s'}[d]));
   if(PAY_WORDS.test(words))out.push({code:'pay_page',weight:15,host,real});
   if(RISKY_TLDS.has(tld))out.push({code:'risky_tld',weight:12,host,real,tld});
   if(host!==real&&host.replace(/^www\./,'')!==real&&host.split('.').length-real.split('.').length>=2)out.push({code:'deep_sub',weight:15,host,real});
   if((label.match(/-/g)||[]).length>=2||/\d{4,}/.test(label))out.push({code:'odd_name',weight:8,host,real});
  }
  return out;
 }
 function verdictOf(score){return score>=55?'high':score>=25?'review':'limited';}
 return {phones,parsePhone,detectKind,phoneFindings,linkBrandFindings,linkFindings,realDomain,verdictOf,COUNTRIES};
})();
