STATIC FALLBACK ONLY — not the full 3.0 application (Red Team Arena, Manipulation DNA, X-ray and Human vs AI DO work here).
index.html supports individual message and URL checks in a desktop browser.
Campaign analysis, saved run review and the new local API require the Python server.
This static file contains no API keys. Do not add keys to frontend JavaScript.
Do not expose the unauthenticated local Python server to the public internet.
