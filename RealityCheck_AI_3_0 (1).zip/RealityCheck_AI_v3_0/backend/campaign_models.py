"""Bounded, explicit contracts for the local campaign workbench."""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from .analyzer import normalize_domain

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

class CampaignRecord(StrictModel):
    id: str = Field(min_length=1, max_length=64, pattern=r'^[A-Za-z0-9_-]+$')
    text: str = Field(min_length=1, max_length=6000)
    channel: Literal['sms', 'email', 'whatsapp', 'web', 'other', 'unknown'] = 'unknown'
    received_at: str | None = Field(default=None, max_length=40)

    @field_validator('text')
    @classmethod
    def valid_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError('Message text cannot be blank')
        if '\x00' in value:
            raise ValueError('NUL characters are not supported')
        return value.strip()

    @field_validator('received_at')
    @classmethod
    def valid_date(cls, value: str | None) -> str | None:
        if not value or not value.strip():
            return None
        try:
            stamp = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
        except ValueError as exc:
            raise ValueError('Use an ISO date/time, e.g. 2026-11-01T10:00:00+02:00') from exc
        if not 2000 <= stamp.year <= 2100:
            raise ValueError('received_at must be between 2000 and 2100')
        # Date-only / naive timestamps deliberately rejected: do not invent a timezone.
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            raise ValueError('received_at requires a timezone or Z; leave blank if unknown')
        return stamp.astimezone(timezone.utc).isoformat()

class BrandProfile(StrictModel):
    name: str = Field(default='', max_length=80)
    aliases: list[str] = Field(default_factory=list, max_length=10)
    official_domains: list[str] = Field(default_factory=list, max_length=10)

    @field_validator('aliases')
    @classmethod
    def aliases_valid(cls, values: list[str]) -> list[str]:
        clean = []
        for value in values:
            value = value.strip()
            if not 2 <= len(value) <= 80:
                raise ValueError('Each alias must be 2–80 characters')
            if value not in clean:
                clean.append(value)
        return clean

    @field_validator('official_domains')
    @classmethod
    def domains_valid(cls, values: list[str]) -> list[str]:
        clean = []
        for value in values:
            domain = normalize_domain(value)
            if not domain:
                raise ValueError('Official domain cannot be empty')
            if domain not in clean:
                clean.append(domain)
        return clean

    @model_validator(mode='after')
    def profile_complete(self):
        if self.official_domains and not (self.name.strip() or self.aliases):
            raise ValueError('Supply a brand name or alias when using official domains')
        return self

class CampaignRequest(StrictModel):
    records: list[CampaignRecord] = Field(min_length=1, max_length=200)
    title: str = Field(default='Local investigation', min_length=1, max_length=100)
    language: Literal['ar', 'he', 'en'] = 'ar'
    sensitivity: Literal['balanced', 'strict'] = 'balanced'
    profile: BrandProfile = Field(default_factory=BrandProfile)

    @model_validator(mode='after')
    def bounded_unique(self):
        ids = [record.id for record in self.records]
        if len(set(ids)) != len(ids):
            raise ValueError('Record IDs must be unique')
        if sum(len(record.text) for record in self.records) > 300000:
            raise ValueError('Batch text limit is 300,000 characters')
        if not self.title.strip():
            raise ValueError('Title cannot be blank')
        return self

class CampaignImport(StrictModel):
    content: str = Field(min_length=1, max_length=1500000)
    format: Literal['csv', 'json', 'jsonl', 'lines']

class CampaignSave(StrictModel):
    run_id: str = Field(pattern=r'^R2-[A-F0-9]{12}$')
    consent: Literal[True]

class CampaignReview(StrictModel):
    revision: int = Field(ge=1)
    group_id: str = Field(pattern=r'^G-[A-F0-9]{10}$')
    status: Literal['open', 'investigating', 'confirmed_scam', 'benign', 'inconclusive']
    note: str = Field(default='', max_length=1200)
    consent: Literal[True]
