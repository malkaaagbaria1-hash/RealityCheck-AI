from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator

class AnalyzeRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    text: str=Field(min_length=1,max_length=12000)
    input_type: Literal['message','url','image_text']='message'
    language: Literal['ar','he','en']='ar'
    expected_domain: str=Field(default='',max_length=253)
    use_ai: bool=False
    use_reputation: bool=False
    @field_validator('text')
    @classmethod
    def not_blank(cls,value):
        if not value.strip(): raise ValueError('Content cannot be blank')
        return value

class SaveRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    case_id: str=Field(min_length=4,max_length=40)
    consent: Literal[True]

class ImageRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    data_url: str=Field(max_length=6000000)
    consent: Literal[True]
    language: Literal['ar','he','en']='ar'

class AssistantRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    case_id: str=Field(min_length=4,max_length=40)
    question: str=Field(min_length=1,max_length=1200)
    language: Literal['ar','he','en']='ar'
    use_ai: bool=False
    consent: bool=False

class CompareRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    before: str=Field(min_length=1,max_length=12000)
    after: str=Field(min_length=1,max_length=12000)
    language: Literal['ar','he','en']='ar'
    expected_domain: str=Field(default='',max_length=253)

class NoteRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    note: str=Field(default='',max_length=2000)
    status: Literal['open','reviewed']='open'
    consent: Literal[True]
