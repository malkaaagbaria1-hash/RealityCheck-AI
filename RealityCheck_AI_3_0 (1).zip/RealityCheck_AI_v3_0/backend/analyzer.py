"""Deterministic, explainable triage. No requests to user-supplied destinations."""
from __future__ import annotations
import ipaddress, json, re, unicodedata, uuid, hashlib, time
from .matching import matching_view, suppression_reason, shield_view, cue_pattern
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parents[1]
RULES=json.loads((ROOT/'shared/rules.json').read_text(encoding='utf-8'))
SIGNALS=json.loads((ROOT/'shared/signals.json').read_text(encoding='utf-8'))
VERSION='3.0.0'
COMPILED_RULES=[(rule,re.compile(rule['pattern'],re.I)) for rule in RULES]
ENTITY_DATA=json.loads((ROOT/'shared/entities.json').read_text(encoding='utf-8'))
GOV_PATTERNS=[re.compile(p) for p in ENTITY_DATA['government_patterns']]
ENTITIES=sorted(ENTITY_DATA['entities'],key=lambda e:e['kind']=='government')
ENTITY_RES=[(e,re.compile('|'.join(cue_pattern(c) for c in e['cues']),re.I)) for e in ENTITIES]


def claimed_entity(content: str):
    lowered=content.lower()
    for entity, pattern in ENTITY_RES:
        if pattern.search(lowered): return entity
    return None


def official_host(entity: dict, host: str) -> bool:
    if any(host==d or host.endswith('.'+d) for d in entity['official']): return True
    return entity['kind']=='government' and any(p.search(host) for p in GOV_PATTERNS)


def bait_tokens(entity: dict) -> list[str]:
    tokens={d.split('.')[0].replace('-','') for d in entity['official']}
    tokens|={c.lower() for c in entity['cues'] if re.fullmatch(r'[a-z0-9]{3,}',c.lower())}
    return [t for t in tokens if len(t)>=3]
SHORTENERS={'bit.ly','tinyurl.com','t.co','goo.gl','cutt.ly','rb.gy','shorturl.at','is.gd','ow.ly','buff.ly'}
NEGATION=re.compile(r"(?:\b(?:never|do not|don't|not to)\s+|(?:لا|ما)\s+(?:ت)?|אל\s+(?:ת)?)$",re.I)
BIDI=re.compile('[\u202a-\u202e\u2066-\u2069]')
URL_PATTERN=re.compile(r'(?:https?://|hxxps?://|www\.)[^\s<>"\u201c\u201d]+',re.I)
DEMO_SUFFIXES=('.example','.test','.invalid','.localhost')


def one_edit_or_equal(a: str,b: str) -> bool:
    if abs(len(a)-len(b))>1: return False
    i=j=changes=0
    while i<len(a) and j<len(b):
        if a[i]==b[j]: i+=1; j+=1; continue
        changes+=1
        if changes>1: return False
        if len(a)>=len(b): i+=1
        if len(b)>=len(a): j+=1
    return changes+len(a)-i+len(b)-j<=1


def normalize_text(text: str) -> str:
    return unicodedata.normalize('NFKC', text).replace('hxxps://','https://').replace('hxxp://','http://').replace('[.]','.').replace('(.)','.')


def normalize_domain(value: str) -> str:
    value=value.strip().lower().rstrip('.')
    if not value:
        return ''
    if '://' in value or any(c in value for c in '/@?#: ') or '.' not in value:
        raise ValueError('expected_domain must be a hostname, such as example.org, without a path or scheme')
    try:
        value=value.encode('idna').decode('ascii')
    except UnicodeError as exc:
        raise ValueError('Invalid hostname') from exc
    if len(value)>253 or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',part) for part in value.split('.')):
        raise ValueError('Invalid hostname')
    return value


def eligible_public_host(host: str) -> bool:
    if not host: return False
    try:
        ipaddress.ip_address(host)
        return False  # Never send IP addresses to this domain-only connector.
    except ValueError:
        pass
    if host in {'localhost','example.com','example.net','example.org'} or host.endswith(DEMO_SUFFIXES+('.local','.internal','.lan')):
        return False
    if any(host.endswith('.'+s) for s in ('example.com','example.net','example.org')):
        return False
    try:
        normalize_domain(host)
        return True
    except ValueError:
        return False


def parse_url(value: str) -> dict:
    raw=value.strip().rstrip('.,;!،؛。)')
    value=normalize_text(raw)
    if BIDI.search(value) or '\\' in value or any(ord(c)<32 for c in value):
        raise ValueError('Unsupported control characters or backslashes in URL')
    if not re.match(r'^https?://',value,re.I):
        if '://' in value or re.match(r'^(?:javascript|data|file|mailto):',value,re.I):
            raise ValueError('Only HTTP and HTTPS URLs are supported')
        value='https://'+value
    if len(value)>4096:
        raise ValueError('URL is too long')
    try:
        parts=urlsplit(value)
        host=parts.hostname or ''
        if not host or '%' in host or any(c.isspace() for c in host):
            raise ValueError('Invalid URL hostname')
        port=parts.port
        raw_host=host.lower().rstrip('.')
        host=raw_host.encode('idna').decode('ascii')
        try:
            address=ipaddress.ip_address(host)
            is_ip=True; is_private=not address.is_global
        except ValueError:
            normalize_domain(host) if host!='localhost' else None
            is_ip=False; is_private=host=='localhost' or host.endswith(('.localhost','.local','.internal','.lan'))
        try:
            unicode_host=host.encode('ascii').decode('idna')
        except UnicodeError:
            unicode_host=raw_host
        scripts=set()
        for c in unicode_host:
            name=unicodedata.name(c,'')
            for script in ('LATIN','CYRILLIC','GREEK'):
                if script in name: scripts.add(script)
        return dict(raw=raw,host=host,unicode_host=unicode_host,scheme=parts.scheme.lower(),port=port,
                    has_userinfo=parts.username is not None,is_ip=is_ip,is_private=is_private,
                    idn='xn--' in host,mixed_script=len(scripts)>1,
                    demo=host in {'example.com','example.org','example.net'} or host.endswith(DEMO_SUFFIXES) or
                         any(host.endswith('.'+x) for x in ('example.com','example.org','example.net')),
                    eligible=eligible_public_host(host))
    except (ValueError,UnicodeError) as exc:
        raise ValueError('Invalid or unsupported URL') from exc


def find_urls(text: str) -> list[str]:
    values=[m.group(0).rstrip('.,;!،؛。)') for m in URL_PATTERN.finditer(text)]
    # Also recognize ordinary bare domains; skip email addresses.
    for token in text.split():
        token=token.strip('()[]{}<>,;!،؛"\'')
        if '@' not in token and '.' in token and '://' not in token and token not in values:
            if re.fullmatch(r'[^\s/:]+\.[a-zA-Z\u0080-\uffff]{2,}(?:/[^\s]*)?',token):
                values.append(token)
    return list(dict.fromkeys(values))


def add_signal(signals: list, code: str, weight: int, lang: str, evidence: str, group='url') -> None:
    data=SIGNALS[code]
    signals.append(dict(code=code,group=group,weight=weight,severity='high' if weight>=28 else 'medium' if weight else 'info',
                        title=data['title'][lang],detail=data['detail'][lang],evidence=evidence[:300]))


def analyze(text: str, input_type='message', language='ar', expected_domain='', shield: bool=True) -> dict:
    if language not in {'ar','he','en'}: raise ValueError('Unsupported language')
    started=time.perf_counter()
    text=text.strip()
    if not text or len(text)>12000: raise ValueError('Enter 1–12000 characters')
    if input_type not in {'message','url','image_text'}: raise ValueError('Unsupported input type')
    expected=normalize_domain(expected_domain)
    normalized=normalize_text(text)
    signals=[]; suppressed=[]
    # Match messages, not URL paths, to reduce unrelated keyword hits.
    match_text, offsets=matching_view(text)
    content=URL_PATTERN.sub(lambda m:' '*len(m.group()),match_text)
    if shield: content, offsets=shield_view(content, offsets)
    # Rules are shared with the portable engine. Each positive is counted once.
    if input_type!='url':
        for rule, pattern in COMPILED_RULES:
            for match in pattern.finditer(content):
                lo=offsets[match.start()]; hi=offsets[match.end()-1]+1
                reason=suppression_reason(content,match.start(),rule['code'])
                if reason:
                    suppressed.append({'code':rule['code'],'reason':reason,'evidence':text[lo:hi][:300]})
                    continue
                signals.append(dict(code=rule['code'],group=rule['group'],weight=rule['weight'],
                    severity='high' if rule['weight']>=28 else 'medium',
                    title=rule['title'][language],detail=rule['detail'][language],
                    evidence=text[lo:hi][:300],start=lo,end=hi,source='local_rule'))
                break
    entity=None if (expected or input_type=='url') else claimed_entity(content)
    # Government words are generic; only treat them as a claim when the message also asks or pressures.
    if entity and entity['kind']=='government' and not any(x['weight'] for x in signals): entity=None
    candidates=[text] if input_type=='url' else find_urls(normalized)
    urls=[]; invalid=0
    for candidate in candidates[:10]:
        try: info=parse_url(candidate)
        except ValueError:
            if input_type=='url': raise
            invalid+=1; continue
        urls.append(info)
        if info['scheme']=='http': add_signal(signals,'http',5,language,info['host'])
        if info['has_userinfo']: add_signal(signals,'userinfo',28,language,info['host'])
        if info['is_private']: add_signal(signals,'private',0,language,info['host'])
        elif info['is_ip']: add_signal(signals,'ip',12,language,info['host'])
        if info['host'] in SHORTENERS: add_signal(signals,'shortener',10,language,info['host'])
        if info['idn']: add_signal(signals,'idn',0,language,info['host'])
        if info['mixed_script']: add_signal(signals,'mixed_script',12,language,info['host'])
        if info['port'] and info['port'] not in (80,443): add_signal(signals,'port',5,language,str(info['port']))
        if info['demo']: add_signal(signals,'demo_domain',0,language,info['host'])
        if entity and not official_host(entity,info['host']):
            add_signal(signals,'claimed_mismatch',28,language,f"{entity['name'][language]} · {info['host']}")
            compact=info['host'].replace('-','')
            compact=compact+' '+compact.translate(str.maketrans('01345','oleas'))+' '+compact.translate(str.maketrans('1','i'))
            if any(t in compact for t in bait_tokens(entity)):
                add_signal(signals,'claimed_bait',12,language,info['host'])
        if expected and not (info['host']==expected or info['host'].endswith('.'+expected)):
            add_signal(signals,'domain_mismatch',28,language,f"{info['host']} ≠ {expected}")
            if expected in info['raw'].lower():
                add_signal(signals,'brand_bait',12,language,info['host'])
            else:
                # Compare complete hostnames; do not guess registrable domain boundaries.
                skeleton=str.maketrans({'0':'o','1':'l','а':'a','е':'e','о':'o','р':'p','с':'c','х':'x'})
                given=info['unicode_host'].translate(skeleton)
                reference=expected.translate(skeleton)
                if min(len(given),len(reference))>=5 and one_edit_or_equal(given,reference):
                    add_signal(signals,'lookalike',12,language,f"{info['host']} ≈ {expected}")

    if BIDI.search(text): add_signal(signals,'bidi',10,language,'Unicode bidi controls','format')
    if re.search(r'ignore (?:all |the )?(?:previous |prior )?instructions|تجاهل التعليمات|התעלם מההוראות',content,re.I):
        add_signal(signals,'injection',0,language,'Untrusted embedded instruction','format')
    codes={s['code'] for s in signals}
    if codes & {'credentials','payment','remote_access'} and (codes & {'urgency','threat'} or urls):
        add_signal(signals,'compound',18,language,' + '.join(sorted(codes & {'credentials','payment','remote_access','urgency','threat'})),'context')
    # Count each rule once, even if the message contains repeated links.
    weights={}
    for signal in signals: weights[signal['code']]=max(weights.get(signal['code'],0),signal['weight'])
    score=min(100,sum(weights.values()))
    verdict='high' if score>=55 else 'review' if score>=25 else 'limited'
    for i,signal in enumerate(signals): signal['id']=f'E{i+1:02}'; signal.setdefault('source','local_rule')
    for i,url in enumerate(urls): url['id']=f'U{i+1:02}'
    from .ml_model import predict
    ml=predict(text) if input_type!='url' else {'status':'abstained','reason':'url_only','label':None,'top_features':[]}
    return dict(id='RC-'+uuid.uuid4().hex[:10].upper(),created_at=datetime.now(timezone.utc).isoformat(),
                engine_version=VERSION,language=language,input_type=input_type,original_text=text,
                expected_domain=expected,claimed_entity=(entity or {}).get('id'),score=score,verdict=verdict,signals=signals,urls=urls,
                invalid_urls=invalid,urls_truncated=len(candidates)>10,
                providers={'local':'completed','reputation':'not_requested','ai':'not_requested'},
                reputation=[],ai_summary=None,notes=[],schema_version=2,
                suppressed_signals=suppressed,ml=ml,
                fingerprint=hashlib.sha256(text.encode('utf-8')).hexdigest(),
                analysis_ms=round((time.perf_counter()-started)*1000,2),
                decision={'method':'weighted_rules_v1','evasion_shield':bool(shield),'review_threshold':25,'high_threshold':55,
                    'uncapped_score':sum(weights.values()),'weights':weights,'is_probability':False,
                    'ml_affects_score':False,'network_requests_local':0},
                limitations=['HEURISTIC_NOT_PROBABILITY','NO_SENDER_VERIFICATION','NO_URL_FETCH','NO_GUARANTEE'])
