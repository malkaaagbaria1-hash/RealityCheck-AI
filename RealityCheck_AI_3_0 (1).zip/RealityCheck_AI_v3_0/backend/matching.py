"""Bounded, deterministic normalization and contextual negation. No remote execution."""
from __future__ import annotations
import re
import unicodedata

REMOVE = re.compile(r'[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7\u0640\u200b-\u200d\ufeff]')
MAP = str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ٱ':'ا','ى':'ي','’':"'",'‘':"'"})
NEGATED = re.compile(
    r"(?:\b(?:never|do not|don't|not to|avoid|not|will not|won't|must not)\s+(?:ever\s+|please\s+)?)$"
    r"|(?:(?<!\w)(?:لا|ولا|ما|اياك ان|اياك|ممنوع|ليس عليك ان|لازم ما|لا تقم ب|لا تقومي ب|يرجي عدم|عدم)\s+)$"
    r"|(?:(?<![\u0590-\u05ff])(?:אל|לא|אין|אין צורך|לעולם אל|אסור)\s+)$", re.I)
WARNING = re.compile(
    r'\b(?:beware of|watch out for|warning about|example of|scam example|never (?:ask|request))\b'
    r'|(?:احذر من|احذروا من|مثال (?:عن|علي)|رسالة احتيال|لن نطلب|لن يطلب|لا نطلب|لا يطلب)'
    r'|(?:היזהרו מהודעות|דוגמה להונאה|לעולם לא נבקש)',re.I)


def matching_view(text: str) -> tuple[str, list[int]]:
    """Return normalized text and original character offsets for inspectable evidence."""
    chars, positions = [], []
    for i, ch in enumerate(text):
        part = REMOVE.sub('', unicodedata.normalize('NFKC', ch)).translate(MAP)
        for c in part:
            chars.append(c); positions.append(i)
    return ''.join(chars), positions


def suppression_reason(content: str, start: int, code: str) -> str | None:
    if code not in {'credentials','payment','remote_access','secrecy','unusual_payment'}:
        return None
    before = re.split(r'[.!?\n؛]', content[max(0,start-110):start])[-1]
    if NEGATED.search(before):
        return 'negated_request'
    if WARNING.search(before):
        return 'warning_context'
    return None


# ---------------------------------------------------------------------------
# 3.0 Evasion Shield: a second, bounded normalization pass used only for rule
# matching. It targets obfuscations measured in the Red Team Arena (homoglyphs,
# leetspeak, invisible characters, intra-word separators, spaced letters and
# Arabic-Indic digits). Every output character keeps its original offset so the
# evidence shown to the reviewer is still the user's original text.
# The same algorithm is implemented in frontend/src/engine.js (parity-tested).
# ---------------------------------------------------------------------------
SHIELD_DROP = set('­͏؜ᅟᅠ឴឵᠎‎‏⁠⁡⁢⁣⁤ㅤﾠ') | {chr(c) for c in range(0xfe00,0xfe10)}
CONFUSABLES = {
    # Cyrillic
    'а':'a','е':'e','о':'o','р':'p','с':'c','х':'x','у':'y','і':'i','ј':'j','ѕ':'s','ԁ':'d','ӏ':'l','һ':'h','ԛ':'q','ԝ':'w','ո':'n',
    'А':'a','В':'b','Е':'e','К':'k','М':'m','Н':'h','О':'o','Р':'p','С':'c','Т':'t','Х':'x','У':'y','І':'i',
    # Persian/Urdu letter forms that look like Arabic ones
    'ک':'ك','ڪ':'ك','ی':'ي','ې':'ي','ہ':'ه','ە':'ه','ۀ':'ه',
    # Greek
    'α':'a','ε':'e','ο':'o','ρ':'p','τ':'t','ν':'v','κ':'k','ι':'i','υ':'u','χ':'x','Α':'a','Β':'b','Ε':'e','Η':'h','Ι':'i','Κ':'k','Μ':'m','Ν':'n','Ο':'o','Ρ':'p','Τ':'t','Χ':'x','Υ':'y','Ζ':'z',
}
DIGITS = {**{chr(0x660+i):str(i) for i in range(10)},**{chr(0x6f0+i):str(i) for i in range(10)}}
LEET = {'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s'}
JOINERS = set('-*·•|_~^+')
SPACERS = set(' .')


def _latin(c: str) -> bool:
    return ('a'<=c<='z') or ('A'<=c<='Z')


def _letter(c: str) -> bool:
    return c.isalpha()


def shield_view(text: str, offsets: list[int]) -> tuple[str, list[int]]:
    """Return a hardened matching view and per-character original offsets."""
    items=[]
    for c,p in zip(text,offsets):
        if c in SHIELD_DROP: continue
        c=CONFUSABLES.get(c,DIGITS.get(c,c))
        items.append([c,p])
    # Leetspeak only inside mostly-Latin tokens (keeps '24 hours' and codes intact).
    i,n=0,len(items)
    while i<n:
        if _latin(items[i][0]) or items[i][0].isdigit() or items[i][0] in '@$':
            j=i
            while j<n and (_latin(items[j][0]) or items[j][0].isdigit() or items[j][0] in '@$' or items[j][0] in JOINERS): j+=1
            token=[items[k][0] for k in range(i,j)]
            letters=sum(_latin(c) for c in token); leet=sum(c in LEET for c in token)
            if letters>=2 and leet and leet<=letters*2:
                for k in range(i,j):
                    items[k][0]=LEET.get(items[k][0],items[k][0])
            i=max(j,i+1)
        else: i+=1
    # Drop joiners and symbols/emoji sandwiched between letters: pass-word, pass🔑word.
    out=[]
    for k,(c,p) in enumerate(items):
        if (c in JOINERS or unicodedata.category(c)=='So') and out and _letter(out[-1][0]):
            nxt=next((items[m][0] for m in range(k+1,len(items)) if not (items[m][0] in JOINERS or unicodedata.category(items[m][0])=='So')),'')
            if _letter(nxt): continue
        out.append([c,p])
    # Collapse runs of >=4 single letters separated by spaces/dots: p a s s w o r d.
    items,out,i,n=out,[],0,len(out)
    while i<n:
        c=items[i][0]
        if _letter(c) and (i==0 or not _letter(items[i-1][0])) and (i+1>=n or not _letter(items[i+1][0])):
            run=[i]; j=i+1
            while True:
                k=j; seps=0
                while k<n and items[k][0] in SPACERS and seps<2: k+=1; seps+=1
                if not seps or k>=n or not _letter(items[k][0]) or (k+1<n and _letter(items[k+1][0])): break
                run.append(k); j=k+1
            if len(run)>=4:
                out.extend(items[r] for r in run); i=j; continue
        out.append(items[i]); i+=1
    return ''.join(c for c,_ in out),[p for _,p in out]


# ---------------------------------------------------------------------------
# 3.0.1 Built-in identity hints: recognise a claimed organization without the
# user typing an expected domain. Mirrors frontend/src/engine.js claimedEntity.
# ---------------------------------------------------------------------------
def cue_pattern(cue: str) -> str:
    c = matching_view(cue)[0].lower()
    body = re.escape(c)
    if re.search(r'[֐-׿]', c):
        return r'(?<![֐-׿])[והבלמשכ]{0,2}' + body + r'(?![֐-׿])'
    if re.search(r'[؀-ۿ]', c):
        return r'(?<![؀-ۿ])(?:[وفب]?ال|لل|[وفبلك]{0,2})' + body + r'(?![؀-ۿ])'
    return r'(?<![a-z0-9])' + body + r'(?![a-z0-9])'
