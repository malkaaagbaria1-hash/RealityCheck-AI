"""Local API for bounded campaign analysis, explicit snapshot saving and review."""
from __future__ import annotations
import json
import threading
import time
from collections import OrderedDict
from pathlib import Path
from fastapi import HTTPException
from fastapi.responses import HTMLResponse
from .analyzer import ROOT
from .campaign_models import CampaignRequest, CampaignImport, CampaignSave, CampaignReview
from .campaigns import analyze_campaign, parse_import
from .campaign_store import CampaignStore, RevisionConflict
from .campaign_exports import report_html

def attach_campaign_routes(app, db_path):
    store = CampaignStore(db_path)
    recent = OrderedDict()
    lock = threading.Lock()
    app.state.campaign_store = store
    app.state.campaign_recent = recent

    def remember(report):
        now = time.monotonic()
        with lock:
            for key, (stamp, _) in list(recent.items()):
                if now - stamp > 1800:
                    recent.pop(key, None)
            recent[report['id']] = (now, report)
            while len(recent) > 4:
                recent.popitem(last=False)

    def get_report(run_id):
        saved = store.get(run_id)
        if saved:
            return saved
        with lock:
            entry = recent.get(run_id)
            if entry and time.monotonic() - entry[0] <= 1800:
                return entry[1]
            recent.pop(run_id, None)
        raise HTTPException(404, 'RUN_EXPIRED_ANALYZE_AGAIN')

    @app.post('/api/intelligence/import')
    def import_batch(payload: CampaignImport):
        try:
            return parse_import(payload)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post('/api/intelligence/analyze')
    def correlate(payload: CampaignRequest):
        result = analyze_campaign(payload)
        remember(result)
        return result

    @app.get('/api/intelligence/demo')
    def demo():
        return json.loads((ROOT/'shared/campaign_demo.json').read_text(encoding='utf-8'))

    @app.get('/api/intelligence/evaluation')
    def evaluation():
        path = ROOT/'evaluation/campaign_results.json'
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'status':'not_run'}

    @app.get('/api/intelligence/runs')
    def runs():
        return {'runs':store.list(), 'limit':50}

    @app.post('/api/intelligence/runs')
    def save(payload: CampaignSave):
        try:
            report = store.save(get_report(payload.run_id))
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        with lock:
            recent.pop(payload.run_id, None)
        return report

    @app.get('/api/intelligence/runs/{run_id}')
    def load(run_id: str):
        return get_report(run_id)

    @app.delete('/api/intelligence/runs/{run_id}')
    def delete(run_id: str):
        with lock:
            recent.pop(run_id, None)
        deleted = store.delete(run_id)
        return {'deleted':deleted}

    @app.post('/api/intelligence/runs/{run_id}/review')
    def review(run_id: str, payload: CampaignReview):
        try:
            return store.review(run_id, payload)
        except RevisionConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(404, str(exc.args[0])) from exc
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get('/api/intelligence/runs/{run_id}/export')
    def export(run_id: str):
        # JSON is already masked; no raw texts or API keys are retained in the result.
        return get_report(run_id)

    @app.get('/api/intelligence/runs/{run_id}/report')
    def html_export(run_id: str):
        report = get_report(run_id)
        return HTMLResponse(report_html(report), headers={'Content-Disposition':f'attachment; filename="{report["id"]}_report.html"'})
