"""Single-user, local SQLite storage. Reports are saved only after explicit consent."""
import json, sqlite3
from pathlib import Path

class CaseStore:
    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS cases (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, report TEXT NOT NULL)')
    def connect(self):
        conn=sqlite3.connect(self.path)
        conn.execute('PRAGMA secure_delete=ON')
        return conn
    def save(self,report):
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO cases VALUES (?,?,?)',(report['id'],report['created_at'],json.dumps(report,ensure_ascii=False)))
    def list(self):
        with self.connect() as db:
            rows=db.execute('SELECT report FROM cases ORDER BY created_at DESC LIMIT 200').fetchall()
        return [json.loads(row[0]) for row in rows]
    def get(self,case_id):
        with self.connect() as db: row=db.execute('SELECT report FROM cases WHERE id=?',(case_id,)).fetchone()
        return json.loads(row[0]) if row else None
    def delete(self,case_id=None):
        with self.connect() as db:
            if case_id: db.execute('DELETE FROM cases WHERE id=?',(case_id,))
            else: db.execute('DELETE FROM cases')
        # Logical deletion is not a guarantee of physical erasure from backups / SSDs.
