"""Inert, escaped HTML exports; no scripts, external images, links or raw messages."""
from html import escape

def report_html(report):
    esc = lambda value: escape(str(value), quote=True)
    lang = report['language']
    direction = 'ltr' if lang == 'en' else 'rtl'
    labels = {
      'ar': {'title':'تقرير ربط الحالات','notice':'مجموعات مرشّحة للتحقيق، وليست حملات مؤكدة. التشابه لا يثبت أن المرسل واحد.','privacy':'النصوص محجوبة جزئيًا؛ راجعها قبل مشاركة التقرير. الحجب لا يضمن إخفاء كل البيانات الشخصية.','groups':'المجموعات','records':'الرسائل','domains':'النطاقات','strength':'قوة الربط الدنيا','review':'مراجعة بشرية','note':'ملاحظة','evidence':'أسباب الربط','none':'غير متاح'},
      'he': {'title':'דוח קשרים בין מקרים','notice':'קבוצות מועמדות לבדיקה, לא קמפיינים מאומתים. דמיון אינו מוכיח שולח משותף.','privacy':'בוצע מיסוך חלקי בלבד. יש לבדוק לפני שיתוף; המיסוך אינו מבטיח אנונימיות.','groups':'קבוצות','records':'הודעות','domains':'דומיינים','strength':'עוצמת קשר מינימלית','review':'סקירה אנושית','note':'הערה','evidence':'סיבות לקשר','none':'לא זמין'},
      'en': {'title':'Case correlation report','notice':'Candidate groups, not confirmed campaigns. Similarity does not establish a shared sender.','privacy':'Best-effort masking only. Review before sharing; personal information may remain.','groups':'Groups','records':'Messages','domains':'Domains','strength':'Minimum link strength','review':'Human review','note':'Note','evidence':'Link evidence','none':'Unavailable'}
    }[lang]
    records = {r['id']:r for r in report['records']}
    group_html = []
    for group in report['groups']:
        body = f"<h2>{esc(group['id'])} · {group['size']} {labels['records']}</h2>"
        body += f"<p>{labels['review']}: <b>{esc(group['review']['status'])}</b> · {labels['strength']}: {group['min_link_strength']:.2f}</p>"
        if group['review']['note']:
            body += f"<p>{labels['note']}: {esc(group['review']['note'])}</p>"
        body += '<p>' + labels['domains'] + ': ' + ', '.join(esc(x['domain']) for x in group['domain_counts']) + '</p>'
        for record_id in group['members']:
            record = records[record_id]
            body += f"<article><h3>{esc(record_id)} · {record['score']}/100</h3><blockquote dir='auto'>{esc(record['preview'])}</blockquote>"
            body += '<ul>' + ''.join(f"<li>{esc(s['title'])}: {esc(s['evidence'])}</li>" for s in record['signals']) + '</ul></article>'
        ids = set(group['members'])
        links = [link for link in report['links'] if link['source'] in ids and link['target'] in ids]
        body += '<details><summary>' + labels['evidence'] + f' ({len(links)})</summary>'
        for link in links:
            body += '<p dir="ltr">' + esc(link['source']) + ' ↔ ' + esc(link['target']) + ': '
            body += '; '.join(esc(reason['code']) + (' ' + ', '.join(esc(v) for v in reason.get('values',[])) if reason.get('values') else '') for reason in link['reasons']) + '</p>'
        group_html.append('<section>' + body + '</details></section>')
    singles = [r for r in report['records'] if not r['group_id']]
    single_html = '<section><h2>Ungrouped / לא מקובץ / غير مجمّع</h2>' + ''.join(f"<p><b>{esc(r['id'])}</b> · {r['score']}/100</p><blockquote dir='auto'>{esc(r['preview'])}</blockquote>" for r in singles) + '</section>'
    return f'''<!doctype html><html lang="{lang}" dir="{direction}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src 'none'; base-uri 'none'; form-action 'none'"><title>RealityCheck 2.0 · {esc(report['title'])}</title><style>
body{{font:16px/1.8 system-ui,sans-serif;max-width:1000px;padding:36px;margin:auto;color:#172c3b}}header{{border-bottom:3px solid #12765e;padding-bottom:24px}}h1,h2,h3{{line-height:1.4}}small{{color:#486071}}section{{border:1px solid #c5d4db;border-radius:12px;padding:22px;margin:24px 0;break-inside:avoid}}blockquote{{background:#f1f5f7;margin:12px 0;padding:14px;white-space:pre-wrap;overflow-wrap:anywhere}}p,li{{overflow-wrap:anywhere}}.notice{{background:#fff4da;padding:16px}}code{{word-break:break-all;font-size:12px}}article{{border-top:1px solid #dce5ea}}@media print{{body{{padding:0;font-size:11px}}details{{display:block}}}}
</style></head><body><header><small>REALITYCHECK AI / CAMPAIGN INTELLIGENCE 2.0</small><h1>{esc(report['title'])}</h1><h2>{labels['title']}</h2><p dir="ltr">{esc(report['id'])} · {esc(report['created_at'])}</p></header><p class="notice">{labels['notice']}</p><p>{labels['privacy']}</p><p>{labels['records']}: {report['summary']['records']} · {labels['groups']}: {report['summary']['candidate_groups']} · {labels['domains']}: {report['summary']['domain_count']}</p>{''.join(group_html)}{single_html}<section><h2>Method / שיטה / المنهج</h2><p>{esc(report['engine_version'])} · TF-IDF + exact indicators + complete-link grouping</p><p>Threshold {report['config']['threshold']} · No URL visits · No sender verification · Local-only · No real-world accuracy claim.</p><p>Scores and link strengths are heuristic indices, not probabilities. Changes in human review do not change the automated evidence.</p><code>Snapshot SHA-256: {esc(report.get('snapshot_sha256','Unsaved snapshot — no stored hash'))}</code></section></body></html>'''
