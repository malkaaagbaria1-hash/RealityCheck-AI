"""Small learned multilingual Naive Bayes baseline. Synthetic corpus only.
Output is advisory, never a fraud probability, never part of the rule score.
No numerical / binary ML dependency; the frozen JSON weights can be audited.
"""
from __future__ import annotations
from collections import Counter
from functools import lru_cache
from pathlib import Path
import json, math, re
from .matching import matching_view
MODEL_PATH=Path(__file__).resolve().parents[1]/'ml/model.json'


def features(text: str) -> Counter:
    normalized,_=matching_view(text.lower())
    normalized=re.sub(r'https?://\S+',' urltoken ',normalized)
    normalized=re.sub(r'\d+',' numtoken ',normalized)
    words=re.findall(r'[^\W\d_]+',normalized,re.UNICODE)
    found=Counter('w:'+w for w in words)
    found.update('b:'+a+' '+b for a,b in zip(words,words[1:]))
    for w in words:
        if len(w)>=4:
            padded='^'+w+'$'
            found.update('c:'+padded[i:i+3] for i in range(len(padded)-2))
    return found


def train(rows: list[dict]) -> dict:
    counts={k:Counter() for k in ('ordinary','caution')}; docs=Counter()
    for row in rows:
        counts[row['label']].update(features(row['text'])); docs[row['label']]+=1
    vocab=sorted(set(counts['ordinary'])|set(counts['caution']))
    size=len(vocab); totals={k:sum(c.values()) for k,c in counts.items()}
    weights={w:round(math.log((counts['caution'][w]+1)/(totals['caution']+size))-
               math.log((counts['ordinary'][w]+1)/(totals['ordinary']+size)),9) for w in vocab}
    return {'version':'synthetic-nb-1','algorithm':'multinomial_naive_bayes','source':'authored_synthetic',
            'languages':['ar','he','en'],'training_rows':len(rows),'training_families':len({r['family'] for r in rows}),
            'prior_log_odds':math.log(docs['caution']/docs['ordinary']),'weights':weights,
            'abstain_margin':1.5,'minimum_coverage':0.18,'minimum_known_features':6,
            'rule_score_impact':0,'real_world_validated':False}


@lru_cache(maxsize=1)
def load_model() -> dict | None:
    try:
        return json.loads(MODEL_PATH.read_text(encoding='utf-8'))
    except (OSError,ValueError):
        return None


def predict(text: str,model: dict | None=None) -> dict:
    model=model or load_model()
    if not model:return {'status':'unavailable','label':None,'top_features':[],'reason':'model_missing'}
    counts=features(text); known={f:n for f,n in counts.items() if f in model['weights']}
    coverage=sum(known.values())/max(1,sum(counts.values()))
    margin=model['prior_log_odds']+sum(n*model['weights'][f] for f,n in known.items())
    reason='low_coverage' if coverage<model['minimum_coverage'] or len(known)<model['minimum_known_features'] else 'close_margin' if abs(margin)<model['abstain_margin'] else None
    top=sorted([(f,n*model['weights'][f]) for f,n in known.items() if f.startswith(('w:','b:'))],key=lambda p:abs(p[1]),reverse=True)[:6]
    return {'status':'abstained' if reason else 'completed','reason':reason,
            'label':None if reason else 'caution_pattern' if margin>0 else 'ordinary_pattern',
            'raw_margin':round(margin,3),'coverage':round(coverage,3),
            'top_features':[{'feature':f[2:],'contribution':round(v,3)} for f,v in top],
            'model_version':model['version'],'source':model['source'],'training_rows':model['training_rows'],
            'is_probability':False,'affects_rule_score':False,'real_world_validated':False}
