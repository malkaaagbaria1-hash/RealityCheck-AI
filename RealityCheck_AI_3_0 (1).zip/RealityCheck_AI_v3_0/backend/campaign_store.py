"""Explicit-save SQLite snapshots and an unauthenticated local change history.

This is not an enterprise audit trail: the machine's owner can modify the DB.
No filesystem path or SQL identifiers are accepted from a request.
"""
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from .campaigns import redact

class RevisionConflict(ValueError):
    pass

class CampaignStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS campaign_runs (
                id TEXT PRIMARY KEY, created_at TEXT NOT NULL, title TEXT NOT NULL,
                revision INTEGER NOT NULL, report TEXT NOT NULL)''')

    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.execute('PRAGMA secure_delete=ON')
        return db

    @staticmethod
    def fingerprint(report):
        source = {key:value for key,value in report.items() if key != 'snapshot_sha256'}
        report['snapshot_sha256'] = hashlib.sha256(json.dumps(source, sort_keys=True, ensure_ascii=False,
                                                              separators=(',',':')).encode()).hexdigest()
        return report

    def save(self, report):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT report FROM campaign_runs WHERE id=?',(report['id'],)).fetchone()
            if old:
                return json.loads(old[0])
            if db.execute('SELECT COUNT(*) FROM campaign_runs').fetchone()[0] >= 50:
                raise ValueError('SAVED_RUN_LIMIT_50')
            saved = json.loads(json.dumps(report))
            saved['saved'] = True
            saved['revision'] = 1
            saved['events'] = [{'time':datetime.now(timezone.utc).isoformat(), 'action':'saved',
                                'note':'Redacted snapshot saved by the local user'}]
            self.fingerprint(saved)
            db.execute('INSERT INTO campaign_runs VALUES (?,?,?,?,?)',
                       (saved['id'],saved['created_at'],saved['title'],1,json.dumps(saved,ensure_ascii=False)))
        return saved

    def list(self):
        with self.connect() as db:
            rows = db.execute('SELECT report FROM campaign_runs ORDER BY created_at DESC LIMIT 50').fetchall()
        reports = [json.loads(row[0]) for row in rows]
        return [{key:report[key] for key in ('id','created_at','title','revision','summary','config')} |
                {'reviewed_groups':sum(g['review']['status'] != 'open' for g in report['groups'])}
                for report in reports]

    def get(self, run_id):
        with self.connect() as db:
            row = db.execute('SELECT report FROM campaign_runs WHERE id=?',(run_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def review(self, run_id, change):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT revision,report FROM campaign_runs WHERE id=?',(run_id,)).fetchone()
            if not row:
                raise KeyError('RUN_NOT_FOUND')
            if row[0] != change.revision:
                raise RevisionConflict('REVISION_CONFLICT_REOPEN')
            report = json.loads(row[1])
            group = next((g for g in report['groups'] if g['id'] == change.group_id), None)
            if group is None:
                raise KeyError('GROUP_NOT_FOUND')
            before = group['review']['status']
            group['review'] = {'status':change.status, 'note':redact(change.note,max_length=1200)}
            report['revision'] += 1
            if len(report['events']) >= 200:
                raise ValueError('REVIEW_EVENT_LIMIT_200')
            report['events'].append({'time':datetime.now(timezone.utc).isoformat(),'action':'reviewed',
                                    'group_id':change.group_id, 'from_status':before, 'to_status':change.status,
                                    'note':group['review']['note']})
            self.fingerprint(report)
            db.execute('UPDATE campaign_runs SET revision=?,report=? WHERE id=?',
                       (report['revision'], json.dumps(report,ensure_ascii=False),run_id))
        return report

    def delete(self, run_id):
        with self.connect() as db:
            return bool(db.execute('DELETE FROM campaign_runs WHERE id=?',(run_id,)).rowcount)
