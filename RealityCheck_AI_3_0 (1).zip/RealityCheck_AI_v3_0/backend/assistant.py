"""Evidence-bound local Q&A. Deliberately a template/retrieval assistant, not an LLM.
It cannot browse, change a verdict, open a link, or execute instructions in a message.
"""
from __future__ import annotations
import re
from .matching import matching_view

TEXT={
'ar':{
'why':'نتيجة القواعد {score}/100، وهي مؤشر اشتباه وليست نسبة احتيال. الأدلة المسجلة:',
'none':'لم تظهر أدلة من القواعد الحالية. هذا لا يثبت أن المحتوى آمن؛ قد يكون خارج تغطيتها.',
'next':'لا ترسل كلمة سر أو رمز تحقق ردًا على الرسالة. تحقق من الطلب عبر التطبيق المعتاد أو جهة تعرفها بشكل مستقل، لا عبر بيانات التواصل الواردة في الرسالة. لا تفتح الروابط لمجرد أن النتيجة منخفضة.',
'url':'المضيف الحقيقي المستخرج هو: {hosts}. لم نفتح الموقع أو نفحص محتواه. المقارنة بالنطاق المتوقع تعتمد على النطاق الذي أدخلته أنت، وليست إثبات هوية.',
'no_url':'لم يُستخرج رابط صالح. غياب الروابط لا ينفي وجود محاولة احتيال.',
'model':'النموذج المحلي Naive Bayes متعلّم من 240 رسالة مصطنعة بثلاث لغات. هو تجربة تعليمية، وليس نموذج لغة كبيرًا ولا نظامًا مثبت الدقة على احتيال حقيقي. نتيجته منفصلة ولا تغيّر درجة القواعد. الشرح السحابي يحتاج تفعيلًا وموافقة.',
'privacy':'التحليل المحلي لا يرسل الرسالة لخدمة خارجية. الحفظ في SQLite اختياري؛ تقارير الجلسة تبقى في ذاكرة مؤقتة محدودة. تشغيل الخدمات الخارجية يتطلب اختيارًا صريحًا، وقد تبقى بيانات لدى مقدم الخدمة. ملفات التصدير تحتوي نص الرسالة.',
'score':'الدرجة تجمع أوزان المؤشرات مرة واحدة لكل نوع، ثم تُحَد إلى 100. أقل من 25: أدلة محدودة؛ من 25: يحتاج مراجعة؛ من 55: اشتباه مرتفع. الأوزان تصميمية وليست احتمالات مقاسة.',
'limits':'لا نتحقق من هوية المرسل أو ملكية النطاق، ولا نزور الروابط. القواعد قد تخطئ، والنموذج متدرّب على بيانات مصطنعة. لا يوجد ضمان أمان أو حكم قطعي بالاحتيال.',
'fallback':'أقدر أشرح أدلة هذا الملف، الدرجة، الروابط، الخطوة التالية، الخصوصية أو النموذج. اسأل مثلًا: لماذا النتيجة مرتفعة؟ هذا مساعد محلي بقوالب، وليس محادثة توليدية عامة.'},
'he':{
'why':'ציון הכללים הוא {score}/100: מדד חשד ולא הסתברות להונאה. הראיות בתיק:',
'none':'לא נמצאו ראיות במסגרת הכללים הנוכחיים. זה אינו מוכיח שההודעה בטוחה.',
'next':'אין לשלוח סיסמה או קוד בתגובה להודעה. יש לבדוק דרך האפליקציה המוכרת או איש קשר שאומת באופן עצמאי, לא דרך פרטים מההודעה. ציון נמוך אינו אישור לפתוח קישור.',
'url':'המארח האמיתי שחולץ: {hosts}. האתר לא נפתח ותוכנו לא נבדק. הדומיין להשוואה הוזן בידי המשתמש ואינו מקור מאומת לזהות.',
'no_url':'לא חולץ קישור תקין. היעדר קישורים אינו שולל הונאה.',
'model':'המודל המקומי הוא Naive Bayes שנלמד מ-240 הודעות סינתטיות בשלוש שפות. זהו ניסוי לימודי, לא מודל שפה גדול ולא גלאי שתוקף על הונאות אמת. תוצאתו נפרדת ואינה משנה את ציון הכללים. הסבר ענן דורש הגדרה והסכמה.',
'privacy':'הניתוח המקומי אינו שולח את ההודעה לשירות חיצוני. שמירה ב-SQLite היא לפי בחירה; דוחות זמניים מוחזקים במטמון מוגבל. שירות חיצוני דורש בחירה מפורשת ועשוי לשמור נתונים. קובצי יצוא כוללים את ההודעה.',
'score':'משקל כל סוג סימן נספר פעם אחת והסכום מוגבל ל-100. מתחת ל-25: ראיות מוגבלות; מ-25: בדיקה; מ-55: חשד גבוה. המשקלים הם החלטות תכנון, לא הסתברויות מדודות.',
'limits':'אין אימות זהות שולח או בעלות דומיין ואין ביקור בקישורים. כללים עלולים לטעות והמודל נלמד מנתונים סינתטיים. אין הבטחת בטיחות או קביעה מוחלטת של הונאה.',
'fallback':'אפשר לשאול על הראיות, הציון, הקישורים, הפעולה הבאה, הפרטיות או המודל. זהו עוזר מקומי מבוסס תבניות, לא צ׳אט גנרטיבי כללי.'},
'en':{
'why':'The rule score is {score}/100: a suspicion index, not a fraud probability. Recorded evidence:',
'none':'No evidence matched the present rules. That does not establish safety.',
'next':'Do not reply with passwords or verification codes. Verify through a familiar app or independently known contact, not contact details in the message. A low score is not permission to open a link.',
'url':'Extracted actual host: {hosts}. The site was not visited or its content inspected. The expected hostname was provided by you and is not verified identity.',
'no_url':'No valid URL was extracted. A message can be fraudulent without a URL.',
'model':'The local Naive Bayes model was trained on 240 synthetic messages in three languages. It is an educational experiment, not an LLM or a real-world validated fraud detector. Its output does not change the rule score. Cloud explanations require configuration and consent.',
'privacy':'Local analysis does not send messages to another service. SQLite saving is opt-in; temporary reports live in a bounded cache. External services require explicit selection and may retain data. Exports include the message text.',
'score':'Each signal type is counted once and the sum is capped at 100. Below 25: limited evidence; from 25: review; from 55: high suspicion. Weights are design choices, not measured probabilities.',
'limits':'Sender identity and domain ownership are not verified; URLs are not visited. Rules can err and the learned model uses synthetic data. There is no safety guarantee or definitive fraud judgment.',
'fallback':'Ask about this case’s evidence, score, links, next steps, privacy or model. This local assistant uses templates; it is not an open-ended generative chatbot.'}}
PATTERNS=[
 ('privacy',r'خصوص|بياناتي|حفظ|privacy|data|store|פרטיות|נתונים|שמירה'),
 ('model',r'نموذج|ذكاء|تعلم|model|\bai\b|train|מודל|בינה|למידה'),
 ('next',r'شو اعمل|ماذا افعل|خطو|كيف اتصرف|next|should i do|מה לעשות|מה עלי|הבא'),
 ('limits',r'مضمون|ضمان|اكيد|حدود|safe|guarantee|limit|בטוח|מגבל|ודאי'),
 ('url',r'رابط|روابط|نطاق|دومين|url|link|domain|קישור|דומיין'),
 ('score',r'كيف.*(?:درج|رقم)|كيف حسب|حساب الدرجة|calculate|weight|threshold|חישוב|משקל|סף'),
 ('why',r'ليش|لماذا|اشرح|سبب|دليل|ادلة|why|explain|evidence|למה|הסבר|ראי')]

def answer(report: dict,question: str,language: str='ar') -> dict:
    text,_=matching_view(question.lower())
    intent=next((i for i,p in PATTERNS if re.search(p,text,re.I)),'fallback')
    lang=TEXT[language]; evidence=report['signals']; refs=[]
    if intent=='why':
        active=[s for s in evidence if s['weight']]
        body=lang['why'].format(score=report['score'])+'\n'+'\n'.join(f"[{s.get('id','E?')}] {s['title']} (+{s['weight']}) — {s['detail']}" for s in active) if active else lang['none']
        refs=[s.get('id') for s in active if s.get('id')]
    elif intent=='url':body=lang['url'].format(hosts=', '.join(u['host'] for u in report['urls'])) if report['urls'] else lang['no_url']
    else:body=lang[intent]
    return {'answer':body,'references':refs,'intent':intent,'mode':'local_templates',
            'case_id':report['id'],'language':language,'external_request':False}
