"""Local single-user service. Do not expose publicly without authentication and hardening."""
from __future__ import annotations
import base64, io, os, time, json, logging, uuid
from collections import OrderedDict, defaultdict, deque
from pathlib import Path
from urllib.parse import urlsplit
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from PIL import Image, UnidentifiedImageError
from .analyzer import ROOT, VERSION, analyze
from .models import AnalyzeRequest, SaveRequest, ImageRequest, AssistantRequest, CompareRequest, NoteRequest
from .storage import CaseStore
from .integrations import Connectors
from .assistant import answer as local_answer
from .ml_model import load_model
load_dotenv(ROOT/'.env')

class BodyLimitMiddleware:
    """Cap streamed bodies as well as Content-Length; never trust that header alone."""
    def __init__(self,app,limit=6500000): self.app=app; self.limit=limit
    async def __call__(self,scope,receive,send):
        if scope['type']!='http': return await self.app(scope,receive,send)
        messages=[]; total=0
        while True:
            message=await receive()
            if message['type']=='http.disconnect': return
            total+=len(message.get('body',b''))
            if total>self.limit:
                return await JSONResponse({'detail':'REQUEST_TOO_LARGE'},status_code=413)(scope,receive,send)
            messages.append(message)
            if not message.get('more_body',False): break
        iterator=iter(messages)
        async def replay():
            try: return next(iterator)
            except StopIteration: return await receive()
        await self.app(scope,replay,send)


def create_app(db_path=None,testing=False,connectors=None):
    app=FastAPI(title='RealityCheck AI',version=VERSION,docs_url='/api/docs',redoc_url=None,openapi_url='/api/openapi.json')
    store=CaseStore(db_path or ROOT/'data/cases.sqlite3')
    services=connectors or Connectors(os.getenv('OPENAI_API_KEY',''),os.getenv('OPENAI_MODEL',''),os.getenv('VIRUSTOTAL_API_KEY',''))
    recent=OrderedDict(); rate=defaultdict(deque)
    app.state.store=store; app.state.connectors=services; app.state.recent=recent
    app.add_middleware(BodyLimitMiddleware)
    app.add_middleware(TrustedHostMiddleware,allowed_hosts=['localhost','127.0.0.1','testserver'] if testing else ['localhost','127.0.0.1'])

    @app.middleware('http')
    async def safety(request: Request,call_next):
        if request.url.path.startswith('/api/'):
            if request.headers.get('sec-fetch-site')=='cross-site':
                return JSONResponse({'detail':'CROSS_SITE_REQUEST_BLOCKED'},status_code=403)
            if request.method not in {'GET','HEAD','OPTIONS'}:
                if request.headers.get('x-realitycheck-client')!='web':
                    return JSONResponse({'detail':'CLIENT_HEADER_REQUIRED'},status_code=403)
                origin=request.headers.get('origin')
                if origin and origin!=f'{request.url.scheme}://{request.headers.get("host","")}':
                    return JSONResponse({'detail':'ORIGIN_NOT_ALLOWED'},status_code=403)
                if request.method=='POST' and not request.headers.get('content-type','').startswith('application/json'):
                    return JSONResponse({'detail':'JSON_REQUIRED'},status_code=415)
                if not testing:
                    key=request.client.host if request.client else 'local'; now=time.monotonic()
                    while rate[key] and now-rate[key][0]>60: rate[key].popleft()
                    if len(rate[key])>=30: return JSONResponse({'detail':'RATE_LIMITED'},status_code=429)
                    rate[key].append(now)
        response=await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='no-referrer'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
        response.headers['Cache-Control']='no-store'
        if not request.url.path.startswith('/api/docs'):
            response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
        return response

    @app.exception_handler(Exception)
    async def unexpected(request: Request,exc: Exception):
        incident=uuid.uuid4().hex[:10]
        logging.getLogger('realitycheck').error('Incident %s / %s / %s',incident,request.url.path,type(exc).__name__)
        return JSONResponse({'detail':'INTERNAL_ERROR','incident_id':incident},status_code=500)

    @app.get('/api/health')
    def health():
        return {'status':'ok','version':VERSION,'mode':'local_server','ai_configured':services.ai_ready,
                'reputation_configured':bool(services.vt_key),'storage':'sqlite_opt_in','public_deployment_ready':False,'local_ml':bool(load_model()),'assistant':'local_templates','release':'campaign_intelligence', 'campaign_engine':True}

    @app.post('/api/analyze')
    async def investigate(payload: AnalyzeRequest):
        try:
            report=analyze(payload.text,payload.input_type,payload.language,payload.expected_domain)
        except ValueError as exc: raise HTTPException(422,str(exc)) from exc
        report=await services.enrich(report,payload.use_ai,payload.use_reputation)
        now=time.monotonic()
        for key,entry in list(recent.items()):
            if now-entry[0]>900: recent.pop(key,None)
        recent[report['id']]=(now,report)
        while len(recent)>50: recent.popitem(last=False)
        return report

    @app.post('/api/cases')
    def save_case(payload: SaveRequest):
        entry=recent.get(payload.case_id)
        if not entry or time.monotonic()-entry[0]>900: raise HTTPException(404,'REPORT_EXPIRED_RUN_AGAIN')
        store.save(entry[1]); return {'saved':True,'id':payload.case_id}

    @app.get('/api/cases')
    def cases(): return {'cases':store.list()}

    def report_by_id(case_id):
        entry=recent.get(case_id)
        if entry and time.monotonic()-entry[0]<=900: return entry[1]
        recent.pop(case_id,None)
        report=store.get(case_id)
        if report is None: raise HTTPException(404,'REPORT_EXPIRED_RUN_AGAIN')
        return report

    @app.post('/api/assistant')
    async def assistant(payload: AssistantRequest):
        report=report_by_id(payload.case_id)
        result=local_answer(report,payload.question,payload.language)
        if payload.use_ai:
            if not payload.consent: raise HTTPException(422,'EXTERNAL_CONSENT_REQUIRED')
            if not services.ai_ready: raise HTTPException(503,'AI_NOT_CONFIGURED')
            status,text=await services.answer(report,payload.question,payload.language)
            if status=='completed':
                result.update(answer=text,mode='cloud_ai',external_request=True,references=[])
            else:
                result.update(mode='local_fallback',external_request=True,provider_status=status)
        return result

    @app.post('/api/compare')
    def compare(payload: CompareRequest):
        try:
            before=analyze(payload.before,language=payload.language,expected_domain=payload.expected_domain)
            after=analyze(payload.after,language=payload.language,expected_domain=payload.expected_domain)
        except ValueError as exc: raise HTTPException(422,str(exc)) from exc
        a={s['code'] for s in before['signals']}; b={s['code'] for s in after['signals']}
        return {'before':before,'after':after,'score_delta':after['score']-before['score'],
                'added':sorted(b-a),'removed':sorted(a-b),'network_requests':0,
                'warning':'A lower score is not evidence of safety.'}

    @app.get('/api/evaluation')
    def evaluation():
        path=ROOT/'evaluation/results.json'
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'status':'not_run'}

    @app.post('/api/self-check')
    def self_check():
        cases=[('credential_request','لازم تدخل كلمة المرور فورا',True),
               ('negative_request','لا ترسل كلمة المرور لأي شخص',False),
               ('english_request','Share your verification code immediately',True),
               ('hebrew_request','שלח קוד אימות מיד',True)]
        results=[]
        for name,text,want in cases:
            r=analyze(text)
            actual='credentials' in {s['code'] for s in r['signals']}
            results.append({'name':name,'passed':actual==want})
        return {'checks':results,'passed':all(x['passed'] for x in results),'scope':'smoke_only','version':VERSION}

    @app.post('/api/cases/{case_id}/note')
    def add_note(case_id: str,payload: NoteRequest):
        report=store.get(case_id)
        if report is None: raise HTTPException(404,'CASE_NOT_FOUND')
        report['analyst_note']=payload.note; report['review_status']=payload.status
        store.save(report)
        if case_id in recent: recent[case_id]=(time.monotonic(),report)
        return {'saved':True}

    @app.get('/api/cases/{case_id}')
    def case(case_id: str):
        report=store.get(case_id)
        if report is None: raise HTTPException(404,'CASE_NOT_FOUND')
        return report

    @app.delete('/api/cases/{case_id}')
    def delete_case(case_id: str):
        store.delete(case_id); recent.pop(case_id,None); return {'deleted':True}

    @app.delete('/api/cases')
    def delete_all():
        store.delete(); recent.clear(); return {'deleted':True}

    @app.post('/api/extract-image')
    async def extract_image(payload: ImageRequest):
        if not services.ai_ready: raise HTTPException(503,'AI_NOT_CONFIGURED')
        if not payload.data_url.startswith(('data:image/png;base64,','data:image/jpeg;base64,','data:image/webp;base64,')):
            raise HTTPException(422,'PNG_JPEG_WEBP_ONLY')
        try:
            raw=base64.b64decode(payload.data_url.split(',',1)[1],validate=True)
            if len(raw)>4_000_000: raise ValueError('Image too large')
            with Image.open(io.BytesIO(raw)) as im:
                if im.width*im.height>16_000_000: raise ValueError('Too many pixels')
                if im.format not in {'PNG','JPEG','WEBP'}: raise ValueError('Wrong image type')
                im.load(); im=im.convert('RGB'); im.thumbnail((2000,2000))
                out=io.BytesIO(); im.save(out,format='JPEG',quality=88)  # strips metadata
            clean='data:image/jpeg;base64,'+base64.b64encode(out.getvalue()).decode('ascii')
        except (ValueError,OSError,UnidentifiedImageError,Image.DecompressionBombError) as exc:
            raise HTTPException(422,'INVALID_IMAGE') from exc
        try: text=await services.extract_image(clean,payload.language)
        except ValueError as exc: raise HTTPException(502,str(exc)) from exc
        return {'text':text,'requires_review':True,'warning':'Verify the transcription against the image before analysis.'}

    from .campaign_api import attach_campaign_routes
    attach_campaign_routes(app, store.path)

    @app.get('/')
    def index(): return FileResponse(ROOT/'web/index.html')
    app.mount('/assets',StaticFiles(directory=ROOT/'web/assets',check_dir=False),name='assets')
    return app

app=create_app()
