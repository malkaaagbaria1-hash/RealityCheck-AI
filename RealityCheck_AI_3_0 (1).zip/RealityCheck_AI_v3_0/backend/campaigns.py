"""Offline campaign *candidate* correlation; no URL visits, remote lookups or attribution.

Graph edges are explainable heuristics, not calibrated probabilities. Complete-link
merging prevents one bridging message from joining otherwise unrelated clusters.
Raw messages never enter a campaign result or its optional persistent snapshot.
"""
from __future__ import annotations
import csv
import hashlib
import hmac
import io
import json
import math
import re
import secrets
import time
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime, timezone
from itertools import combinations
from urllib.parse import urlsplit, urlunsplit
from pydantic import ValidationError
from .analyzer import analyze, normalize_text, SHORTENERS, URL_PATTERN, find_urls
from .campaign_models import CampaignRequest, CampaignImport, CampaignRecord

ENGINE = 'campaign-correlation-2.0.0'
THRESHOLDS = {'balanced': .66, 'strict': .82}
# Exact-host matching only. We intentionally do not guess eTLD+1 / domain ownership.
GENERIC_HOSTS = SHORTENERS | {
    'google.com','www.google.com','docs.google.com','drive.google.com','forms.gle',
    'facebook.com','www.facebook.com','instagram.com','www.instagram.com',
    'youtube.com','youtu.be','wa.me','api.whatsapp.com','t.me','telegram.me',
    'linkedin.com','www.linkedin.com','x.com','twitter.com','microsoft.com',
    'login.microsoftonline.com','login.live.com','accounts.google.com',
    'github.com','github.io','linktr.ee','wix.com','wordpress.com','sites.google.com',
    'example.com','example.org','example.net'
}
EMAIL = re.compile(r'(?<![\w.+-])[\w.+-]+@[A-Za-z0-9][A-Za-z0-9.-]*\.[A-Za-z]{2,}(?![\w.-])', re.UNICODE)
PHONE = re.compile(r'(?<!\w)(?:\+?\d[\d ()-]{6,}\d)(?!\w)')
SECRETS = re.compile(r'(?i)((?:password|passcode|otp|token|secret|api[_ -]?key|קוד\s*אימות|סיסמה|كلمه\s*(?:السر|المرور)|كلمة\s*(?:السر|المرور)|رمز\s*التحقق)\s*[:=]\s*)([^\s,;]{3,})')
LONG_TOKEN = re.compile(r'\b[A-Za-z0-9_+/=-]{30,}\b')
AR_MARKS = re.compile(r'[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640\u200b-\u200f\u202a-\u202e\u2066-\u2069]')
WORD = re.compile(r'[^\W_]+', re.UNICODE)
RISK_CODES = {'credentials','payment','remote_access','secrecy','domain_mismatch','brand_domain_mismatch','unusual_payment'}
LANG_LABELS = {'ar': 'العربية', 'he': 'עברית', 'en': 'English', 'mixed': 'Mixed', 'other': 'Other'}


def host_allowed(host: str, domains: list[str]) -> bool:
    return any(host == domain or host.endswith('.' + domain) for domain in domains)


def normalized_message(text: str) -> str:
    text = AR_MARKS.sub('', unicodedata.normalize('NFKC', text).casefold())
    return text.translate(str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ى':'ي'}))


def safe_url_display(value: str) -> str:
    """Keep a hostname for investigation, strip credentials/path/query/fragment."""
    try:
        part = urlsplit(value if '://' in value else 'https://' + value)
        host = (part.hostname or '').encode('idna').decode('ascii')
        if not host:
            return '[URL]'
        return f'{part.scheme}://{host}/[…]'  # displayed as text, never a hyperlink
    except (ValueError, UnicodeError):
        return '[URL]'


def redact(text: str, *, max_length: int = 6000) -> str:
    """Best-effort masking, NOT de-identification. Names and free text may remain."""
    text = normalize_text(str(text))
    # Include bare-domain URLs such as example.org/reset?token=... too.
    for candidate in sorted(find_urls(text), key=len, reverse=True):
        text = text.replace(candidate, safe_url_display(candidate))
    text = URL_PATTERN.sub(lambda m: safe_url_display(m.group()), text)
    text = EMAIL.sub('[EMAIL]', text)
    text = PHONE.sub('[NUMBER]', text)
    text = SECRETS.sub(lambda m: m.group(1) + '[SECRET]', text)
    text = LONG_TOKEN.sub('[TOKEN]', text)
    # Mask even short standalone numeric codes, amounts and IDs in exported text.
    text = re.sub(r'(?<!\w)\d{3,}(?!\w)', '[NUMBER]', text)
    return text[:max_length]


def language_of(text: str) -> str:
    counts = {'ar': len(re.findall(r'[\u0600-\u06ff]', text)),
              'he': len(re.findall(r'[\u0590-\u05ff]', text)),
              'en': len(re.findall('[A-Za-z]', URL_PATTERN.sub(' ', text)))}
    ordered = sorted(counts, key=counts.get, reverse=True)
    if counts[ordered[0]] < 3:
        return 'other'
    if counts[ordered[1]] >= 8 and counts[ordered[1]] >= counts[ordered[0]] * .4:
        return 'mixed'
    return ordered[0]


def content_features(text: str) -> tuple[str, Counter]:
    text = URL_PATTERN.sub(' ', normalize_text(text))
    text = EMAIL.sub(' ', text)
    text = PHONE.sub(' ', text)
    text = normalized_message(text)
    text = re.sub(r'\d+', ' ', text)
    words = WORD.findall(text)[:700]
    # Bound the feature vocabulary even for hostile/repetitive input.
    terms = Counter({'w:' + word: min(3, n) for word, n in Counter(words).items() if len(word) > 1})
    for word in words:
        if len(word) >= 4:
            for i in range(min(len(word)-2, 36)):
                key = 'c:' + word[i:i+3]
                terms[key] = min(2, terms.get(key, 0)+1)
        if len(terms) > 1600:
            break
    terms = Counter(dict(list(terms.items())[:1800]))
    return ' '.join(words), terms


def vectors(features: list[Counter]) -> list[dict[str, float]]:
    df = Counter(term for row in features for term in row)
    n = len(features)
    output = []
    for row in features:
        raw = {term: (1 + math.log(count)) * (math.log((n+1)/(df[term]+1))+1) *
               (1.3 if term.startswith('w:') else .5) for term, count in row.items()}
        norm = math.sqrt(sum(value*value for value in raw.values())) or 1
        output.append({term: value/norm for term, value in raw.items()})
    return output


def cosine(a: dict, b: dict) -> float:
    if len(a) > len(b):
        a, b = b, a
    return min(1., max(0., sum(value*b.get(key, 0.) for key, value in a.items())))


def _secret_key(value: str, salt: bytes) -> str:
    return hmac.new(salt, value.encode('utf-8'), hashlib.sha256).hexdigest()


def _brand_mentioned(text: str, profile) -> bool:
    aliases = ([profile.name] if profile.name.strip() else []) + profile.aliases
    content = normalized_message(URL_PATTERN.sub(' ', text))
    return any(re.search(r'(?<!\w)' + re.escape(normalized_message(alias.strip())) + r'(?!\w)', content)
               for alias in aliases)


def _extract(record: CampaignRecord, request: CampaignRequest, salt: bytes) -> dict:
    report = analyze(record.text, language=request.language)
    profile = request.profile
    mentioned = _brand_mentioned(record.text, profile)
    urls = report['urls']
    hosts = sorted({u['host'] for u in urls if not u['is_private'] and not u['is_ip']})
    foreign = [host for host in hosts if profile.official_domains and not host_allowed(host, profile.official_domains)] if mentioned else []
    signals = [{key: value for key, value in signal.items() if key in {'id','code','weight','title','detail'}} |
               {'evidence': redact(signal['evidence'], max_length=300)} for signal in report['signals']]
    if foreign:
        labels = {'ar': ('اسم جهة مع نطاق خارج قائمتك', 'النطاق ليس ضمن القائمة التي أدخلتها. قد تكون خدمة طرف ثالث؛ يلزم تحقق بشري.'),
                  'he': ('שם מותג עם דומיין מחוץ לרשימה', 'הדומיין אינו ברשימה שהזנת. ייתכן ספק חיצוני; נדרשת בדיקה אנושית.'),
                  'en': ('Brand mention with an unlisted domain', 'Not in your supplied domain list. It may be a legitimate third party; human verification is required.')}
        title, detail = labels[request.language]
        signals.append({'id':f'E{len(signals)+1:02}', 'code':'brand_domain_mismatch', 'weight':28,
                        'title':title, 'detail':detail, 'evidence':', '.join(foreign)})
    score = min(100, sum({signal['code']: signal['weight'] for signal in signals}.values()))
    codes = {s['code'] for s in signals if s['weight'] > 0}
    correlate = bool(codes & RISK_CODES or {'urgency','threat'} <= codes) and score >= 25
    norm, features = content_features(record.text)
    contacts = set()
    for match in EMAIL.finditer(record.text):
        contacts.add(_secret_key('e:' + match.group().casefold(), salt))
    for match in PHONE.finditer(record.text):
        number = re.sub(r'\D', '', match.group())
        if 8 <= len(number) <= 15:
            contacts.add(_secret_key('n:' + number, salt))
    targets = set()
    for url in urls:
        if url['is_private'] or url['is_ip']:
            continue
        try:
            part = urlsplit(normalize_text(url['raw']) if '://' in normalize_text(url['raw']) else 'https://' + normalize_text(url['raw']))
            if part.path and part.path != '/':
                # Exact target equality includes query data; only a keyed digest survives.
                canonical = urlunsplit((part.scheme.lower(), url['host'], part.path, part.query, ''))
                targets.add(_secret_key(canonical, salt))
        except ValueError:
            pass
    info = dict(id=record.id, channel=record.channel, received_at=record.received_at,
                language=language_of(record.text), preview=redact(record.text), score=score,
                verdict='high' if score >= 55 else 'review' if score >= 25 else 'limited',
                signals=signals, domains=hosts, brand_mentioned=mentioned,
                unlisted_domains=foreign, suppressed_count=len(report['suppressed_signals']),
                correlation_eligible=correlate, invalid_urls=report['invalid_urls'],
                urls_truncated=report['urls_truncated'], synthetic_urls=any(u['demo'] for u in urls))
    return dict(public=info, features=features, normalized=norm,
                hosts=set(hosts)-GENERIC_HOSTS-{h for h in hosts if host_allowed(h, profile.official_domains)},
                contacts=contacts, targets=targets, codes=codes,
                exact=hashlib.sha256(normalize_text(record.text).strip().encode()).hexdigest(),
                eligible=correlate)


def pair_evidence(a: dict, b: dict, sim: float, threshold: float) -> dict | None:
    if not (a['eligible'] and b['eligible']):
        return None
    shared_hosts = sorted(a['hosts'] & b['hosts'])
    shared_codes = sorted((a['codes'] & b['codes']) & (RISK_CODES | {'urgency','threat'}))
    same_target = bool(a['targets'] & b['targets'])
    same_contact = bool(a['contacts'] & b['contacts'])
    exact = a['exact'] == b['exact']
    enough_text = min(len(a['normalized']), len(b['normalized'])) >= 45
    # Domain equality is not ownership or actor attribution. Generic hosts contribute zero.
    score = max(.58 if shared_hosts else 0, .62 if same_target else 0, .40 if same_contact else 0)
    score += .12 if shared_codes else 0
    score += .30 * sim
    if enough_text and sim >= .9:
        score = max(score, .72 + .25 * sim)
    if exact and enough_text:
        score = max(score, .99)
    independent_anchor = bool(shared_hosts or same_target or same_contact or (enough_text and sim >= .9))
    if not independent_anchor or score + 1e-9 < threshold:
        return None
    reasons = []
    if shared_hosts:
        reasons.append({'code':'shared_host','values':shared_hosts})
    if same_target:
        reasons.append({'code':'same_target','values':[]})
    if same_contact:
        reasons.append({'code':'shared_contact','values':[]})
    if shared_codes:
        reasons.append({'code':'shared_signals','values':shared_codes})
    if sim >= .45:
        reasons.append({'code':'text_similarity','value':round(sim, 3)})
    if exact:
        reasons.append({'code':'exact_duplicate','values':[]})
    return {'source':a['public']['id'], 'target':b['public']['id'],
            'anchor_rank':4 if exact else 3 if same_target else 2 if shared_hosts else 1 if same_contact else 0,
            'strength':round(min(1., score), 4), 'text_similarity':round(sim, 4), 'reasons':reasons}


def complete_link_groups(ids: list[str], edges: list[dict]) -> list[list[str]]:
    """Greedy deterministic clique merging, NOT connected components / actor attribution."""
    groups = {item: {item} for item in ids}
    owner = {item: item for item in ids}
    linked = {frozenset((edge['source'],edge['target'])) for edge in edges}
    for edge in sorted(edges, key=lambda x: (-x.get('anchor_rank',0), -x['strength'], x['source'], x['target'])):
        left, right = owner[edge['source']], owner[edge['target']]
        if left == right:
            continue
        aa, bb = groups[left], groups[right]
        if not all(frozenset((a,b)) in linked for a in aa for b in bb):
            continue
        keeper, removed = sorted((left,right))
        groups[keeper] |= groups.pop(removed)
        for item in groups[keeper]:
            owner[item] = keeper
    return sorted((sorted(group) for group in groups.values()), key=lambda row: (-len(row), row))


def analyze_campaign(request: CampaignRequest) -> dict:
    started = time.perf_counter()
    salt = secrets.token_bytes(32)
    rows = [_extract(record, request, salt) for record in sorted(request.records, key=lambda r:r.id)]
    embeddings = vectors([row['features'] for row in rows])
    threshold = THRESHOLDS[request.sensitivity]
    edges = []
    for i, j in combinations(range(len(rows)), 2):
        if not (rows[i]['eligible'] and rows[j]['eligible']):
            continue
        edge = pair_evidence(rows[i], rows[j], cosine(embeddings[i], embeddings[j]), threshold)
        if edge:
            edges.append(edge)
    public = [row['public'] for row in rows]
    by_id = {row['id']:row for row in public}
    groups, member_group = [], {}
    all_clusters = complete_link_groups([row['id'] for row in public], edges)
    for members in all_clusters:
        if len(members) < 2:
            continue
        group_id = 'G-' + hashlib.sha256('|'.join(members).encode()).hexdigest()[:10].upper()
        for member in members:
            member_group[member] = group_id
        records = [by_id[member] for member in members]
        member_set = set(members)
        links = [edge for edge in edges if edge['source'] in member_set and edge['target'] in member_set]
        counts = Counter(host for record in records for host in record['domains'])
        stamps = sorted(record['received_at'] for record in records if record['received_at'])
        top_signals = Counter(signal['code'] for record in records for signal in record['signals'] if signal['weight'] > 0)
        group = dict(id=group_id, members=members, size=len(members), max_score=max(r['score'] for r in records),
                     average_score=round(sum(r['score'] for r in records)/len(records),1),
                     domain_counts=[{'domain':host,'count':count} for host,count in counts.most_common()],
                     languages=sorted({r['language'] for r in records}),
                     channels=sorted({r['channel'] for r in records}),
                     first_seen=stamps[0] if stamps else None, last_seen=stamps[-1] if stamps else None,
                     dated_records=len(stamps), link_count=len(links),
                     min_link_strength=min(edge['strength'] for edge in links),
                     signal_counts=dict(top_signals.most_common()),
                     duplicate_pairs=sum(any(r['code']=='exact_duplicate' for r in e['reasons']) for e in links),
                     review={'status':'open','note':''})
        groups.append(group)
    groups.sort(key=lambda group:(-group['max_score'],-group['size'],group['id']))
    for record in public:
        record['group_id'] = member_group.get(record['id'])
    for edge in edges:
        edge['in_group'] = bool(member_group.get(edge['source']) and member_group.get(edge['source'])==member_group.get(edge['target']))
    timeline = Counter(r['received_at'][:10] for r in public if r['received_at'])
    domains = Counter(host for record in public for host in record['domains'])
    high = sum(row['score']>=55 for row in public)
    # Only redacted data survives; no secrets, token values, keyed contact hashes or raw text.
    return dict(id='R2-' + secrets.token_hex(6).upper(), schema_version=1, engine_version=ENGINE,
                app_version='3.0.0', created_at=datetime.now(timezone.utc).isoformat(),
                title=redact(request.title,max_length=100), language=request.language,
                config={'sensitivity':request.sensitivity,'threshold':threshold,'clustering':'complete_link_greedy',
                        'similarity':'bounded_word_and_character_tfidf_cosine', 'max_records':200},
                profile=request.profile.model_dump(), records=public, groups=groups, links=edges,
                timeline=[{'date':date,'count':count} for date,count in sorted(timeline.items())],
                domain_counts=[{'domain':domain,'count':count,'generic':domain in GENERIC_HOSTS,
                                'listed':host_allowed(domain,request.profile.official_domains)} for domain,count in domains.most_common()],
                summary={'records':len(public),'candidate_groups':len(groups),'grouped_records':len(member_group),
                         'ungrouped_records':len(public)-len(member_group),'high_priority_records':high,
                         'domain_count':len(domains),'languages':len({row['language'] for row in public}),
                         'unknown_dates':sum(not row['received_at'] for row in public),
                         'duplicates':len(rows)-len({row['exact'] for row in rows}),
                         'bridge_links_not_merged':sum(not edge['in_group'] for edge in edges)},
                privacy={'raw_messages_saved':False,'masking':'best_effort_not_anonymization',
                         'contacts':'per_run_keyed_comparison_not_returned','network_requests':0},
                analysis_ms=round((time.perf_counter()-started)*1000,2), revision=0, saved=False, events=[],
                limitations=['CANDIDATES_NOT_CONFIRMED_CAMPAIGNS','NO_ACTOR_ATTRIBUTION','HEURISTICS_NOT_PROBABILITIES',
                             'EXACT_HOST_NOT_DOMAIN_OWNERSHIP','GENERIC_HOST_LIST_INCOMPLETE','BEST_EFFORT_MASKING',
                             'CROSS_LANGUAGE_LINKS_NEED_SHARED_INDICATORS','UNRELATED_DOES_NOT_MEAN_SAFE',
                             'NO_BACKGROUND_MONITORING','NO_URL_VISITS','LOCAL_SINGLE_USER_ONLY'])


def parse_import(payload: CampaignImport) -> dict:
    content = payload.content.lstrip('\ufeff')
    warnings = []
    try:
        if payload.format == 'json':
            data = json.loads(content)
            if isinstance(data, dict) and set(data).issuperset({'records'}):
                data = data['records']
            if not isinstance(data, list):
                raise ValueError('JSON must be an array or an object containing records')
        elif payload.format == 'jsonl':
            data = [json.loads(line) for line in content.splitlines() if line.strip()]
        elif payload.format == 'lines':
            data = [{'text':line.strip()} for line in content.splitlines() if line.strip()]
        else:
            stream = io.StringIO(content, newline='')
            reader = csv.DictReader(stream)
            if not reader.fieldnames or 'text' not in reader.fieldnames:
                raise ValueError('CSV needs a text column; optional: id, channel, received_at')
            if len(reader.fieldnames) != len(set(reader.fieldnames)):
                raise ValueError('Duplicate CSV column names are not allowed')
            data = list(reader)
    except (json.JSONDecodeError, csv.Error, RecursionError) as exc:
        raise ValueError('Cannot parse file: use valid UTF-8 CSV/JSON/JSONL or one message per line') from exc
    if not 1 <= len(data) <= 200:
        raise ValueError('Import must contain 1–200 messages')
    records = []
    allowed = {'id','text','channel','received_at'}
    for index, value in enumerate(data, 1):
        if isinstance(value, str):
            value = {'text':value}
        if not isinstance(value, dict):
            raise ValueError(f'Row {index}: expected an object or text string')
        unknown = set(value) - allowed
        if unknown:
            warnings.append(f'Row {index}: ignored non-schema columns')
        row = {key:val for key,val in value.items() if key in allowed}
        if not row.get('id'):
            row['id'] = f'M{index:03}'
        if not row.get('channel'):
            row['channel'] = 'unknown'
        try:
            records.append(CampaignRecord.model_validate(row))
        except ValidationError as exc:
            err = exc.errors(include_input=False)[0]
            raise ValueError(f"Row {index} / {'.'.join(map(str,err['loc']))}: {err['msg']}") from exc
    # Reuse batch validation for duplicate IDs and size ceilings.
    try:
        batch = CampaignRequest(records=records)
    except ValidationError as exc:
        raise ValueError(exc.errors(include_input=False)[0]['msg']) from exc
    return {'records':[row.model_dump() for row in batch.records], 'count':len(records),
            'warnings':list(dict.fromkeys(warnings))[:10], 'stored':False, 'network_requests':0}
