# RealityCheck AI 3.0.0 — Red Team Edition

## One sentence
We attacked our own detector with 13 evasion techniques, measured where it broke, hardened it, and put the whole experiment inside the product so anyone can repeat it live.

## Headline numbers (synthetic, development benchmark)
| | 2.0 | 3.0 |
|---|---|---|
| Attack trials where the alert level held (275 trials, 30 scam messages, ar/he/en) | **44.4 %** | **91.3 %** |
| New alerts on 156 benign texts | — | **0** |
| Score change on clean suspicious texts | — | **0** |
| Python ↔ JS score mismatches on 600 clean + attacked texts | 1 | **0** |
| Campaign-correlation outputs and benchmark | — | identical to 2.0 |

Reproduce: `node scripts/redteam_benchmark.mjs --corpus-out evaluation/redteam_corpus.json` then `python -m pytest -q tests/test_shield.py`. UI checks: `python tests/browser_v3.py` (29/29 in the build environment, Chromium).

## Per technique (share of trials held)
| Technique | Family | 2.0 | 3.0 |
|---|---|---|---|
| Leetspeak (p4ssw0rd) | visual | 17 % | 100 % |
| Invisible soft hyphen U+00AD | invisible | 21 % | 100 % |
| Symbol inside word (pass*word) | structural | 21 % | 100 % |
| Emoji inside word | structural | 21 % | 100 % |
| Chained attack (3 techniques) | structural | 21 % | 76 % |
| Look-alike letters (Cyrillic/Persian) | visual | 32 % | 100 % |
| Letter spacing (p a s s) | structural | 38 % | 86 % |
| Zero-width space, tatweel/diacritics, Arabic-Indic digits, defanged links, full-width | various | 100 % | 100 % |
| **Semantic paraphrase** | semantic | 29 % | **29 %** — not defended |

## What was added
1. **Evasion Shield** (`backend/matching.py::shield_view`, `frontend/src/engine.js::shieldView`) — runs after URL blanking and before rules; every output character keeps its original offset, so evidence spans still point into the user's own text. Steps: drop invisible characters → map confusables (Cyrillic, Greek, Persian) and Arabic-Indic digits → decode leetspeak only inside mostly-Latin tokens → drop joiners/symbols sandwiched between letters → join runs of ≥4 single letters. `analyze(..., shield=False)` reproduces 2.0.
2. **Red Team Arena** (`frontend/src/redteam.js`, page *Red Team Arena*) — white-box operators rewrite only the words inside rule evidence spans. Live mode attacks any pasted message; each card can open the attacked text in the investigation view.
3. **Manipulation DNA** — seven levers adapted from Stajano & Wilson (2011): time, authority, fear, greed, secrecy, herd, kindness; derived from rule signals plus a small trilingual cue lexicon. Labelled as lexical cues, not psychological measurement.
4. **Evidence X-ray** — rule evidence highlighted by group; invisible and disguised characters rendered as red badges with their code point.
5. **Human vs AI** — 8 staged rounds per language; engine scores 7/8 by design (it misses the link-free "hi mom" scam, which the DNA profile still flags as kindness + time pressure).
6. **Warn someone you love** — a copyable summary that never includes the suspicious link or original text.

## Limitations (say these out loud)
- Attacks, corpus and defence were all authored by the team; this is a development benchmark, not a field evaluation. A white-box attacker is stronger than most real attackers, but an adaptive attacker who knows the shield could still find new evasions.
- Joined spaced letters can merge two adjacent spaced words ("p a y g i f t") — counted as *weakened* in the benchmark.
- Meaning-preserving paraphrase is not handled by character normalization; a multilingual semantic model is the next step.
- FastAPI-dependent Python suites were not runnable in the 3.0 build sandbox (no package index access); the pure-engine suites (`test_analyzer.py`, `test_shield.py`, 81 tests) and the browser checks were run. Run `RUN_TESTS.bat` on your machine before submission.
