# Security and privacy scope

This release is for one trusted user on a local computer. It has not received an independent security audit. It is not an enterprise security boundary.

## Untrusted inputs

Message bodies, domains, IDs, batch file contents, notes and profile fields are untrusted. The application escapes them for HTML rendering. Exported HTML has no scripts, external assets or clickable suspect URLs. CSV is parsed as data only; the application does not execute spreadsheet formulas and does not export CSV. Local API payloads are Pydantic-validated with lengths/counts. Request bodies are capped, including streamed bodies. IDs do not become filesystem paths. SQL uses bound parameters.

The campaign engine never fetches URLs, resolves DNS or scans third-party infrastructure. Private/IP URLs are excluded as correlation anchors. This avoids creating a crawler/SSRF path in that engine; it is not a broader security certification.

## Local request protection

The server binds 127.0.0.1, restricts Host headers, rejects cross-site API requests, and requires a custom client header plus same-origin checks for mutations. This is not login/authentication. Local software or someone using the same computer can access the service and database. No multi-user isolation, account system or production authorization layer is supplied.

Original API POST rate limit is 30 mutations per minute per client in non-test mode. Large batch work is bounded at 200 records / 300,000 total text characters. Synchronous campaign routes use FastAPI's threadpool execution rather than making this CPU work an async coroutine.

## Data

Campaign reports use best-effort masking of common email/number/secret patterns and URL path/query data. Some names, addresses, unusual tokens, hostnames containing PII and other personal content can remain. Masking is not anonymization. Review before saving/sharing; use authorized data only. Original individual-analysis saved cases may retain raw text after their own explicit save consent.

The database, notes, exports and optional `.env` secrets are not encrypted by this application. Use device access controls and do not distribute user data or credentials. A snapshot checksum is not a digital signature. Local events are not authenticated or tamper-proof. Deleting a record does not erase backups or copies of previously exported files.

## External services

The campaign engine makes no provider calls. The existing optional per-message cloud explanation, image transcription, and domain-reputation features remain separate and require credentials/consent. They may transmit permitted content to their providers; live credentials were not used in this build. Review provider terms and data handling before enabling them. Do not silently turn them on for someone else's messages.

## Before an internet or business pilot

A public/organizational deployment needs a separate design for authentication, authorization, tenant isolation, transport security, retention/deletion controls, secret management, provider data handling, abuse controls, monitoring, reproducible field evaluation and incident response. Do not expose the current unauthenticated service through a tunnel or open its port to the public internet.

References to design sources are in SOURCES_V2.md. Tests cover specific cases, not every vulnerability or adversarial input.
