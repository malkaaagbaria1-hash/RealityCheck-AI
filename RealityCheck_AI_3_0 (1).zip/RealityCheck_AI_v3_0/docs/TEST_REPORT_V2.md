# RealityCheck AI 2.0 — Release verification

Build date: 2026-11-05. Local Linux build environment, Python 3.13.5.

## Executed checks

| Area | Observed result | Evidence |
|---|---:|---|
| Python automated checks | **233 passed** | `python_tests_v2.xml` |
| New campaign UI and behavior checks | **61 passed** | `browser_v2_results.json` |
| Existing feature UI and behavior checks | **50 passed** | `browser_release_results.json` |
| Rule-engine Python/JavaScript parity | 60 fixtures inside the preceding UI suite | `browser_release_results.json` |
| Local model Python/JavaScript parity | 60 fixtures inside the preceding UI suite | `browser_release_results.json` |

The 111 browser checks are assertions, not 111 independent real-world cases. Counts are not measures of fraud detection accuracy. Re-run `python -m pytest -q`; see tests/browser_intelligence.py and tests/browser_release.py for the browser harness. Use a disposable `scripts/serve_ui_test.py` server for those browser scripts, not your personal case database.

Python coverage includes import validation, bounds, timestamp parsing, safe URL parsing, no DNS/URL fetching, simple negation, credential cues, clustering reasons, generic host handling, duplicate handling, masking, complete-link bridge prevention, evidence prioritization regression, snapshot revisions, review persistence, export escaping, local Host/origin/mutation-header policy and inherited features. These are selected tests, not a complete security audit or a coverage-percentage claim.

## Browser execution boundary

Native browser navigation to localhost is blocked by this build environment. The bundled HTML was loaded into Chromium using `set_content`, with a restricted Python HTTP bridge forwarding relative `/api/` requests to the disposable local server. This tests DOM rendering, actual UI actions, and backend behavior. Export content was intercepted as a Blob for checks rather than testing operating-system download delivery.

Screenshots are from the real application under this harness; not artwork. Desktop and a **390-pixel viewport** were exercised in Arabic, Hebrew and English; no overflow was observed in the checked screens. These are **not physical iPhone/Android tests**. Native Windows, Safari, real browser navigation on the user's computer, public hosting, and external API credentials were not tested here.

## Synthetic development benchmark — not an independent holdout

83 synthetic messages, 3403 unordered message pairs. Pair label means two records belong to the same author-assigned fictional campaign. Predicted positive means the records end in the same candidate group, not merely that a candidate edge exists.

| Metric | Value |
|---|---:|
| True-positive pairs | 92 |
| False-positive pairs | 4 |
| False-negative pairs | 6 |
| True-negative pairs | 3301 |
| Pair precision | 0.958333 |
| Pair recall | 0.938776 |
| Pair F1 | 0.948454 |

This set is distinct from the 37-message presentation demo, but was inspected and used during debugging. It is a **development regression benchmark**, not a blinded validation set. Do not turn the above into an advertised real-world accuracy percentage. The 240-message Naive Bayes training data inherited from 1.0 is also synthetic.

Known error examples remain visible in the Evaluation UI and `evaluation/campaign_results.json`: shared infrastructure can incorrectly merge unrelated campaigns; translated messages with changed domains or weak cues can be missed. A substring/regex detector has limited language understanding. No fraud actor attribution is made.

During development, high text similarity on reused templates could outrank shared-host evidence and create mixed groups. The engine now prioritizes exact duplicates, identical targets and exact hosts before contact/text-only links, with complete-link admission. A regression check covers the discovered failure. This is an engineering fix for a known case, not proof that every false merge is solved.

## Capacity and measurement

Limit: 200 records per batch; 6,000 characters per record, total 300,000 characters. One dense synthetic 200-message batch produced 19,900 pair links in 448.75 ms on this Linux environment, with an approximately 6.7 MB JSON result (`performance_v2.json`). This is a single local measurement, not an SLA or a Windows throughput promise. Computation/output are quadratic in pair count. UI graph and relation tables are capped; JSON retains all returned data.

## Packaging / scope

The release contains source, built UI, fixtures, scripts, test evidence and updated Markdown documentation. No API keys, personal databases, local virtual environments, private messages, or installation logs should be bundled. `SHA256SUMS.txt` verifies release-file integrity, not publisher identity. The HTML-only fallback retains individual analysis but **cannot run campaign correlation without the Python server**.

See `PACKAGE_SMOKE_V2.json` for the clean-extracted-package HTTP check and `THREAT_MODEL_V2.md` for security boundaries. The app remains local single-user software, not a public multi-tenant security service.
