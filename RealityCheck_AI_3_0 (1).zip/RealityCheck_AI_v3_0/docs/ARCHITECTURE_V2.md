# Architecture / RealityCheck 2.0

## Components

Browser UI (dependency-free JavaScript/CSS; three-language labels) → FastAPI local API → bounded import / campaign engine → optional explicit-save SQLite snapshot.

`campaign_models.py` defines contracts. `campaigns.py` is the network-free correlation engine and importer. `campaign_store.py` stores only server-owned reports and revisioned review changes. `campaign_api.py` exposes routes. `campaign_exports.py` creates escaped inert HTML. `frontend/src/intelligence.js` renders the workbench and data-bound SVG. Existing individual-analysis, learned baseline and optional providers are retained.

## Pipeline

1. Validate 1–200 records, unique IDs, each text 1–6000 chars, total <=300,000 chars. Normalize ISO timestamps to UTC; reject timezone-free timestamps instead of inventing times.
2. Run the original local rule engine. Keep its explainable evidence and limited negation/awareness suppression. A supplied brand alias plus an unlisted hostname adds a 28-point review cue; an incomplete legitimate-provider list can cause false flags.
3. Extract exact hostnames (no eTLD+1 guesses), exact full-target comparisons, and normalized contact values. Contact/target comparisons use per-run HMAC keys which are not returned or persisted. Private/IP destinations are not correlation anchors. URLs are never visited or resolved.
4. Build bounded word + character-trigram TF-IDF vectors. Word weights are 1.3, character weights .5; L2 normalize, then cosine compare. This is a local similarity method, not a multilingual LLM or pretrained embedding model.
5. Permit an edge only when both records have actionable risk cues and an independent anchor. A brand name or shared risk words alone is insufficient. Generic hosts in the bundled list do not contribute hostname-anchor weight.
6. Greedy complete-link merge: order edges by anchor type (exact duplicate, same full target, shared exact host, shared contact, text-only), then strength and stable IDs. Merge two groups only if **every cross-pair** has a qualifying edge. This prevents bridge-only transitive merges. It is deterministic, not globally optimal clustering.
7. Produce masked text, evidence, candidate groups, exact domain counts, supplied-date timeline, and metadata. Do not include the raw texts or comparison HMACs in the returned snapshot. Network request count for this engine is zero.

## Link heuristic (not a calibrated probability)

A pair must have both records eligible: score >=25 and a credential/payment/remote-access/secrecy/unusual-payment/domain mismatch cue, or both urgency and threat. Not all fraudulent messages satisfy this gate; misses are expected.

Base = max(.58 for shared non-generic/non-approved exact host, .62 for identical full URL target, .40 for shared contact). Add .12 for shared request/risk cues, plus .30 × text cosine. When normalized texts are >=45 characters and cosine >=.90, a near-template link may instead use .72 + .25 × cosine. An exact duplicate with sufficient text gets at least .99. A meaningful anchor is mandatory. Score is capped at 1.

Thresholds: balanced .66, strict .82. A stricter threshold may omit useful links and can change cluster composition; it is not a guarantee of higher real-world precision. The values are hand-set engineering choices, not learned/calibrated probabilities.

The all-pairs similarity stage is approximately O(n² × F), with capped feature dimension F <=1800. Complete-link consistency adds bounded pair checks. Edge storage is O(n²). The application intentionally caps n at 200; it is not a large-scale streaming threat platform. Dense batches return up to 19,900 pair relations; the UI caps graph nodes and displayed relation rows, not the export.

## Semantic limits

Cross-language correlation works when messages share observable anchors and compatible local risk cues. Translations on different infrastructure can be missed. Shared hosting can cause false joins. Character-script labels are rough language hints, not a reliable general language detector. Same hostname/URL/contact does not establish ownership or an actor. A campaign label is always a review hypothesis.

## Storage / concurrency

Recent results: up to 4 in memory, TTL 30 minutes. Raw request text is not stored by campaign endpoints. Explicit save writes masked report JSON to `data/cases.sqlite3` in `campaign_runs`; max 50 snapshots. Review updates occur in a transaction with an expected revision, preventing a stale tab from silently overwriting newer changes. Human status never changes automated evidence. Events are capped at 200 per run. Snapshot SHA-256 is a checksum, not a signature or tamper-resistant audit trail.

## UI/export

Untrusted input is HTML-escaped. Suspect URLs are inert text. Graph nodes come from actual result records; no random/fake result values. Solid lines represent message–hostname occurrences. Dashed message–message lines represent other qualifying evidence for the current group. The diagram is capped at 30 messages/12 hosts and 80 other evidence lines; the table/JSON remains complete. Timeline is based only on user-supplied UTC dates and shows at most the last 30 occupied dates.

Standalone mode retains individual analysis but disables campaign features with an explicit explanation. Static hosting of the fallback file does not deploy the Python workbench.
