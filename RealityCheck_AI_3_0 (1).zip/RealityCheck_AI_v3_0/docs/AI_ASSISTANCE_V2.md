# Development assistance disclosure

The project was developed with AI-assisted code generation, design, debugging and documentation. The uploaded v1 project was used as the base; v2 adds new campaign modules and tests. No claim is made that the student independently authored every line, that the system is globally novel, or that all benchmark examples are real.

Before academic submission, the team should review and understand the source, run the tests on its own machine, explain algorithms and tradeoffs, document human/AI contributions as required by the course, and replace any placeholder team/course information. Successful tool tests are evidence about those test cases, not a guarantee of a grade, safety or commercial viability.
