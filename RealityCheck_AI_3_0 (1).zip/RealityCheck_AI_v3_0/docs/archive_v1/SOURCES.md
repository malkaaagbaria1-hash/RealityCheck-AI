# Primary references (checked 2026-11-05)

These support API contracts, limitations and related-work descriptions, not our measured software results.

1. OpenAI Responses API — text/image inputs, instructions, store setting:
   https://developers.openai.com/api/reference/resources/responses/methods/create
2. OpenAI data controls — retention differs from disabling response storage:
   https://developers.openai.com/api/docs/guides/your-data
3. VirusTotal domains — hostname-level attributes and analysis statistics:
   https://docs.virustotal.com/reference/domains-object
4. VirusTotal API usage and public/non-commercial limitations:
   https://docs.virustotal.com/reference/getting-started
   https://docs.virustotal.com/reference/public-vs-premium-api
5. OWASP LLM Prompt Injection Prevention — untrusted inputs, limited authority, output handling:
   https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html
6. scikit-learn Naive Bayes documentation — multinomial text classification and poorly calibrated probabilities:
   https://scikit-learn.org/stable/modules/naive_bayes.html
7. Norton Genie official FAQ — existing text/screenshot scam assessment and explanations:
   https://support.norton.com/sp/en/us/home/current/solutions/v20230717145233467
8. Google Safe Browsing official reference — unsafe web-resource lookups and non-commercial API terms:
   https://developers.google.com/safe-browsing/reference

No Norton, Google Safe Browsing, or UCI data/integration is bundled. Competitor comparison is descriptive, not a head-to-head performance benchmark. The training dataset in this release is authored synthetic data only. The code's default analysis makes no provider requests. External integrations do not inherit the research validity of provider marketing claims.
