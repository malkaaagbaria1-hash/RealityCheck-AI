# Architecture — 1.0.0

## Data flow

Browser → Pydantic request validation → normalization + evidence mapping → local rules/context → URL syntax checks → deduplicated rule score → independent local Naive Bayes → optional provider enrichment → report. Saving to SQLite requires a separate opt-in request. Local Q&A retrieves a recent/saved report by ID; it does not accept client-forged evidence.

The portable HTML bundles the same JSON rules, model weights, templates and translations. JavaScript implements a matching counterpart; Python is the primary academic backend. Parity tests cover the bundled cases, not a proof of parser equivalence (Python URL parsing and browser WHATWG URL parsing differ for unusual inputs).

## Engine

`matching_view` applies per-character NFKC, removes selected Arabic/Hebrew marks and invisible joiners, normalizes alef forms and preserves offsets into original text. URL substrings are blanked for message matching. Rules are compiled once. Each rule records the first non-suppressed match. Suppression inspects at most 110 preceding normalized characters inside a bounded sentence for negation/warning context. This is a narrow heuristic; it cannot resolve arbitrary quotation, irony or discourse.

Score = min(100, sum of maximum weight for each distinct signal code)). Review threshold 25; high threshold 55. Weights are hand-designed, not learned or calibrated. Multiple related signals may be correlated; the score is an explanatory index only. Context bonus is added when a sensitive request is combined with pressure or a URL. External flags are separate and cannot silently modify the local index.

URL handling never visits the destination, resolves DNS, follows redirects or checks ownership. Expected-domain checks use equality or `.`-bounded suffix matching. Typo hints compare full hostnames using a one-edit/skeleton heuristic; there is no Public Suffix List or comprehensive Unicode confusable database. Non-Latin domains are not classified as malicious solely for being IDNs.

## Learned baseline

Multinomial Naive Bayes over word unigrams, word bigrams and in-word character trigrams, Laplace smoothing α=1. Frozen JSON stores per-feature log-likelihood differences and prior log odds. Inference sums weighted counts; it abstains on too few known features, low feature coverage or a narrow margin. Model margins are never exposed as fraud probabilities. Data: 240 authored synthetic rows, 120 base families, three languages. Training is reproducible; 5-fold evaluation keeps both variants from each family together. No hidden provider call or downloaded pre-trained model is required.

## API

GET `/api/health`, `/api/evaluation`, `/api/cases`, `/api/cases/{id}`.
POST `/api/analyze`, `/api/compare`, `/api/assistant`, `/api/self-check`, `/api/cases`, `/api/cases/{id}/note`, `/api/extract-image`.
DELETE `/api/cases/{id}`, `/api/cases`.
OpenAPI: `/api/docs`. The interactive docs require the same `X-RealityCheck-Client: web` header on mutations; use the app or explicit HTTP calls. A docs request without that header intentionally fails.

## Local server controls

Loopback binding. Host allowlist. Same-origin checks plus `Sec-Fetch-Site` rejection for cross-site API requests. Mutations require a custom header and POST requires JSON. Streamed bodies capped at 6.5 MB. Input text max 12,000 characters. At most 10 URL candidates analyzed. Rate limit: 30 mutations/minute/client. Images: 4 MB decoded, 16M pixels, transcoded JPEG before optional upload. Exact API keys never return in health or diagnostics.

No account login or per-user tenancy; this is not a deployment security boundary. A hostile local user/process with access to files is outside the threat model. Do not tunnel the service publicly.

## Complexity

With fixed, bounded rule patterns, text normalization and scanning are approximately proportional to message length and rule count, not a formal worst-case regex guarantee. Naive Bayes feature extraction/inference is linear in generated feature count. Near-hostname matching is O(hostname length). SQLite stores serialized report JSON keyed by case id; it uses parameterized SQL. The list endpoint reads the most recent 200 records.
