Historical v1.0 material. The old slides/report describe v1.0 only and are not the current v2.0 specification. Use ../PROJECT_HE_V2.md, ../DEMO_AR.md and ../TEST_REPORT_V2.md for this release.
