# 1.0.0 — Academic release

Changes from supplied 0.1.0 archive:
- Fixed Arabic credential requests such as «لازم تدخل كلمة المرور» without an ad-hoc pasted block.
- Added normalized Arabic/Hebrew matching with original evidence offsets and bounded warning/negation suppression.
- Added unusual-payment signals, expected-host typo hints, misleading expected-domain placement and non-scoring prompt-instruction notes.
- Added independent trained local Naive Bayes with explicit synthetic-data scope, abstention, learned feature explanations and Python/JavaScript parity checks.
- Added evidence-linked template assistant and opt-in cloud Q&A.
- Added message comparison, case dashboard, analyst notes/review status and standalone HTML reports.
- Added an evaluation workbench, authored challenge set, grouped model cross-validation, visible failures and readiness checks.
- Improved error diagnosis, port selection, Windows startup, diagnostics and optional server-side key setup.
- Added academic handoff material, privacy/threat documentation and honest verification boundaries.

Not included: public hosting, user accounts, local screenshot OCR, autonomous browsing, production fraud certification or tested user-owned provider keys. Existing prototype data is not automatically migrated; keep the old project backed up.
