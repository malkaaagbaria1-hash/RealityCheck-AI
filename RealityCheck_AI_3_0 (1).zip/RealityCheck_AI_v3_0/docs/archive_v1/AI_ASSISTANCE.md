# AI assistance and authorship disclosure

This release was substantially developed with generative AI assistance, including code generation, refactoring, test authoring, synthetic data, UI text and documentation. The student/team must review the implementation, validate it on their own hardware, understand the algorithms and comply with their course's AI policy.

Suggested disclosure (adapt to actual contributions, do not submit as a false personal claim):

> We used an AI assistant for implementation drafts, debugging, tests, documentation and synthetic data generation. We are responsible for reviewing the code, understanding design decisions, reproducing the tests, identifying limitations and accurately describing our own contributions. Individual contributions and final acceptance checks are documented separately.

No team contribution has been invented. Names, course details and contribution records must be completed by the actual team. Passing bundled tests does not prove personal understanding or satisfy an unseen course rubric.
