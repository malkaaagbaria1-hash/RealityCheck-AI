# Verification report — academic release 1.0.0

Build date: 2026-11-05. Environment: Linux x86_64, Python 3.13.5, Chromium.

## Functional verification
150 pytest tests passed; 0 failed. See `python_tests.xml`. The suite includes analysis, multilingual sensitive requests and bounded negation, URL parsing, input limits, API consent, local storage, redaction, mock external integrations, evidence assistant, comparison, review notes and live self-check.

## Browser verification
82 named checks passed: 32 existing smoke checks plus 50 release checks. The latter includes parity checks for all 60 synthetic challenge cases (rule scores/codes and advisory-model results). The first suite also compares 12 translated demo examples. These are checks, not independent accuracy observations.

Method: Chromium renders the built standalone HTML via `set_content`. A Python HTTP bridge forwards only local `/api/` requests to the real backend, because native browser navigation is blocked in this environment. Tests inspect UI behavior, saving/reloading, generated report contents, multilingual rendering, presentation mode, local fallback, and overflow at 1440px desktop and 390px mobile viewports. JSON logs: `browser_results.json` and `browser_release_results.json`.

Not verified here: Windows BAT execution, a physical iPhone/Safari, native browser navigation, download delivery, public hosting, real provider credentials. These remain manual acceptance gates. Browser screenshots are of rendered code, not design mockups.

## Rule development challenge (synthetic only)
60 authored messages, balanced 30 caution / 30 ordinary, 20 per language. Alert threshold: score >=25. TP24, FP6, FN6, TN24. Precision=0.80, recall=0.80, F1=0.80. Not independent: these are development examples authored for this project, not real-world samples. Every error is retained in `evaluation/results.json` and `rule_predictions.json`.

## Learned baseline (synthetic only)
240 authored examples in 120 template families. Five grouped folds: 192 training / 48 validation examples each; zero family overlap per fold. Models are retrained inside each fold. 219 classified, 21 abstentions; coverage91.25%. On classified examples: TP80, FP37, FN24, TN78; precision68.38%, recall76.92%, F172.40%. Do not compare this directly with the rule benchmark: datasets and evaluation protocols differ. Cross-validation remains synthetic, small, multilingual and not representative of real deployment.

The shipped model is trained on all240 examples for demonstration. It is a learned Multinomial Naive Bayes baseline, not an LLM. Its output never changes the deterministic rule score. Feature contributions explain model behavior; they are not independent evidence that the message is fraudulent.

## Original user regression
The request containing 'لازم تدخل كلمة المرور' now scores88: urgency12 + threat18 + credentials40 + compound18. The negative warning 'لا ترسل كلمة المرور أو رمز التحقق لأي شخص.' scores0. Zero means no selected rule contributed, not that the message is safe.

## Reproduction
Run `python -m pytest -q`, `python scripts/evaluate.py` and `python build_frontend.py`. Browser scripts additionally require Playwright, Chromium and a loopback server on8765. Their launch/method are documented in the scripts. External providers are stubbed in automated tests; never substitute screenshots for a live-integration test.

For browser tests use a disposable server: `python scripts/serve_ui_test.py`, then run the smoke script followed by the release script in another terminal. Restart this test server for a fresh database before rerunning the smoke script. Do not run UI tests against your own saved case database.
