# v2.0.0 / Campaign Intelligence

Added the local campaign workbench, bounded batch ingestion, explainable pair correlation, anchor-prioritized complete-link grouping, interactive SVG evidence maps, supplied-date timeline, optional brand profile, saved masked snapshots, revision-aware human review, inert HTML and JSON exports, synthetic development evaluation, and a clearer Windows launcher.

Retained individual message/URL analysis, comparison, rule evidence, experimental 240-example Naive Bayes model, template evidence assistant, per-case storage and optional provider integrations. The new campaign engine does not rely on cloud AI or claim general semantic translation.

The old office report and slide deck are archived under docs/archive_v1. New source-of-truth documentation is PROJECT_HE_V2.md / ARCHITECTURE_V2.md / TEST_REPORT_V2.md. There is no new PowerPoint deck in this release; do not present the old deck as a complete v2 description.

Migration: use a NEW extracted folder. Do not overwrite your v1 copy or copy its .venv. No existing user database or .env is bundled. Re-enter any service configuration locally only when needed. Saved v1 cases are not automatically migrated.

Known limitations: local single-user only; no public deployment/authentication; no live data collection/monitoring; no sender or actor attribution; best-effort masking; generic-host list incomplete; no live-key provider verification; native Windows/Safari execution still needs user-side verification.
