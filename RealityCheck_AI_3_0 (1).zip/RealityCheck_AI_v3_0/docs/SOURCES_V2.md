# Implementation references

Accessed during this build on 2026-11-05. These are design/documentation references, not evidence that this application is certified or commercially superior.

- Python Software Foundation, Using Python on Windows (install manager, runtime selection, py list / py install): https://docs.python.org/3/using/windows.html
- FastAPI, Concurrency and async / await (normal def route execution in a threadpool): https://fastapi.tiangolo.com/async/
- OWASP, CSV Injection (untrusted spreadsheet contents; this release imports CSV as text and does not export CSV): https://community.owasp.org/attacks/CSV_Injection
- Public Suffix List, Learn (registrable-domain boundaries cannot safely be guessed by taking the last two labels): https://publicsuffix.org/learn/

This release uses exact hostname matching and does not bundle/update a Public Suffix List. Hostname equality is not an ownership claim. No source above supplies this engine's heuristic weights or validates its detection accuracy.

## Added for 3.0
- F. Stajano and P. Wilson, "Understanding scam victims: seven principles for systems security", Communications of the ACM 54(3), 2011 — basis for the Manipulation DNA axes.
- Unicode Technical Standard #39, Unicode Security Mechanisms (confusable characters) — https://www.unicode.org/reports/tr39/ — background for the confusable mapping; the shield uses a small hand-picked subset, not the full confusables table.
- Unicode Standard Annex #15, Normalization Forms (NFKC) — https://www.unicode.org/reports/tr15/
