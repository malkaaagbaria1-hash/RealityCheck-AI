"""Bundle the dependency-free UI for both localhost and file:// usage."""
from pathlib import Path
import json
from backend.assistant import TEXT,PATTERNS
ROOT=Path(__file__).resolve().parent
assets=ROOT/'web/assets';assets.mkdir(parents=True,exist_ok=True)
data={name:json.loads((ROOT/f'shared/{name}.json').read_text(encoding='utf-8')) for name in ('rules','signals','samples','entities')}
data['model']=json.loads((ROOT/'ml/model.json').read_text(encoding='utf-8'))
data['evaluation']=json.loads((ROOT/'evaluation/results.json').read_text(encoding='utf-8')) if (ROOT/'evaluation/results.json').exists() else {}
data['assistant']={'text':TEXT,'patterns':PATTERNS}
rt_path=ROOT/'evaluation/redteam_results.json'
if rt_path.exists():
    rt=json.loads(rt_path.read_text(encoding='utf-8'))
    data['redteam']={k:rt[k] for k in ('messages_attacked','trials','operators','totals','robustness','false_positive_guard') if k in rt}
data_js='window.RC_DATA='+json.dumps(data,ensure_ascii=False)+';\n'
js=data_js+'\n'.join((ROOT/f'frontend/src/{p}.js').read_text(encoding='utf-8') for p in ('ml','engine','redteam','smart','i18n','advanced','intelligence','v3','app'))
css=(ROOT/'frontend/src/styles.css').read_text(encoding='utf-8')+'\n'+(ROOT/'frontend/src/intelligence.css').read_text(encoding='utf-8')+'\n'+(ROOT/'frontend/src/v3.css').read_text(encoding='utf-8')
head='''<!doctype html><html lang="ar" dir="rtl" data-theme="dark"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta name="description" content="RealityCheck AI — local, evidence-first message and URL triage. Red Team Edition 3.0.0."><title>RealityCheck AI | المحقق الرقمي</title>'''
body='''</head><body><a class="skip-link" href="#main-content">تخطي إلى المحتوى / Skip to content</a><div id="app"><section style="max-width:760px;margin:60px auto;padding:30px;font:18px/2 system-ui"><h1>RealityCheck AI</h1><p>هذه معاينة للملف. لتشغيل التطبيق افتحه على الكمبيوتر باستخدام Chrome أو Edge، أو افتح نسخة منشورة كرابط على الهاتف. معاينة ملفات iPhone قد لا تشغّل JavaScript.</p><p>זו תצוגה מקדימה. הפעלת האפליקציה דורשת דפדפן שמריץ JavaScript.</p><p>Open the file in a desktop browser, or use a hosted website link on your phone. File preview apps may not run JavaScript.</p></section></div><div id="toast" role="status" aria-live="polite"></div><noscript>This app needs JavaScript enabled. No remote scripts are required.</noscript>'''
(assets/'app.js').write_text(js,encoding='utf-8')
(assets/'styles.css').write_text(css,encoding='utf-8')
(ROOT/'web/index.html').write_text(head+'<link rel="stylesheet" href="/assets/styles.css">'+body+'<script src="/assets/app.js" defer></script></body></html>',encoding='utf-8')
# No third-party assets: this file opens without an internet connection.
portable=head+'<style>'+css+'</style>'+body+'<script>'+js.replace('</script','<\\/script')+'</script></body></html>'
(ROOT/'RealityCheck_AI.html').write_text(portable,encoding='utf-8')
print('Built web assets and RealityCheck_AI.html; no Node.js/npm required.')
