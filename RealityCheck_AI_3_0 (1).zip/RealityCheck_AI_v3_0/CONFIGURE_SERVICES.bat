@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python.exe scripts\configure_services.py
) else (
 py -3 scripts\configure_services.py
)
pause
