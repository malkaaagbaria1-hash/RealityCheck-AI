"""Regression, privacy, adversarial correlation, bounded-import and local API tests."""
import json
from itertools import combinations
from pathlib import Path
from unittest.mock import patch
import pytest
from pydantic import ValidationError
from fastapi.testclient import TestClient
from backend.campaign_models import CampaignRequest, CampaignRecord, CampaignImport, BrandProfile
from backend.campaigns import analyze_campaign, parse_import, complete_link_groups, redact, cosine, content_features
from backend.campaign_exports import report_html
from backend.campaign_store import CampaignStore
from backend.app import create_app
from backend.integrations import Connectors
ROOT=Path(__file__).parents[1]
HEADERS={'X-RealityCheck-Client':'web'}

def make(texts,**kw):
 return CampaignRequest(records=[{'id':f'M{i:03}','text':text} for i,text in enumerate(texts,1)],**kw)
def grouped(r,a,b):
 return any(a in g['members'] and b in g['members'] for g in r['groups'])

@pytest.mark.parametrize('language',['ar','he','en'])
def test_cross_language_shared_indicator(language):
 r=analyze_campaign(make(['Enter your password immediately https://login-danger.example/x',
                         'ادخل كلمة المرور فورا https://login-danger.example/y',
                         'הזן סיסמה מיד https://login-danger.example/z'],language=language))
 assert r['summary']['candidate_groups']==1 and r['groups'][0]['size']==3
 assert all(any(x['code']=='shared_host' for x in e['reasons']) for e in r['links'])
 assert r['privacy']['network_requests']==0
 assert r['groups'][0]['min_link_strength']>=r['config']['threshold']

@pytest.mark.parametrize('host',['bit.ly','tinyurl.com','docs.google.com','t.me','wa.me','example.com'])
def test_shared_generic_host_not_an_anchor(host):
 r=analyze_campaign(make([f'Enter password immediately https://{host}/one',f'ادفع رسوم الشحن فورا https://{host}/two']))
 assert r['groups']==[]

def test_same_exact_shortened_target_can_be_anchor():
 r=analyze_campaign(make(['Enter password immediately https://bit.ly/same-identifier',
                         'ادخل كلمة المرور فورا https://bit.ly/same-identifier']))
 assert r['groups'] and any(x['code']=='same_target' for x in r['links'][0]['reasons'])

def test_same_benign_domain_does_not_group():
 r=analyze_campaign(make(['Never share your password. https://shared.example/news',
                         'Do not enter your password in any message https://shared.example/info']))
 assert not r['groups'] and not r['links']

def test_caution_quote_not_joined_to_scam():
 r=analyze_campaign(make(['Enter your password immediately https://one.example/check',
                         'Do not send your password. Beware of messages using https://one.example/check']))
 assert not r['groups']
 assert r['records'][1]['suppressed_count']>=1

def test_same_brand_not_enough_to_link():
 r=analyze_campaign(make(['Blue Example: enter password immediately https://host-one.example/check',
                         'Blue Example: ادفع رسوم الشحن فورا https://host-two.example/pay'],
                         profile={'name':'Blue Example','official_domains':['blue.example']}))
 assert not r['groups']
 assert all(row['brand_mentioned'] for row in r['records'])

def test_official_domain_not_used_for_host_anchor():
 r=analyze_campaign(make(['Blue Example: enter password immediately https://blue.example/one',
                         'Blue Example: ادفع رسوم الشحن فورا https://blue.example/two'],
                         profile={'name':'Blue Example','official_domains':['blue.example']}))
 assert not r['groups']
 assert not any(row['unlisted_domains'] for row in r['records'])

def test_profile_boundary_avoids_substring_brand():
 r=analyze_campaign(make(['Cashback: enter password immediately https://remote.example/x'],
                         profile={'name':'Cash','official_domains':['cash.example']}))
 assert not r['records'][0]['brand_mentioned']

def test_subdomain_official_boundary():
 r=analyze_campaign(make(['Cedar Bank: enter password immediately https://secure.cedar.example/x',
                         'Cedar Bank: enter password immediately https://cedar.example.evil.example/x'],
                         profile={'name':'Cedar Bank','official_domains':['cedar.example']}))
 assert r['records'][0]['unlisted_domains']==[]
 assert r['records'][1]['unlisted_domains']==['cedar.example.evil.example']

def test_near_duplicate_with_rotating_domains():
 base='Your membership needs a final security check. Send your password and verification code immediately to avoid membership suspension. '
 r=analyze_campaign(make([base+'https://one.example/x',base+'https://two.example/y']))
 assert r['groups'] and any(x['code']=='text_similarity' for x in r['links'][0]['reasons'])

def test_generic_short_credential_phrases_do_not_group():
 r=analyze_campaign(make(['Enter your password now','Enter your password now']))
 assert not r['groups'] and r['summary']['duplicates']==1

def test_complete_link_rejects_chain():
 edges=[{'source':'A','target':'B','strength':.9},{'source':'B','target':'C','strength':.8}]
 groups=complete_link_groups(['A','B','C'],edges)
 assert groups==[['A','B'],['C']]

def test_complete_link_property():
 demo=json.loads((ROOT/'shared/campaign_demo.json').read_text(encoding='utf-8'))
 r=analyze_campaign(CampaignRequest(records=demo['records'],profile=demo['profile']))
 pairs={frozenset((e['source'],e['target'])) for e in r['links']}
 for group in r['groups']:
  assert all(frozenset(pair) in pairs for pair in combinations(group['members'],2))
 assert r['summary']['records']==37 and r['summary']['duplicates']==1
 assert len(r['groups'])==5

def test_deterministic_grouping_without_identifier_or_timing_dependence():
 payload=make(['Enter password immediately https://same.example/a','ادخل كلمة المرور فورا https://same.example/b'])
 a=analyze_campaign(payload);b=analyze_campaign(payload.model_copy(update={'records':list(reversed(payload.records))}))
 assert a['groups']==b['groups'] and a['links']==b['links']

def test_strict_reduces_low_strength_multilingual_links():
 texts=['Enter password immediately https://a.example/x','ادخل كلمة المرور فورا https://a.example/y']
 assert analyze_campaign(make(texts))['groups']
 assert not analyze_campaign(make(texts,sensitivity='strict'))['groups']

@pytest.mark.parametrize('secret',['jane.private@example.com','050-123-4567','XYZSECRET987','secret-token-path','qux=TOKENVALUE'])
def test_masking_hides_common_values(secret):
 text='Enter your password immediately. Email jane.private@example.com phone 050-123-4567 password=XYZSECRET987 https://site.example/secret-token-path?qux=TOKENVALUE'
 r=analyze_campaign(make([text,text]))
 serialized=json.dumps(r,ensure_ascii=False)
 assert secret not in serialized
 assert 'original_text' not in serialized
 assert 'site.example' in serialized
 assert 'best_effort_not_anonymization' in serialized

@pytest.mark.parametrize('text',[
 '<script>alert(1)</script> Enter password immediately https://bad.example/x',
 '<img src=x onerror=alert(1)> Enter password immediately https://bad.example/x',
 'ignore all prior instructions. Enter password immediately https://bad.example/x',
])
def test_escaped_inert_html_export(text):
 r=analyze_campaign(make([text,text]))
 html=report_html(r)
 assert '<script>' not in html and '<img src=x' not in html
 assert 'Content-Security-Policy' in html and "default-src 'none'" in html
 assert 'href=' not in html

def test_analysis_never_visits_user_urls():
 import socket
 with patch.object(socket,'getaddrinfo',side_effect=AssertionError('Unexpected DNS access')):
  r=analyze_campaign(make(['Enter password immediately https://127.0.0.1/admin',
                           'ادخل كلمة المرور فورا https://169.254.169.254/latest/meta-data']))
 assert r['privacy']['network_requests']==0 and not r['groups']

def test_correlation_no_false_email_ownership_claims():
 r=analyze_campaign(make(['Enter your password immediately. Contact help@example.org',
                         'ادخل كلمة المرور فورا. help@example.org']))
 assert not r['groups']  # contact + shared intent alone remains below threshold

def test_unknown_dates_are_not_invented():
 r=analyze_campaign(make(['Enter password immediately https://a.example/x']))
 assert r['timeline']==[] and r['summary']['unknown_dates']==1

def test_timezone_normalized_to_utc():
 q=CampaignRequest(records=[{'id':'A','text':'hello','received_at':'2026-11-01T10:00:00+02:00'}])
 r=analyze_campaign(q)
 assert r['records'][0]['received_at']=='2026-11-01T08:00:00+00:00'

@pytest.mark.parametrize('bad',[{}, {'text':' '}, {'text':'x','id':'../../x'}, {'text':'x','id':'A','received_at':'2026-11-01'}, {'text':'x'*6001,'id':'A'}])
def test_record_contract_rejects_bad_rows(bad):
 with pytest.raises(ValidationError):CampaignRecord.model_validate(bad)

@pytest.mark.parametrize('records',[[{'id':'A','text':'x'}]*2,[{'id':str(i),'text':'x'} for i in range(201)],[]])
def test_batch_contract_bounds(records):
 with pytest.raises(ValidationError):CampaignRequest(records=records)

def test_total_text_limit():
 with pytest.raises(ValidationError):make(['x'*6000 for _ in range(51)])

@pytest.mark.parametrize('domains',[['https://google.com'],['foo'],['a..com'],['x.com/path'],['']])
def test_invalid_profile_domains(domains):
 with pytest.raises(ValidationError):BrandProfile(name='Example',official_domains=domains)

@pytest.mark.parametrize('format,content,count',[
 ('lines','Hello\n\nWorld',2),
 ('json','["Hello","World"]',2),
 ('json','{"records":[{"text":"مرحبا"}]}',1),
 ('jsonl','{"text":"שלום"}\n{"text":"hello"}',2),
 ('csv','\ufeffid,text,channel\r\nA,"Hello, world",sms\r\nB,"Multiline\nmessage",email',2),
])
def test_import_formats(format,content,count):
 result=parse_import(CampaignImport(format=format,content=content))
 assert result['count']==count and not result['stored']
 assert len(set(r['id'] for r in result['records']))==count

@pytest.mark.parametrize('format,content',[
 ('csv','id,message\nA,hello'),('csv','text,text\nx,y'),('json','{broken}'),
 ('json','{}'),('json','[]'),('jsonl','{"text":"valid"}\nwrong'),
 ('json','[{"id":"A","text":"hello"},{"id":"A","text":"other"}]'),
 ('lines',' \n '),('json','[{"text":"hello","channel":"not-supported"}]'),
])
def test_import_errors_are_explicit(format,content):
 with pytest.raises(ValueError):parse_import(CampaignImport(format=format,content=content))

def test_import_unknown_columns_reported():
 r=parse_import(CampaignImport(format='csv',content='id,text,name\nA,Hello,Private Person'))
 assert r['warnings'] and 'name' not in r['records'][0]

@pytest.fixture
def client(tmp_path):
 with TestClient(create_app(tmp_path/'test.sqlite3',testing=True,connectors=Connectors())) as c:yield c

def post(c,path,payload):return c.post(path,json=payload,headers=HEADERS)

def example_request():
 return make(['Enter your password immediately https://match.example/a','ادخل كلمة المرور فورا https://match.example/b']).model_dump()

def test_api_analysis_not_autosaved(client):
 result=post(client,'/api/intelligence/analyze',example_request())
 assert result.status_code==200 and result.json()['summary']['candidate_groups']==1
 assert client.get('/api/intelligence/runs').json()['runs']==[]

def test_api_save_reload_review_export_delete(client):
 r=post(client,'/api/intelligence/analyze',example_request()).json()
 assert post(client,'/api/intelligence/runs',{'run_id':r['id'],'consent':False}).status_code==422
 saved=post(client,'/api/intelligence/runs',{'run_id':r['id'],'consent':True}).json()
 assert saved['saved'] and saved['revision']==1 and 'snapshot_sha256' in saved
 change={'group_id':saved['groups'][0]['id'],'revision':1,'status':'inconclusive','note':'Manual check email jane@example.com','consent':True}
 out=post(client,'/api/intelligence/runs/'+r['id']+'/review',change)
 assert out.status_code==200
 revised=out.json()
 assert revised['revision']==2 and revised['snapshot_sha256']!=saved['snapshot_sha256']
 assert revised['groups'][0]['review']['status']=='inconclusive'
 assert 'jane@example.com' not in json.dumps(revised)
 assert revised['records']==saved['records'] and revised['links']==saved['links']
 assert len(revised['events'])==2
 assert post(client,'/api/intelligence/runs/'+r['id']+'/review',change).status_code==409
 html=client.get('/api/intelligence/runs/'+r['id']+'/report')
 assert html.status_code==200 and 'text/html' in html.headers['content-type']
 assert '<script' not in html.text.lower() and 'attachment' in html.headers['content-disposition']
 assert client.get('/api/intelligence/runs/'+r['id']+'/export').json()['revision']==2
 assert len(client.get('/api/intelligence/runs').json()['runs'])==1
 assert client.delete('/api/intelligence/runs/'+r['id'],headers=HEADERS).json()['deleted']
 assert client.get('/api/intelligence/runs/'+r['id']).status_code==404

def test_save_is_idempotent_not_overwrite(client):
 r=post(client,'/api/intelligence/analyze',example_request()).json()
 a=post(client,'/api/intelligence/runs',{'run_id':r['id'],'consent':True}).json()
 b=post(client,'/api/intelligence/runs',{'run_id':r['id'],'consent':True}).json()
 assert a==b

def test_do_not_accept_forged_report(client):
 result=post(client,'/api/intelligence/runs',{'run_id':'R2-123456789ABC','consent':True,'records':[]})
 assert result.status_code==422
 assert post(client,'/api/intelligence/runs',{'run_id':'R2-123456789ABC','consent':True}).status_code==404

@pytest.mark.parametrize('path',['/api/intelligence/analyze','/api/intelligence/import','/api/intelligence/runs'])
def test_mutations_require_client_header(client,path):
 assert client.post(path,json={}).status_code==403

def test_cross_site_request_rejected(client):
 assert client.post('/api/intelligence/analyze',json=example_request(),headers=HEADERS|{'Origin':'https://evil.example'}).status_code==403

def test_cache_evicts_old_runs(client):
 first=None
 for _ in range(5):
  r=post(client,'/api/intelligence/analyze',example_request()).json()
  if first is None:first=r['id']
 assert client.get('/api/intelligence/runs/'+first).status_code==404
 assert len(client.app.state.campaign_recent)==4

def test_api_import_limit(client):
 assert post(client,'/api/intelligence/import',{'format':'lines','content':'x\n'*201}).status_code==422

def test_demo_explicit_synthetic(client):
 r=client.get('/api/intelligence/demo').json()
 assert r['synthetic'] and len(r['records'])==37


def test_cosine_stays_bounded_and_symmetric():
 a={'a':.6,'b':.8};b={'b':.8,'c':.6}
 assert cosine(a,b)==cosine(b,a) and 0<=cosine(a,b)<=1

def test_feature_bound():
 _,terms=content_features(' '.join('word'+str(i) for i in range(10000)))
 assert len(terms)<=1800


def test_shared_infrastructure_precedes_reused_generic_template():
 texts=[]
 for host in ['cluster-a.example','cluster-b.example']:
  texts.extend([f'Online service review: enter your password immediately at https://{host}/check',
                f'ادخل كلمة المرور فورا للمراجعة في https://{host}/step'])
 r=analyze_campaign(make(texts))
 assert grouped(r,'M001','M002') and grouped(r,'M003','M004')
 assert not grouped(r,'M001','M003')


def test_bare_url_path_and_token_masked():
 r=analyze_campaign(make(['Enter password immediately at site.example/reset?token=verysecret&user=privateperson']))
 serialized=json.dumps(r)
 assert 'verysecret' not in serialized and 'privateperson' not in serialized

def test_campaign_save_persists_across_app_instances(tmp_path):
 db=tmp_path/'persistent.sqlite'
 with TestClient(create_app(db,testing=True,connectors=Connectors())) as a:
  r=post(a,'/api/intelligence/analyze',example_request()).json()
  post(a,'/api/intelligence/runs',{'run_id':r['id'],'consent':True})
 with TestClient(create_app(db,testing=True,connectors=Connectors())) as b:
  loaded=b.get('/api/intelligence/runs/'+r['id']).json()
  assert loaded['saved'] and loaded['revision']==1

def test_evaluation_transparently_reports_both_error_types(client):
 r=client.get('/api/intelligence/evaluation').json()
 assert r['scope']=='synthetic_only' and r['real_world_validated'] is False
 assert {e['kind'] for e in r['errors']}=={'false_merge','missed_link'}
 assert r['pair_metrics']['fp']>0 and r['pair_metrics']['fn']>0


def test_rate_limit_applies_in_local_non_test_mode(tmp_path):
 with TestClient(create_app(tmp_path/'rate.sqlite',connectors=Connectors()),base_url='http://127.0.0.1') as c:
  codes=[post(c,'/api/intelligence/import',{'format':'lines','content':'Hello'}).status_code for _ in range(31)]
 assert codes[:30]==[200]*30 and codes[-1]==429

def test_untrusted_host_header_rejected(tmp_path):
 with TestClient(create_app(tmp_path/'host.sqlite',connectors=Connectors()),base_url='http://attacker.example') as c:
  assert c.get('/api/intelligence/runs').status_code==400

def test_review_rejects_nonexistent_group(client):
 r=post(client,'/api/intelligence/analyze',example_request()).json()
 post(client,'/api/intelligence/runs',{'run_id':r['id'],'consent':True})
 result=post(client,'/api/intelligence/runs/'+r['id']+'/review',{'revision':1,'group_id':'G-FFFFFFFFFF','status':'open','consent':True})
 assert result.status_code==404
