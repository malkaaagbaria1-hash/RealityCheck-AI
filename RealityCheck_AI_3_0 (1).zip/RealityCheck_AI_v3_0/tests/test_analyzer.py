import json
from pathlib import Path
import pytest
from backend.analyzer import analyze,parse_url,normalize_domain,eligible_public_host
SAMPLES=json.loads((Path(__file__).parents[1]/'shared/samples.json').read_text(encoding='utf-8'))

@pytest.mark.parametrize('language',['ar','he','en'])
@pytest.mark.parametrize('sample',SAMPLES,ids=lambda s:s['id'])
def test_synthetic_examples(sample,language):
    report=analyze(sample['text'][language],language=language,expected_domain=sample['expected'])
    assert report['verdict']==('high' if sample['kind']=='suspicious' else 'limited')
    assert report['providers']=={'local':'completed','reputation':'not_requested','ai':'not_requested'}

@pytest.mark.parametrize('url',['https://example.com','http://example.com','https://127.0.0.1/a','https://[::1]/','www.example.com','https://مثال.إختبار/','https://good.example@evil.example/login'])
def test_valid_urls(url):
    r=analyze(url,input_type='url')
    assert len(r['urls'])==1

@pytest.mark.parametrize('url',['javascript:alert(1)','file:///etc/passwd','data:text/html,hi','https://','http://a:bad','https://a.example\\@b.example','https://exa mple.org','https://x.example/\u202e'])
def test_invalid_urls(url):
    with pytest.raises(ValueError): analyze(url,input_type='url')

@pytest.mark.parametrize('text',['','   ','a'*12001])
def test_reject_blank_and_oversize(text):
    with pytest.raises(ValueError): analyze(text)

def test_expected_domain_boundary():
    r=analyze('https://bank.example.attacker.example',input_type='url',expected_domain='bank.example')
    assert 'domain_mismatch' in {s['code'] for s in r['signals']}
    r=analyze('https://secure.bank.example',input_type='url',expected_domain='bank.example')
    assert 'domain_mismatch' not in {s['code'] for s in r['signals']}

def test_userinfo_real_host():
    r=analyze('https://bank.example@attacker.example',input_type='url')
    assert r['urls'][0]['host']=='attacker.example'
    assert 'userinfo' in {s['code'] for s in r['signals']}

def test_no_signals_is_not_safe():
    r=analyze('Hello, see you at the library tomorrow.')
    assert r['verdict']=='limited' and r['score']==0
    assert 'safe' not in r['verdict']

def test_https_does_not_establish_trust():
    r=analyze('https://example.org',input_type='url')
    assert r['verdict']=='limited'

def test_repeated_signals_do_not_inflate_score():
    a=analyze('pay immediately https://one.example/a',language='en')
    b=analyze('pay immediately https://one.example/a https://two.example/b',language='en')
    assert a['score']==b['score']

def test_idn_alone_not_suspicious():
    r=analyze('https://مثال.إختبار',input_type='url')
    assert r['score']==0 and any(s['code']=='idn' for s in r['signals'])

def test_url_limit_is_visible():
    r=analyze(' '.join(f'https://site{i}.example' for i in range(12)))
    assert r['urls_truncated'] and len(r['urls'])==10

@pytest.mark.parametrize('host',['127.0.0.1','8.8.8.8','::1','localhost','private.local','private.internal','private.lan','test.example','x.test','example.org','sub.example.org'])
def test_hosts_excluded_from_external_services(host):
    assert not eligible_public_host(host)

@pytest.mark.parametrize('host',['www.wikipedia.org','openai.com'])
def test_public_domain_eligibility_is_only_syntax(host):
    assert eligible_public_host(host) # This does NOT imply the domain is safe.

@pytest.mark.parametrize('domain',['https://example.org','example.org/path','user@example.org','example.org:443','example.org?token=secret','-bad.example','no_dot'])
def test_expected_domain_validation(domain):
    with pytest.raises(ValueError):normalize_domain(domain)

def test_defanged_link_recognized():
    r=analyze('Check hxxps://hello[.]example/path')
    assert r['urls'][0]['host']=='hello.example'

def test_html_is_returned_as_data_only():
    text='<img src=x onerror=alert(1)> Hello'
    assert analyze(text)['original_text']==text

def test_secrets_not_found_in_url_paths_as_message_rules():
    r=analyze('Here is https://hello.example/urgent/pay/password')
    assert not any(s['group']=='secrets' for s in r['signals'])
