import json
import pytest
from fastapi.testclient import TestClient
from backend.app import create_app
from backend.integrations import Connectors
HEADERS={'X-RealityCheck-Client':'web'}
@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path/'test.sqlite3',testing=True,connectors=Connectors())) as c:
        yield c

def post(c,path,payload):return c.post(path,json=payload,headers=HEADERS)

def test_health_honest_and_no_keys(client):
    r=client.get('/api/health').json()
    assert r['status']=='ok' and not r['ai_configured'] and not r['reputation_configured']
    assert not r['public_deployment_ready']
    assert 'API_KEY' not in json.dumps(r)

def test_analyze_does_not_save_automatically(client):
    r=post(client,'/api/analyze',{'text':'مرحبا، اللقاء بكرا.'})
    assert r.status_code==200
    assert client.get('/api/cases').json()['cases']==[]

def test_save_read_delete_lifecycle(client):
    report=post(client,'/api/analyze',{'text':'Urgent: enter your password at https://verify.example','language':'en'}).json()
    r=post(client,'/api/cases',{'case_id':report['id'],'consent':True})
    assert r.status_code==200
    assert client.get('/api/cases').json()['cases'][0]['id']==report['id']
    assert client.get('/api/cases/'+report['id']).json()['original_text']==report['original_text']
    assert client.delete('/api/cases/'+report['id'],headers=HEADERS).status_code==200
    assert client.get('/api/cases').json()['cases']==[]
    assert client.get('/api/cases/'+report['id']).status_code==404

def test_delete_all(client):
    for text in ['one','two']:
        r=post(client,'/api/analyze',{'text':text}).json()
        post(client,'/api/cases',{'case_id':r['id'],'consent':True})
    assert len(client.get('/api/cases').json()['cases'])==2
    assert client.delete('/api/cases',headers=HEADERS).status_code==200
    assert client.get('/api/cases').json()['cases']==[]

def test_no_save_without_consent(client):
    r=post(client,'/api/analyze',{'text':'hello'}).json()
    assert post(client,'/api/cases',{'case_id':r['id'],'consent':False}).status_code==422
    assert post(client,'/api/cases',{'case_id':'forged','consent':True}).status_code==404

def test_mutations_require_client_header(client):
    assert client.post('/api/analyze',json={'text':'hello'}).status_code==403

def test_cross_origin_mutation_blocked(client):
    assert client.post('/api/analyze',json={'text':'hello'},headers={**HEADERS,'Origin':'https://evil.example'}).status_code==403

def test_cross_site_read_blocked(client):
    assert client.get('/api/cases',headers={'Sec-Fetch-Site':'cross-site'}).status_code==403

def test_untrusted_host_blocked(client):
    assert client.get('/api/health',headers={'Host':'evil.example'}).status_code==400

@pytest.mark.parametrize('payload',[{'text':''},{'text':'   '},{'text':'x'*12001},{'text':'hi','language':'xx'},{'text':'hi','unexpected':1},{'text':'file:///etc/passwd','input_type':'url'},{'text':'hi','expected_domain':'https://hello.org'}])
def test_invalid_input(client,payload):
    assert post(client,'/api/analyze',payload).status_code==422

def test_optional_services_are_not_mocked_as_real(client):
    r=post(client,'/api/analyze',{'text':'hello','use_ai':True,'use_reputation':True}).json()
    assert r['providers']['ai']=='not_configured'
    assert r['providers']['reputation']=='not_configured'
    assert r['ai_summary'] is None

def test_security_headers_and_static(client):
    r=client.get('/')
    assert r.status_code==200 and 'RealityCheck AI' in r.text
    assert r.headers['x-content-type-options']=='nosniff'
    assert r.headers['referrer-policy']=='no-referrer'
    assert "frame-ancestors 'none'" in r.headers['content-security-policy']
    assert client.get('/assets/app.js').status_code==200

def test_image_transcription_requires_configuration(client):
    r=post(client,'/api/extract-image',{'data_url':'data:image/png;base64,aGVsbG8=','consent':True})
    assert r.status_code==503

def test_streamed_body_limit(client):
    r=client.post('/api/analyze',content=b'x'*6500001,headers={**HEADERS,'Content-Type':'application/json'})
    assert r.status_code==413
