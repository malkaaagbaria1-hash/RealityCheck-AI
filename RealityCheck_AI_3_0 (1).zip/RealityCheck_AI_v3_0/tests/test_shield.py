"""3.0 Evasion Shield: obfuscation recovery, offsets, false-positive guard and JS parity."""
import json
from pathlib import Path
import pytest
from backend.analyzer import analyze
from backend.matching import shield_view

ROOT = Path(__file__).parents[1]


@pytest.mark.parametrize('text,code', [
    ('Send your p a s s w o r d immediately', 'credentials'),
    ('Enter your passw0rd imm3diately', 'credentials'),
    ('Enter your pass-word now', 'credentials'),
    ('Enter your pass*word now', 'credentials'),
    ('Enter your раssword', 'credentials'),          # Cyrillic р/а
    ('Enter your pass\U0001F511word', 'credentials'),         # emoji inside word
    ('Enter your pa­ss­word', 'credentials'),       # soft hyphens
    ('Enter your pa⁠ssword', 'credentials'),             # word joiner
    ('Install T34mV13w3r now', 'remote_access'),
    ('ادخل کلمة المرور', 'credentials'),  # Persian kaf
])
def test_shield_recovers_obfuscated_rules(text, code):
    assert code not in {s['code'] for s in analyze(text, language='en', shield=False)['signals']}
    hardened = analyze(text, language='en')
    assert code in {s['code'] for s in hardened['signals']}
    assert hardened['decision']['evasion_shield'] is True


def test_arabic_indic_digits_map_to_ascii():
    view, _ = shield_view('خلال ٢٤ ساعة', list(range(9)))
    assert '24' in view


def test_evidence_keeps_original_text():
    text = 'Enter your p4ssw0rd'
    signal = next(s for s in analyze(text, language='en')['signals'] if s['code'] == 'credentials')
    assert signal['evidence'] == 'Enter your p4ssw0rd'
    assert text[signal['start']:signal['end']] == signal['evidence']


@pytest.mark.parametrize('text', [
    'Your code is 1234, valid 24h', 'Call 050-123-4567 tomorrow at 10', 'Order RR123456789IL shipped',
    'Meeting in room B12 at 3pm', 'Version 2.0.1-beta is out', 'e-mail me the slides please',
])
def test_shield_does_not_create_alerts_on_ordinary_text(text):
    assert analyze(text, language='en')['score'] == analyze(text, language='en', shield=False)['score'] == 0


def test_benign_challenges_unchanged():
    for item in json.loads((ROOT/'evaluation/challenges.json').read_text(encoding='utf-8')):
        a = analyze(item['text'], language=item['language'], shield=True)['score']
        b = analyze(item['text'], language=item['language'], shield=False)['score']
        assert a == b, item['id']


def test_js_parity_on_attack_corpus():
    corpus = ROOT/'evaluation/redteam_corpus.json'
    if not corpus.exists():
        pytest.skip('run: node scripts/redteam_benchmark.mjs --corpus-out evaluation/redteam_corpus.json')
    rows = json.loads(corpus.read_text(encoding='utf-8'))
    assert len(rows) > 300
    mismatches = [r['id']+'/'+r['variant'] for r in rows
                  if analyze(r['text'], language=r['language'], expected_domain=r.get('expected_domain', ''))['score'] != r['js_v3']]
    assert mismatches == []


def test_redteam_results_recorded():
    result = json.loads((ROOT/'evaluation/redteam_results.json').read_text(encoding='utf-8'))
    assert result['robustness']['v3'] > result['robustness']['v2']
    assert result['false_positive_guard']['score_changed'] == []
    assert result['clean_suspicious_score_changed'] == 0
