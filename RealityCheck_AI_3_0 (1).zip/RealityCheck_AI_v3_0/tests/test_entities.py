"""3.0.1 built-in identity hints: no expected domain needed for well-known organizations."""
import json
from pathlib import Path
import pytest
from backend.analyzer import analyze

CASES = json.loads((Path(__file__).parents[1]/'evaluation/entity_cases.json').read_text(encoding='utf-8'))


@pytest.mark.parametrize('case', CASES, ids=[c['id'] for c in CASES])
def test_entity_cases(case):
    r = analyze(case['text'], language=case['language'])
    assert (r['score'] >= 25) == case['alert']
    if case['alert']:
        assert 'claimed_mismatch' in {s['code'] for s in r['signals']}


def test_user_supplied_domain_takes_precedence():
    text = 'Police notice: unpaid traffic fine. Pay within 24 hours at https://police-fines-pay.example'
    codes = {s['code'] for s in analyze(text, language='en', expected_domain='police.gov.il')['signals']}
    assert 'domain_mismatch' in codes and 'claimed_mismatch' not in codes


def test_official_subdomain_is_not_flagged():
    r = analyze('Police notice: pay your traffic fine within 24 hours at https://www.police.gov.il/fines', language='en')
    assert 'claimed_mismatch' not in {s['code'] for s in r['signals']}
