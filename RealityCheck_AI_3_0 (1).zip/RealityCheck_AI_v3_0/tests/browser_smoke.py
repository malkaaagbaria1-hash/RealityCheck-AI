"""Real Chromium smoke checks. Requires playwright + a Chromium executable.
Run the server on port 8765 first, then: python tests/browser_smoke.py
This is not a production security audit or real-world detection benchmark.
"""
from pathlib import Path
import json,os,sys,urllib.request,urllib.error
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from backend.analyzer import analyze
checks=[]
# The execution environment blocks browser URL navigation. Render our local HTML
# directly and bridge only test API calls to the local test server. No browser
# policy is changed. Native navigation / downloads still need user-machine QA.
def bridge(path,options):
    if not path.startswith('/api/'):
        raise ValueError('Only the local test API is allowed')
    request=urllib.request.Request('http://127.0.0.1:8765'+path,
        data=options.get('body','').encode('utf-8') if options.get('body') else None,
        method=options.get('method','GET'),headers=options.get('headers') or {})
    try:
        with urllib.request.urlopen(request) as response:
            return {'status':response.status,'data':json.loads(response.read())}
    except urllib.error.HTTPError as error:
        return {'status':error.code,'data':json.loads(error.read())}
BRIDGE_JS="""<script>
window.fetch=async(path,options={})=>{
 const r=await window.__rcTestFetch(path,{method:options.method||'GET',headers:options.headers||{},body:options.body||''});
 return {ok:r.status>=200&&r.status<300,status:r.status,json:async()=>r.data};
};
</script>"""
def load_document(page,server=True):
    html=(ROOT/'RealityCheck_AI.html').read_text(encoding='utf-8')
    if server:
        page.expose_function('__rcTestFetch',bridge)
        html=html.replace('</head>',BRIDGE_JS+'</head>')
        html=html.replace("if(location.protocol==='http:'||location.protocol==='https:'){","if(true){")
    page.set_content(html,wait_until='load')
    page.wait_for_function("document.querySelector('.mode-pill') !== null")
    if server:page.wait_for_function("document.querySelector('.mode-pill').textContent.includes('Python')")

def check(name,condition):
    assert condition,name
    checks.append(name)
    print('PASS',name)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':1440,'height':1000},device_scale_factor=1,accept_downloads=True)
    page=context.new_page();errors=[];external=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda req:external.append(req.url) if not req.url.startswith(('http://127.0.0.1:8765','file:','data:','blob:')) else None)
    page.on('dialog',lambda dialog:dialog.accept())
    load_document(page)
    check('Arabic RTL default',page.locator('html').get_attribute('dir')=='rtl')
    check('Server ready and live UI',page.locator('.mode-pill').inner_text()=='خادم Python')
    check('Empty submit disabled',page.locator('#start-button').is_disabled())
    page.screenshot(path=str(ROOT/'docs/SCREENSHOT_DESKTOP.png'),full_page=True)
    page.locator('[data-sample="parcel"]').click()
    page.locator('#start-button').click()
    page.locator('.score-value').wait_for()
    check('Arabic example returns real rule score',page.locator('.score-value').inner_text().startswith('92'))
    check('Evidence cards rendered',page.locator('.evidence-item').count()>=5)
    check('Suspect links are not clickable',page.locator('.url-item a').count()==0)
    page.screenshot(path=str(ROOT/'docs/SCREENSHOT_REPORT.png'),full_page=True)
    page.locator('[data-action="save"]').click()
    page.wait_for_function("document.querySelector('.nav-count').textContent === '1'")
    check('Explicit save succeeds',page.locator('.nav-count').inner_text()=='1')
    page.evaluate("""() => {
      const original=HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click=function(){
        if(this.download){window.__exportName=this.download;window.__exportURL=this.href;return;}
        return original.call(this);
      };
    }""")
    page.locator('[data-action="export"]').click()
    check('JSON export constructs a downloadable file',page.evaluate("window.__exportName.endsWith('.json') && window.__exportURL.startsWith('blob:')"))
    page.locator('[data-page="history"]').first.click()
    check('History contains saved case',page.locator('.history-card').count()==1)
    page.locator('#case-search').fill('no-such-case')
    check('History filtering works',page.locator('.history-card').count()==0)
    page.locator('#case-search').fill('')
    page.locator('[data-open]').click()
    check('Saved report reopens',page.locator('.evidence-item').count()>=5)
    page.locator('[data-page="history"]').first.click()
    page.locator('[data-delete]').click()
    page.wait_for_function("document.querySelectorAll('.history-card').length === 0")
    check('Deletion works',page.locator('.history-card').count()==0)
    page.locator('[data-page="lab"]').click()
    check('Lab has four synthetic cases',page.locator('.sample-card').count()==4)
    page.locator('[data-lang="he"]').click()
    check('Hebrew navigation',page.locator('html').get_attribute('lang')=='he' and 'מעבדת' in page.locator('.breadcrumb').inner_text())
    page.locator('[data-sample="warning"]').click()
    page.locator('#start-button').click();page.locator('.score-value').wait_for()
    check('Hebrew safety warning regression fixed',page.locator('.score-value').inner_text().startswith('0'))
    page.locator('[data-lang="en"]').click()
    check('English switches to LTR',page.locator('html').get_attribute('dir')=='ltr')
    page.locator('[data-action="theme"]').click()
    check('Light theme works',page.locator('html').get_attribute('data-theme')=='light')
    page.locator('[data-page="investigate"]').first.click()
    page.locator('[data-tab="url"]').click()
    page.locator('#content').fill('javascript:alert(1)');page.locator('#start-button').click()
    page.locator('.error-box').wait_for()
    check('Invalid URL gets visible error',page.locator('.error-box').is_visible())
    page.locator('[data-tab="message"]').click()
    page.locator('#content').fill('<img src=x onerror="window.__xss=1"> Hello friend')
    page.locator('#start-button').click();page.locator('.score-value').wait_for()
    check('Input markup never executed',page.evaluate('window.__xss === undefined'))
    page.locator('[data-tab="image"]').click()
    page.locator('#image-file').set_input_files(str(ROOT/'docs/SCREENSHOT_DESKTOP.png'))
    page.locator('.image-preview').wait_for()
    check('Local image preview works',page.locator('.image-preview img').count()==1)
    check('AI transcription honestly disabled without key',page.locator('[data-action="extract"]').is_disabled())
    page.locator('[data-page="settings"]').first.click()
    check('Unconfigured services visible',page.locator('.config-row').count()==3)
    check('No external web requests by default',external==[])
    check('No uncaught JavaScript errors',errors==[])
    # Mobile layout and navigation.
    mobile=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
    mp=mobile.new_page();load_document(mp)
    check('Mobile no horizontal overflow',mp.evaluate('document.documentElement.scrollWidth <= innerWidth'))
    mp.screenshot(path=str(ROOT/'docs/SCREENSHOT_MOBILE.png'),full_page=True)
    mp.locator('.mode-pill').click()
    check('Mobile settings accessible',mp.locator('.config-card').is_visible())
    mp.locator('button[data-page="investigate"]').first.click()
    mp.locator('[data-sample="parcel"]').click();mp.locator('#start-button').click();mp.locator('.score-value').wait_for()
    check('Mobile report no horizontal overflow',mp.evaluate('document.documentElement.scrollWidth <= innerWidth'))
    # Portable HTML: actual local checks without a server or network requests.
    offline=browser.new_context(viewport={'width':1280,'height':900})
    op=offline.new_page();requests=[];offline_errors=[]
    op.on('request',lambda req:requests.append(req.url) if not req.url.startswith(('file:','data:','blob:')) else None)
    op.on('pageerror',lambda e:offline_errors.append(str(e)))
    load_document(op,server=False)
    check('Portable HTML renders directly in Chromium',op.locator('.mode-pill').inner_text()=='نسخة مستقلة')
    op.locator('[data-sample="parcel"]').click();op.locator('#start-button').click();op.locator('.score-value').wait_for()
    check('Standalone local engine works',op.locator('.score-value').inner_text().startswith('92'))
    samples=json.loads((ROOT/'shared/samples.json').read_text(encoding='utf-8'))
    parity=0
    for sample in samples:
        for lang in ('ar','he','en'):
            payload={'text':sample['text'][lang],'language':lang,'expected_domain':sample['expected']}
            js=op.evaluate('(p)=>RC.analyze(p)',payload)
            py=analyze(**payload)
            assert js['score']==py['score'] and js['verdict']==py['verdict']
            assert [s['code'] for s in js['signals']]==[s['code'] for s in py['signals']]
            parity+=1
    check('12 browser/Python example parity checks',parity==12)
    check('Standalone makes no network requests',requests==[])
    check('Standalone has no JS errors',offline_errors==[])
    browser.close()
(ROOT/'docs/browser_results.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'example_parity_cases':12,'external_provider_calls':'not exercised with live credentials','browser_method':'set_content of portable HTML; server requests bridged through local Python HTTP because browser URL navigation is blocked by environment policy; native navigation and file downloads not tested'},ensure_ascii=False,indent=2),encoding='utf-8')
print('BROWSER CHECKS PASSED:',len(checks))
