"""Chromium UI/engine tests using a localhost Python HTTP bridge.
Native browser navigation is blocked in this build environment. No policy bypass is used:
HTML is set as content; only API calls are bridged. Native navigation/download delivery,
real browser storage persistence, actual Safari and Windows execution remain manual QA.
"""
import json,os,sys,urllib.request,urllib.error
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from backend.analyzer import analyze
from backend.ml_model import predict
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name);print('PASS',name,flush=True)
def bridge(path,options):
 if not path.startswith('/api/'):raise ValueError('Only local API allowed')
 req=urllib.request.Request('http://127.0.0.1:8765'+path,data=options.get('body','').encode() if options.get('body') else None,method=options.get('method','GET'),headers=options.get('headers') or {})
 try:
  with urllib.request.urlopen(req) as r:return {'status':r.status,'data':json.loads(r.read())}
 except urllib.error.HTTPError as e:return {'status':e.code,'data':json.loads(e.read())}
BRIDGE="""<script>window.fetch=async(path,options={})=>{const r=await window.__rcTestFetch(path,{method:options.method||'GET',headers:options.headers||{},body:options.body||''});return {ok:r.status>=200&&r.status<300,status:r.status,json:async()=>r.data};};</script>"""
def load(page,server=True):
 html=(ROOT/'RealityCheck_AI.html').read_text(encoding='utf-8')
 if server:
  page.expose_function('__rcTestFetch',bridge)
  html=html.replace('</head>',BRIDGE+'</head>').replace("if(location.protocol==='http:'||location.protocol==='https:'){","if(true){")
 page.set_content(html,wait_until='load');page.wait_for_selector('.mode-pill')
 if server:page.wait_for_function("document.querySelector('.mode-pill').textContent.includes('Python')")
def investigate(p,text):
 p.locator('button[data-page="investigate"]').first.click();p.locator('[data-tab="message"]').click();p.locator('#content').fill(text);p.locator('#start-button').click();p.locator('.score-value').wait_for()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1440,'height':1000});errors=[]
 page.set_default_timeout(6000)
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());load(page)
 check('Release version shown','3.0.0' in page.locator('.version').inner_text())
 page.screenshot(path=str(ROOT/'docs/RELEASE_DESKTOP.png'),full_page=False)
 investigate(page,'حسابك البنكي رح يتوقف خلال 24 ساعة! لازم تدخل كلمة المرور ورمز التحقق فورًا لتجنب إغلاق الحساب.')
 check('Original user regression shows 88',page.locator('.score-value').inner_text().startswith('88'))
 check('Four deterministic evidence items',page.locator('.evidence-item').count()==4)
 check('Synthetic model disclosed','240' in page.locator('.ml-card').inner_text())
 check('Pipeline is present',page.locator('.pipeline-stages>div').count()==5)
 page.locator('[data-ask="askWhy"]').click();page.locator('.chat-answer').wait_for()
 check('Assistant cites existing evidence','[E' in page.locator('.chat-answer').inner_text())
 check('Assistant not mislabelled LLM','محلي' in page.locator('.chat-entry small').inner_text())
 page.locator('#assistant-question').fill('شو أعمل هسا؟');page.locator('#assistant-form button[type="submit"]').click();page.wait_for_function("document.querySelectorAll('.chat-entry').length === 2")
 check('Assistant free-text request works',page.locator('.chat-entry').count()==2)
 page.locator('#case-report').scroll_into_view_if_needed();page.screenshot(path=str(ROOT/'docs/RELEASE_REPORT.png'),full_page=True)
 page.locator('[data-action="save"]').click();page.wait_for_function("Number(document.querySelector('.nav-count').textContent)>0")
 page.locator('#analyst-note').fill('فحص أكاديمي — لم يتم فتح الروابط.');page.locator('#reviewed-note').check();page.locator('[data-adv="save-note"]').click();page.wait_for_timeout(250)
 check('Analyst note saved',page.locator('#analyst-note').input_value().startswith('فحص أكاديمي'))
 page.locator('[data-page="dashboard"]').first.click()
 check('Dashboard shows real saved records',page.locator('.case-row').count()>0)
 page.screenshot(path=str(ROOT/'docs/RELEASE_DASHBOARD.png'),full_page=False)
 page.locator('.case-row').first.click();page.locator('#analyst-note').wait_for()
 check('Note persists after case reload',page.locator('#analyst-note').input_value().startswith('فحص أكاديمي'))
 page.evaluate("""()=>{const orig=URL.createObjectURL;URL.createObjectURL=function(blob){window.__lastBlob=blob;return orig.call(this,blob);};const old=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.download){window.__filename=this.download;return;}old.call(this);};}""")
 page.locator('[data-adv="export-html"]').click()
 html=page.evaluate('()=>window.__lastBlob.text()')
 check('HTML report produced','<!doctype html>' in html and '240' in html)
 check('Report export has no active script','<script' not in html.lower())
 page.locator('[data-page="compare"]').first.click();page.locator('[data-adv="compare-demo"]').click();page.locator('#compare-form button[type="submit"]').click();page.locator('.compare-result').wait_for()
 check('Compare produces negative score delta','-' in page.locator('.delta-score strong').inner_text())
 check('Credentials are removed in warning comparison','معلومات حساسة' in page.locator('.comparison-diff').inner_text())
 page.screenshot(path=str(ROOT/'docs/RELEASE_COMPARISON.png'),full_page=False)
 page.locator('[data-page="evaluation"]').first.click();page.locator('[data-adv="self-check"]').click();page.locator('.check-results').wait_for()
 check('Four live readiness checks rendered',page.locator('.check-results>div').count()==4)
 check('All live readiness checks pass','لم ينجح' not in page.locator('.check-results').inner_text())
 check('Evaluation discloses false negatives',page.locator('.boundary-case').count()>0)
 page.screenshot(path=str(ROOT/'docs/RELEASE_EVALUATION.png'),full_page=True)
 for lang in ['he','en','ar']:
  page.locator('[data-lang="'+lang+'"]').click()
  for dest in ['dashboard','compare','evaluation','settings','about','investigate']:
   page.locator('button[data-page="'+dest+'"]').first.click()
   check(f'{lang} {dest} no desktop overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 page.locator('[data-adv="presentation"]').click()
 check('Presentation mode toggles',page.locator('body').evaluate("e=>e.classList.contains('presentation-mode')"))
 page.locator('[data-adv="presentation"]').click()
 check('No JS exceptions in advanced UI',not errors)
 # Engine parity on all authored challenges, including known false positives/negatives.
 op=b.new_page(viewport={'width':1280,'height':950});load(op,False);oe=[];op.on('pageerror',lambda e:oe.append(str(e)))
 cases=json.loads((ROOT/'evaluation/challenges.json').read_text(encoding='utf-8'))
 parity=[];model_parity=[]
 for row in cases:
  payload={'text':row['text'],'language':row['language'],'expected_domain':row['expected_domain']}
  js=op.evaluate('(x)=>RC.analyze(x)',payload);py=analyze(**payload)
  parity.append(js['score']==py['score'] and [s['code'] for s in js['signals']]==[s['code'] for s in py['signals']])
  if not parity[-1]:print('PARITY FAIL',row['id'],js['score'],py['score'])
  model_parity.append(js['ml']['label']==py['ml']['label'] and abs(js['ml']['raw_margin']-py['ml']['raw_margin'])<.002)
 check('60 JS/Python challenge score and code comparisons',all(parity))
 check('60 JS/Python learned-model output comparisons',all(model_parity))
 op.locator('[data-page="compare"]').first.click();op.locator('[data-adv="compare-demo"]').click();op.locator('#compare-form button[type="submit"]').click();op.locator('.compare-result').wait_for()
 check('Offline compare works without server',op.locator('.delta-score strong').inner_text().startswith('-'))
 investigate(op,'لازم تدخل كلمة المرور فورا');op.locator('[data-ask="askWhy"]').click();op.locator('.chat-answer').wait_for()
 check('Offline assistant responds with evidence','[E' in op.locator('.chat-answer').inner_text())
 check('No portable JS errors',not oe)
 # Mobile emulation, not a Safari certification.
 mp=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);mp.set_default_timeout(6000);load(mp)
 for dest in ['dashboard','compare','evaluation','settings','about','investigate']:
  if dest=='settings': mp.locator('.mode-pill').click()
  elif dest=='about': mp.locator('.footer-link').click()
  else: mp.locator('button[data-page="'+dest+'"]').first.click()
  check(f'Mobile {dest} no overflow',mp.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 mp.screenshot(path=str(ROOT/'docs/RELEASE_MOBILE.png'),full_page=True)
 investigate(mp,'لازم تدخل كلمة المرور فورا');mp.locator('[data-ask="askWhy"]').click();mp.locator('.chat-answer').wait_for()
 check('Mobile advanced report no overflow',mp.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 mp.screenshot(path=str(ROOT/'docs/RELEASE_MOBILE_REPORT.png'),full_page=True)
 b.close()
(ROOT/'docs/browser_release_results.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'engine_parity_cases':60,'model_parity_cases':60,'method':'Chromium set_content; localhost API via Python HTTP bridge; no native navigation/download delivery/Safari/Windows QA'},ensure_ascii=False,indent=2),encoding='utf-8')
print('RELEASE BROWSER CHECKS:',len(checks))
