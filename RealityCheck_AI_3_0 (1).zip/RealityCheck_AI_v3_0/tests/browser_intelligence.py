"""Local Chromium DOM/interaction QA with a narrow Python HTTP test bridge.

Native browser navigation is blocked by the build environment. The application's
bundled HTML is loaded using set_content; only relative /api/ calls to the disposable
localhost test server are exposed. No external browsing or provider calls are made.
This is not a native-navigation, Windows, Safari or real-device verification.
"""
import json, os, time, urllib.request, urllib.error
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
RESULTS=[]
def check(name, ok):
    if not ok:raise AssertionError(name)
    RESULTS.append(name);print('PASS',name,flush=True)

def bridge(path, options):
    if not isinstance(path,str) or not path.startswith('/api/') or '://' in path:
        raise ValueError('Test bridge accepts relative local API paths only')
    req=urllib.request.Request('http://127.0.0.1:8765'+path,
        data=options.get('body','').encode() if options.get('body') else None,
        method=options.get('method','GET'), headers=options.get('headers') or {})
    try:
        with urllib.request.urlopen(req,timeout=20) as r:return {'status':r.status,'body':r.read().decode('utf-8')}
    except urllib.error.HTTPError as e:return {'status':e.code,'body':e.read().decode('utf-8')}
BRIDGE='''<script>window.fetch=async(path,options={})=>{const r=await window.__rcTestFetch(path,{method:options.method||'GET',headers:options.headers||{},body:options.body||''});return {ok:r.status>=200&&r.status<300,status:r.status,json:async()=>JSON.parse(r.body),text:async()=>r.body};};</script>'''

def load(page, server=True):
    html=(ROOT/'RealityCheck_AI.html').read_text(encoding='utf-8')
    if server:
        page.expose_function('__rcTestFetch',bridge)
        html=html.replace('</head>',BRIDGE+'</head>').replace("if(location.protocol==='http:'||location.protocol==='https:'){","if(true){")
    page.set_content(html,wait_until='load')
    page.wait_for_selector('.ci-tabs')
    if server:page.wait_for_function("document.querySelector('.mode-pill').textContent.includes('Python')")

with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.getenv('CHROMIUM_EXECUTABLE','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page(viewport={'width':1600,'height':1050});page.set_default_timeout(10000)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
    load(page)
    check('3.0 version and campaign landing','3.0.0' in page.locator('.version').inner_text())
    check('No desktop overflow at start',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    page.screenshot(path=str(ROOT/'docs/V2_WORKBENCH_DESKTOP.png'),full_page=True)
    page.locator('[data-ci="demo"]').click();page.wait_for_function("document.querySelector('.ci-ready')?.textContent.includes('37')")
    check('Demo ingestion displays 37 messages','37' in page.locator('.ci-ready').inner_text())
    check('Demo label explicitly synthetic','مصطنعة' in page.locator('#ci-title').input_value())
    page.locator('[data-ci="analyze"]').click();page.locator('.ci-result-layout').wait_for()
    check('Five candidate groups',page.locator('.ci-group').count()==5)
    check('37 actual record rows',page.locator('.ci-record-row').count()==37)
    check('Graph contains data-bound message nodes',page.locator('.ci-node').count()>=3)
    check('Graph has real domain nodes',page.locator('.ci-host').count()>=1)
    check('Evidence score is not called probability','مؤشر' in page.locator('.ci-graph-legend').inner_text())
    check('Privacy and uncertainty visible','ليست حملات مؤكدة' in page.locator('.ci-disclosure').inner_text())
    check('Review disabled until saved',page.locator('[data-ci="review"]').is_disabled())
    page.screenshot(path=str(ROOT/'docs/V2_CAMPAIGNS_DESKTOP.png'),full_page=True)
    # Selection within the evidence map; keyboard interaction as well as mouse.
    old=page.locator('.ci-inspector>.ci-section-top code').inner_text()
    page.locator('.ci-node').nth(1).click()
    check('Graph selection opens correct evidence',page.locator('.ci-inspector>.ci-section-top code').inner_text()!=old)
    page.locator('.ci-node').nth(2).focus();page.keyboard.press('Enter')
    check('Keyboard graph selection supported',page.locator('.ci-node.selected').count()==1)
    page.locator('.ci-links>summary').click()
    check('Every group relation has reason rows',page.locator('.ci-link-row').count()>=3)
    check('No clickable suspect URLs',page.locator('a[href*=".example"]').count()==0)
    page.locator('[data-ci="save"]').click();page.wait_for_function("document.querySelector('[data-ci=review]').disabled===false")
    check('Explicit save enables review',not page.locator('[data-ci="review"]').is_disabled())
    page.locator('#ci-review-status').select_option('investigating')
    page.locator('#ci-review-note').fill('Reviewing with partner; private email tester@example.com')
    page.locator('[data-ci="review"]').click();page.wait_for_function("document.querySelector('[data-ci=review]').disabled===false")
    check('Human status saved','investigating'==page.locator('#ci-review-status').input_value())
    check('Review note preserved through UI rerender','Reviewing with partner' in page.locator('#ci-review-note').input_value())
    check('Review notes masked server-side','tester@example.com' not in page.locator('#ci-review-note').input_value())
    page.locator('[data-ci="tab-archive"]').click();page.locator('.ci-saved-card').first.wait_for()
    check('Snapshot visible in archive',page.locator('.ci-saved-card').count()>0)
    page.locator('[data-ci="load"]').first.click();page.locator('.ci-result-layout').wait_for()
    check('Review survives saved reload',page.locator('#ci-review-status').input_value()=='investigating')
    # Capture generated download blobs, not native browser download delivery.
    page.evaluate('''()=>{const orig=URL.createObjectURL;URL.createObjectURL=function(blob){window.__lastBlob=blob;return orig.call(this,blob);};const old=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.download){window.__filename=this.download;return;}old.call(this);};}''')
    page.locator('[data-ci="html"]').click();page.wait_for_function("!!window.__lastBlob")
    html=page.evaluate('()=>window.__lastBlob.text()')
    check('HTML report generated', '<!doctype html>' in html and 'Campaign' in html or 'CAMPAIGN' in html)
    check('HTML report has no active script','<script' not in html.lower())
    page.evaluate('window.__lastBlob=null')
    page.locator('[data-ci="json"]').click();page.wait_for_function("!!window.__lastBlob")
    export=json.loads(page.evaluate('()=>window.__lastBlob.text()'))
    check('JSON has all records',len(export['records'])==37)
    check('JSON does not include raw messages',all('original_text' not in row and 'text' not in row for row in export['records']))
    check('Export keeps human history',len(export['events'])>=2)
    page.locator('#ci-search').fill('M001')
    check('Record search filters the list',page.locator('.ci-record-row').count()==1)
    page.locator('#ci-search').fill('')
    check('Clear record search restores list',page.locator('.ci-record-row').count()==37)
    # Legacy analysis remains usable.
    page.locator('button[data-page="investigate"]').first.click()
    page.locator('#content').fill('حسابك البنكي رح يتوقف خلال 24 ساعة! لازم تدخل كلمة المرور ورمز التحقق فورًا لتجنب إغلاق الحساب.')
    page.locator('#start-button').click();page.locator('.score-value').wait_for()
    check('Original 88-point regression retained',page.locator('.score-value').inner_text().startswith('88'))
    page.locator('[data-ask="askWhy"]').click();page.locator('.chat-answer').wait_for()
    check('Legacy evidence assistant retained','[E' in page.locator('.chat-answer').inner_text())
    page.locator('[data-page="intelligence"]').first.click()
    page.locator('[data-ci="tab-benchmark"]').click();page.locator('.ci-benchmark').wait_for()
    check('Benchmark shows known errors',page.locator('.ci-eval-error').count()>0)
    check('Synthetic-only benchmark disclosure','مصطنعة' in page.locator('.ci-disclosure').inner_text())
    page.screenshot(path=str(ROOT/'docs/V2_EVALUATION.png'),full_page=True)
    for lang in ['he','en','ar']:
        page.locator('[data-lang="'+lang+'"]').click()
        for tab in ['input','result','archive','benchmark']:
            page.locator('[data-ci="tab-'+tab+'"]').click();page.wait_for_timeout(180)
            check(f'{lang} {tab} desktop no overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    page.locator('[data-ci="tab-result"]').click();page.wait_for_timeout(150)
    page.locator('[data-lang="en"]').click();page.screenshot(path=str(ROOT/'docs/V2_CAMPAIGNS_EN.png'),full_page=True)
    # Responsive width is emulation, not a physical iPhone test.
    page.set_viewport_size({'width':390,'height':844})
    for lang in ['ar','he','en']:
        page.locator('[data-lang="'+lang+'"]').click()
        for tab in ['input','result','archive','benchmark']:
            page.locator('[data-ci="tab-'+tab+'"]').click();page.wait_for_timeout(150)
            check(f'{lang} {tab} mobile-width no overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    page.locator('[data-lang="ar"]').click();page.locator('[data-ci="tab-result"]').click()
    page.screenshot(path=str(ROOT/'docs/V2_MOBILE.png'),full_page=True)
    page.locator('[data-action="theme"]').click()
    check('Light mode works',page.evaluate("document.documentElement.dataset.theme==='light'"))
    page.screenshot(path=str(ROOT/'docs/V2_MOBILE_LIGHT.png'),full_page=True)
    page.locator('[data-action="theme"]').click()
    check('No JavaScript exceptions',not errors)
    # Fresh standalone file explicitly disables campaign-only features.
    offline=b.new_page(viewport={'width':1280,'height':900});load(offline,server=False)
    check('Standalone limitation is visible','START_WINDOWS.bat' in offline.locator('.ci-empty').inner_text())
    check('Standalone never offers fake batch analysis',offline.locator('[data-ci="analyze"]').count()==0)
    offline.locator('button[data-page="investigate"]').first.click()
    offline.locator('#content').fill('Never share your password.')
    offline.locator('#start-button').click();offline.locator('.score-value').wait_for()
    check('Standalone single-message analysis still works',offline.locator('.score-value').inner_text().startswith('0'))
    b.close()
(ROOT/'docs/browser_v2_results.json').write_text(json.dumps({'passed':len(RESULTS),'checks':RESULTS,
    'scope':'Chromium set_content + local API bridge; not native navigation, native downloads, Windows or Safari.'},ensure_ascii=False,indent=2),encoding='utf-8')
print('TOTAL',len(RESULTS))
