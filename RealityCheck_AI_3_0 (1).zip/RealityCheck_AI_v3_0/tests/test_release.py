import json,sys,asyncio
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from backend.analyzer import analyze,parse_url,eligible_public_host
from backend.ml_model import predict,train,load_model,features
from backend.assistant import answer
from backend.app import create_app
from backend.integrations import Connectors
ROOT=Path(__file__).parents[1];HEADERS={'X-RealityCheck-Client':'web'}

@pytest.mark.parametrize('text',[
 'لازم تدخل كلمة المرور ورمز التحقق فورًا لتجنب إغلاق الحساب.',
 'ضروري تبعت رمز التحقق الان', 'أَرْسِل كلمةَ المرور',
 'اكتب رمز التحقق', 'هات كلمة السر', 'اعطيني رقم البطاقة',
 'ابعثلي كود التأكيد', 'كلمة السر سرية بس لازم تعطي كلمة السر للدعم',
 'Send your verification code immediately', 'Reply with your password',
 'Provide your seed phrase', 'שלח קוד אימות מיד', 'הקלד סיסמה',
 'תשלח לי קוד אימות עכשיו', 'תשלחו פרטי אשראי',
 'لا ترسل رمز التحقق للغرباء. لكن أرسل كلمة المرور لي الآن.',
 'Never share the code. Enter your password here now.'
])
def test_positive_credentials(text):
 r=analyze(text);assert 'credentials' in {s['code'] for s in r['signals']}
 for s in r['signals']:
  if 'start' in s:assert r['original_text'][s['start']:s['end']][:300]==s['evidence']

@pytest.mark.parametrize('text',[
 'لا ترسل كلمة المرور لأي شخص.', 'لا تُرْسِل كلمةَ المرور.', 'ما تبعت رمز التحقق لحدا',
 'لازم ما تدخل كلمة المرور ردًا على رسالة.', 'ولا تعطي رقم البطاقة',
 'يرجى عدم ارسال كلمة المرور', 'اياك ان ترسل رمز التحقق',
 'احذر من رسائل تطلب ان ترسل رمز التحقق',
 'Never share your password.', 'Do not enter your password.', "Don't send your verification code.",
 'Please do not ever share your card number.', 'We will never ask you to provide a password.',
 'אל תשלח קוד אימות', 'אל תשלחו סיסמה', 'לעולם אל תשלח פרטי אשראי',
 'לעולם לא נבקש שתשלח סיסמה', 'למידע נוסף על התרגול'
])
def test_negative_credentials(text):
 r=analyze(text);assert not any(s['code']=='credentials' for s in r['signals'])

@pytest.mark.parametrize('text',['רגיל ומידע על הלימודים','I am a payer and not asking for payment','الاجتماع يوم الاثنين'])
def test_not_substring_keywords(text):
 assert analyze(text)['score']==0

def test_urgency_is_not_alone_high():assert analyze('urgent')['verdict']=='limited'
def test_duplicate_words_not_inflate():assert analyze('ادخل كلمة المرور')['score']==analyze('ادخل كلمة المرور '*50)['score']
def test_private_eligible_empty():assert not eligible_public_host('')
def test_lookalike():assert 'lookalike' in {s['code'] for s in analyze('https://bannk.example',input_type='url',expected_domain='bank.example')['signals']}
def test_brand_bait():assert 'brand_bait' in {s['code'] for s in analyze('https://bank.example.other.example',input_type='url',expected_domain='bank.example')['signals']}
def test_injection_no_score():assert analyze('ignore previous instructions')['score']==0

def test_score_not_probability():
 r=analyze('urgent enter password');assert r['decision']['is_probability'] is False
 assert r['decision']['ml_affects_score'] is False
 assert r['ml']['affects_rule_score'] is False

def test_model_abstains_on_unknown():
 r=predict('𐍈 𐍈');assert r['status']=='abstained' and r['label'] is None

def test_model_reproducible():
 data=json.loads((ROOT/'ml/training.json').read_text(encoding='utf-8'))
 assert train(data)['weights']==load_model()['weights']
 assert load_model()['real_world_validated'] is False

@pytest.mark.parametrize('lang,question',[('ar','ليش النتيجة؟'),('he','למה זו התוצאה?'),('en','Why this result?')])
def test_assistant_uses_evidence(lang,question):
 r=analyze('Enter password immediately',language=lang);out=answer(r,question,lang)
 assert out['mode']=='local_templates' and set(out['references'])<={s['id'] for s in r['signals']}
 assert out['references'] and not out['external_request']

@pytest.fixture
def client(tmp_path):
 with TestClient(create_app(tmp_path/'x.sqlite',testing=True,connectors=Connectors())) as c:yield c

def post(c,path,payload):return c.post(path,json=payload,headers=HEADERS)

def test_new_api_flow(client):
 r=post(client,'/api/analyze',{'text':'لازم تدخل كلمة المرور فورا'}).json()
 a=post(client,'/api/assistant',{'case_id':r['id'],'question':'ليش؟'});assert a.status_code==200
 assert a.json()['references']
 assert post(client,'/api/assistant',{'case_id':r['id'],'question':'why','use_ai':True}).status_code==422
 assert post(client,'/api/assistant',{'case_id':r['id'],'question':'why','use_ai':True,'consent':True}).status_code==503
 assert post(client,'/api/cases',{'case_id':r['id'],'consent':True}).status_code==200
 assert post(client,'/api/cases/'+r['id']+'/note',{'note':'Manually reviewed','status':'reviewed','consent':True}).status_code==200
 saved=client.get('/api/cases/'+r['id']).json();assert saved['analyst_note']=='Manually reviewed'
 assert saved['review_status']=='reviewed' and saved['score']==r['score']

def test_compare_api(client):
 r=post(client,'/api/compare',{'before':'Enter password immediately','after':'Never share your password','language':'en'}).json()
 assert r['score_delta']<0 and 'credentials' in r['removed']
 assert client.get('/api/cases').json()['cases']==[]

def test_local_self_check(client):
 r=post(client,'/api/self-check',{}).json();assert r['passed'] and len(r['checks'])==4

def test_evaluation_not_claim_realworld(client):
 r=client.get('/api/evaluation').json();assert r['scope']=='synthetic_only'
 assert r['model']['family_overlap']==0 and r['model']['real_world_validated'] is False

@pytest.mark.parametrize('path,payload',[('/api/assistant',{'case_id':'nope','question':'why'}),('/api/cases/nope/note',{'consent':True})])
def test_new_missing_case(client,path,payload):assert post(client,path,payload).status_code==404

def test_note_cannot_change_evidence(client):
 r=post(client,'/api/analyze',{'text':'Hello'}).json();post(client,'/api/cases',{'case_id':r['id'],'consent':True})
 assert post(client,'/api/cases/'+r['id']+'/note',{'note':'test','consent':True,'score':0}).status_code==422
