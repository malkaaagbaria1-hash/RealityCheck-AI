@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto missing
.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
if errorlevel 1 goto done
.venv\Scripts\python.exe -m pytest -q
if errorlevel 1 goto done
.venv\Scripts\python.exe scripts\evaluate_campaigns.py
goto done
:missing
echo Run START_WINDOWS.bat first to create the environment.
:done
pause
