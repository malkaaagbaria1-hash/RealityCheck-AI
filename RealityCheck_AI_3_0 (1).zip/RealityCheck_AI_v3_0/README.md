# RealityCheck AI 3.0 — Red Team Edition

> **We attacked our own AI before scammers could.** 3.0 adds an adversarial self-test (Red Team Arena), an Evasion Shield that lifts robustness under white-box attack from **44.4 % to 91.3 %** with zero new false alerts, a psychological *Manipulation DNA* profile, an *Evidence X-ray* that reveals invisible/disguised characters, and a live *Human vs AI* audience challenge. All 3.0 features run fully offline, including in the standalone `RealityCheck_AI.html`.

Quick demo with no installation: open `RealityCheck_AI.html` in Chrome/Edge → **Red Team Arena** → *Launch 13 attacks*. Presentation script: `docs/DEMO_SCRIPT_V3_AR.md`. Release notes: `docs/RELEASE_NOTES_V3.md`.

Reproduce the 3.0 numbers:
```sh
node scripts/redteam_benchmark.mjs --corpus-out evaluation/redteam_corpus.json   # Node >= 18, no packages
python -m pytest -q tests/test_shield.py tests/test_analyzer.py
```

---

## 2.0 base — Campaign Intelligence

A local, evidence-first academic prototype for **candidate campaign correlation**, built on the original message/URL triage application. No external calls are made by the campaign engine. It does not identify threat actors, verify senders, block URLs, or claim production readiness.

## Run

Windows: extract the whole archive, close the earlier server, double-click `START_WINDOWS.bat`.
The launcher prefers an installed Python 3.13, otherwise uses the default available runtime. It creates `.venv`, installs `requirements.txt`, and runs the loopback-only server. First install needs internet. There are no new campaign-engine dependencies beyond the existing application stack.

macOS/Linux: `sh START_MAC_LINUX.sh` with Python >=3.11 available.

Manual development setup:
```sh
python -m venv .venv
# Activate .venv for your platform, then:
python -m pip install -r requirements-dev.txt
python build_frontend.py
python run.py
```
No Node/npm/build service is required for the UI. Source lives in `frontend/src`; run `python build_frontend.py` after editing frontend source. The server chooses a free loopback port from 8000–8009 and opens the browser after a health check. Do not expose it publicly.

## New capabilities

- Bounded CSV/JSON/JSONL/plain-text ingestion with explicit validation (no silent partial batch).
- Up to 200 messages; TF-IDF word/character similarity plus exact-host, exact-target and private contact comparisons.
- Candidate groups using deterministic, anchor-prioritized, complete-link greedy merging; every merged pair must meet the threshold.
- Generic-host exclusions, local warning/negation signals, a user-supplied brand/domain profile.
- Data-bound SVG evidence map, record inspection, supplied-timestamp timeline, search.
- Explicit-save masked snapshots in SQLite, human-review states, revision-conflict protection, local change history.
- Escaped HTML/JSON exports. Raw messages, URL query data and contact comparison keys are not returned in campaign results.
- A reproducible synthetic development benchmark with false merges and missed links displayed.

## Demo

Load the scenario from the campaign workbench, then analyze. It contains 37 fictional records across three languages and yields five candidate groups in balanced mode. The isolated demo is not a field accuracy evaluation. Standalone `RealityCheck_AI.html` supports individual checks only, not batch campaign analysis. The same limitation applies to `publish/index.html`.

## Verification
```sh
python -m pytest -q
python scripts/evaluate_campaigns.py
python scripts/evaluate.py
```
`RUN_TESTS.bat` installs dev requirements, runs Python tests and regenerates the campaign benchmark. Chromium UI tests require optional Playwright and Chromium, not included in runtime dependencies. See `docs/TEST_REPORT_V2.md` for their scope and environment constraints.

## API

Interactive schema: `/api/docs`. Mutating requests require `Content-Type: application/json` and `X-RealityCheck-Client: web`, with a same-origin request when an Origin is supplied. This is a **local API**, not an authenticated commercial service.

- `POST /api/intelligence/import`: validate file text and return normalized records (not saved).
- `POST /api/intelligence/analyze`: analyze a bounded batch without provider calls.
- `GET /api/intelligence/demo`, `/evaluation`: fixtures and synthetic evaluation.
- `POST /api/intelligence/runs`: explicit consent to save a recent server-issued run ID.
- `GET /api/intelligence/runs`: list saved snapshots (max 50).
- `GET /api/intelligence/runs/{id}`: load saved or recent snapshot.
- `POST /api/intelligence/runs/{id}/review`: revision-checked human review.
- `GET /api/intelligence/runs/{id}/export` and `/report`: masked JSON / inert HTML.
- `DELETE /api/intelligence/runs/{id}`: local deletion.

See `examples/local_api.py`. Original individual-analysis API remains available.

## Scope / privacy

A single-user localhost application, not a multi-tenant product. No background collection or monitoring, campaign feed, live crawlers, automatic attribution, or automatic enforcement. Network-free campaign correlation does not verify that a destination is safe. The heuristic generic-host list is finite and exact-host comparisons are not registrable-domain or ownership analysis.

Masking is best-effort, not anonymization. Names and other PII can remain. Saved SQLite content is not encrypted at rest. Review and consent are required before saving/sharing. Legacy individual-case saving can retain original text after explicit consent. Logs do not intentionally include message bodies or API secrets. The local audit history is not authenticated or tamper-proof.

The learned baseline from v1 remains trained on 240 synthetic records. Optional cloud explanation, image transcription and domain reputation connectors remain opt-in and require your own keys. Live credentials were not used for this build. Do not include `.env`, `.venv`, user `data/`, or real messages in shared archives.

See `docs/PROJECT_HE_V2.md`, `docs/DEMO_AR.md`, `docs/ARCHITECTURE_V2.md`, and `docs/THREAT_MODEL_V2.md`. Old v1.0 office documents are under `docs/archive_v1` and are historical, not the v2 specification.
