"""Loopback-only launcher. Select a free port and open only after our app is healthy."""
from pathlib import Path
import json,os,socket,sys,threading,time,urllib.request,webbrowser
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)

def select_port(start: int=8000, attempts: int=10) -> int:
    if not 1024<=start<=65535: raise ValueError('Choose a port between 1024 and 65535.')
    for port in range(start,min(start+attempts,65536)):
        with socket.socket() as sock:
            try: sock.bind(('127.0.0.1',port));return port
            except OSError: continue
    raise OSError('No free local port. Close an earlier server and try again.')

def main():
    try: import uvicorn
    except ImportError:
        print('Dependencies missing. Use START_WINDOWS.bat or install requirements.txt.');return 1
    try: port=select_port(int(os.getenv('REALITYCHECK_PORT','8000')))
    except (ValueError,OSError) as e: print(str(e));return 1
    url=f'http://127.0.0.1:{port}'
    def open_when_ready():
        for _ in range(100):
            try:
                with urllib.request.urlopen(url+'/api/health',timeout=1) as r:
                    health=json.loads(r.read())
                    if health.get('version')=='3.0.0' and health.get('status')=='ok':
                        webbrowser.open(url);return
            except (OSError,ValueError):time.sleep(.25)
    print(f'\nRealityCheck AI 3.0.0 | Red Team Edition\nOpen: {url}\nLocal computer only. Keep this window open. Ctrl+C stops the app.\n')
    if '--no-browser' not in sys.argv:threading.Thread(target=open_when_ready,daemon=True).start()
    uvicorn.run('backend.app:app',host='127.0.0.1',port=port,access_log=False)
    return 0
if __name__=='__main__':sys.exit(main())
