@echo off
setlocal
cd /d "%~dp0"
title RealityCheck AI 3.0 - Red Team Edition
where py >nul 2>nul
if errorlevel 1 goto try_python
py -3.13 -c "import sys" >nul 2>nul
if errorlevel 1 goto default_py
py -3.13 scripts\launcher.py
goto finished
:default_py
py -3 -c "import sys" >nul 2>nul
if errorlevel 1 goto try_python
py -3 scripts\launcher.py
goto finished
:try_python
where python >nul 2>nul
if errorlevel 1 goto no_python
python scripts\launcher.py
goto finished
:no_python
echo Python was not found. Install Python from python.org.
echo If Python Install Manager exists, run: py install 3.13
goto end
:finished
if not errorlevel 1 goto end
echo.
echo Startup did not finish. Read the error above or run DIAGNOSTICS.bat.
echo The standalone RealityCheck_AI.html supports individual checks only.
:end
pause
